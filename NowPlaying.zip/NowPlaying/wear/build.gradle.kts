import java.io.File

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Same fixed signing key as the phone app (the watch and phone apps must share one signature to talk to each other).
val ksPath: String? = System.getenv("KEYSTORE_PATH")?.takeIf { File(it).length() > 0L }

base.archivesName.set("NowPlaying-Watch")

android {
    namespace = "app.nowplaying.watch"
    compileSdk = 35

    defaultConfig {
        // Must match the phone app's id so the two can exchange data.
        applicationId = "app.nowplaying"
        minSdk = 30
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    signingConfigs {
        if (ksPath != null) {
            create("fixed") {
                storeFile = file(ksPath)
                storePassword = System.getenv("KEYSTORE_PASS")
                keyAlias = "edge"
                keyPassword = System.getenv("KEYSTORE_PASS")
            }
        }
    }

    buildTypes {
        debug {
            if (ksPath != null) signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("com.google.android.gms:play-services-wearable:18.2.0")
}
