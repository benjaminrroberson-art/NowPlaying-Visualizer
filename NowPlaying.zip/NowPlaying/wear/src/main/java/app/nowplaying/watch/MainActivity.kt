package app.nowplaying.watch

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager

class MainActivity : Activity() {
    private lateinit var v: WatchView
    private val h = Handler(Looper.getMainLooper())

    private val beat = object : Runnable {
        override fun run() {
            sendSub()
            h.postDelayed(this, 4000)
        }
    }

    /** Tells the phone whether the visualizer page is open (it only streams audio data while it is). */
    private fun sendSub() {
        val on = v.page == 1 && Link.vizOn
        Link.send("/np/sub", byteArrayOf(if (on) 1 else 0))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        v = WatchView(this)
        v.onExit = { finish() }
        v.onPage = { pg ->
            if (pg == 1) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            sendSub()
        }
        setContentView(v)
    }

    override fun onResume() {
        super.onResume()
        Link.start(this)
        v.requestFocus()
        h.removeCallbacks(beat)
        h.post(beat)
        v.invalidate()
    }

    override fun onPause() {
        h.removeCallbacks(beat)
        Link.send("/np/sub", byteArrayOf(0))
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Link.stop()
        super.onPause()
    }
}
