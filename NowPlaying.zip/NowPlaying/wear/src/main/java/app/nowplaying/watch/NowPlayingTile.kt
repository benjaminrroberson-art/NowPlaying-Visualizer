package app.nowplaying.watch

import android.graphics.Bitmap
import android.graphics.Color
import android.os.SystemClock
import androidx.wear.protolayout.ActionBuilders
import androidx.wear.protolayout.ColorBuilders
import androidx.wear.protolayout.DimensionBuilders
import androidx.wear.protolayout.LayoutElementBuilders
import androidx.wear.protolayout.ModifiersBuilders
import androidx.wear.protolayout.ResourceBuilders
import androidx.wear.protolayout.TimelineBuilders
import androidx.wear.tiles.RequestBuilders
import androidx.wear.tiles.TileBuilders
import androidx.wear.tiles.TileService
import com.google.android.gms.wearable.DataEventBuffer
import com.google.android.gms.wearable.WearableListenerService
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import java.nio.ByteBuffer

/**
 * The Now Playing tile: album art behind the song and artist, a progress arc (as of the last refresh),
 * prev / play-pause / next, volume down / up and the like button. Tap the song to open the app.
 */
class NowPlayingTile : TileService() {

    private var lastClick = ""
    private var lastClickAt = 0L

    companion object {
        private var cachedVer = -1
        private var cachedBytes: ByteArray? = null
        private const val ART_PX = 176
    }

    override fun onTileRequest(requestParams: RequestBuilders.TileRequest): ListenableFuture<TileBuilders.Tile> {
        val click = requestParams.currentState.lastClickableId
        val f = SettableFuture.create<TileBuilders.Tile>()
        val ctx = applicationContext
        Link.loadAll(ctx) {
            val now = SystemClock.uptimeMillis()
            val fresh = click.isNotEmpty() && !(click == lastClick && now - lastClickAt < 700)
            if (fresh) {
                lastClick = click
                lastClickAt = now
                when (click) {
                    "pp" -> {
                        Link.toggleLocal()
                        Link.sendAsync(ctx, "/np/cmd", "pp".toByteArray(Charsets.UTF_8))
                    }
                    "prev" -> Link.sendAsync(ctx, "/np/cmd", "prev".toByteArray(Charsets.UTF_8))
                    "next" -> Link.sendAsync(ctx, "/np/cmd", "next".toByteArray(Charsets.UTF_8))
                    "vdn" -> {
                        Link.vol = (Link.vol - 1).coerceAtLeast(0)
                        Link.sendAsync(ctx, "/np/cmd", ("vol:" + Link.vol).toByteArray(Charsets.UTF_8))
                    }
                    "vup" -> {
                        Link.vol = (Link.vol + 1).coerceAtMost(Link.volMax)
                        Link.sendAsync(ctx, "/np/cmd", ("vol:" + Link.vol).toByteArray(Charsets.UTF_8))
                    }
                    "like" -> {
                        Link.like = if (Link.like == 2) 1 else 2
                        Link.sendAsync(ctx, "/np/cmd", "like".toByteArray(Charsets.UTF_8))
                    }
                }
            }
            f.set(buildTile())
        }
        return f
    }

    override fun onTileResourcesRequest(requestParams: RequestBuilders.ResourcesRequest): ListenableFuture<ResourceBuilders.Resources> {
        val f = SettableFuture.create<ResourceBuilders.Resources>()
        Link.loadAll(applicationContext) { f.set(buildResources()) }
        return f
    }

    // ------------------------------------------------------------------ resources (album art)

    private fun resVersion(): String = "a" + Link.artVersion + (if (Link.art != null) "y" else "n")

    private fun artBytes(): ByteArray? {
        val art = Link.art ?: return null
        if (cachedVer == Link.artVersion && cachedBytes != null) return cachedBytes
        return try {
            val small = Bitmap.createScaledBitmap(art, ART_PX, ART_PX, true)
            val b = small.copy(Bitmap.Config.RGB_565, false)
            val buf = ByteBuffer.allocate(b.byteCount)
            b.copyPixelsToBuffer(buf)
            cachedVer = Link.artVersion
            cachedBytes = buf.array()
            cachedBytes
        } catch (e: Exception) {
            null
        }
    }

    private fun buildResources(): ResourceBuilders.Resources {
        val rb = ResourceBuilders.Resources.Builder().setVersion(resVersion())
        val bytes = artBytes()
        if (bytes != null) {
            rb.addIdToImageMapping(
                "art",
                ResourceBuilders.ImageResource.Builder()
                    .setInlineResource(
                        ResourceBuilders.InlineImageResource.Builder()
                            .setData(bytes)
                            .setWidthPx(ART_PX)
                            .setHeightPx(ART_PX)
                            .setFormat(ResourceBuilders.IMAGE_FORMAT_RGB_565)
                            .build()
                    )
                    .build()
            )
        }
        return rb.build()
    }

    // ------------------------------------------------------------------ layout

    private fun buildTile(): TileBuilders.Tile =
        TileBuilders.Tile.Builder()
            .setResourcesVersion(resVersion())
            .setFreshnessIntervalMillis(30_000L)
            .setTileTimeline(TimelineBuilders.Timeline.fromLayoutElement(layout()))
            .build()

    private fun txt(s: String, size: Float, color: Int): LayoutElementBuilders.Text =
        LayoutElementBuilders.Text.Builder()
            .setText(s)
            .setMaxLines(1)
            .setOverflow(LayoutElementBuilders.TEXT_OVERFLOW_ELLIPSIZE_END)
            .setFontStyle(
                LayoutElementBuilders.FontStyle.Builder()
                    .setSize(DimensionBuilders.sp(size))
                    .setColor(ColorBuilders.argb(color))
                    .build()
            )
            .build()

    private fun btn(id: String, label: String, bg: Int, fg: Int, size: Float, textSize: Float): LayoutElementBuilders.LayoutElement {
        val click = ModifiersBuilders.Clickable.Builder()
            .setId(id)
            .setOnClick(ActionBuilders.LoadAction.Builder().build())
            .build()
        val mods = ModifiersBuilders.Modifiers.Builder()
            .setClickable(click)
            .setBackground(
                ModifiersBuilders.Background.Builder()
                    .setColor(ColorBuilders.argb(bg))
                    .setCorner(ModifiersBuilders.Corner.Builder().setRadius(DimensionBuilders.dp(size / 2f)).build())
                    .build()
            )
            .build()
        return LayoutElementBuilders.Box.Builder()
            .setWidth(DimensionBuilders.dp(size))
            .setHeight(DimensionBuilders.dp(size))
            .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
            .setVerticalAlignment(LayoutElementBuilders.VERTICAL_ALIGN_CENTER)
            .setModifiers(mods)
            .addContent(txt(label, textSize, fg))
            .build()
    }

    private fun gap(w: Float): LayoutElementBuilders.LayoutElement =
        LayoutElementBuilders.Spacer.Builder().setWidth(DimensionBuilders.dp(w)).build()

    private fun vgap(h: Float): LayoutElementBuilders.LayoutElement =
        LayoutElementBuilders.Spacer.Builder().setHeight(DimensionBuilders.dp(h)).build()

    private fun fill(color: Int): LayoutElementBuilders.LayoutElement =
        LayoutElementBuilders.Box.Builder()
            .setWidth(DimensionBuilders.expand())
            .setHeight(DimensionBuilders.expand())
            .setModifiers(
                ModifiersBuilders.Modifiers.Builder()
                    .setBackground(ModifiersBuilders.Background.Builder().setColor(ColorBuilders.argb(color)).build())
                    .build()
            )
            .build()

    private fun progressArc(): LayoutElementBuilders.LayoutElement? {
        val dur = Link.durationMs
        if (!Link.showProgress || dur <= 0L) return null
        val frac = (Link.posNow().toFloat() / dur).coerceIn(0f, 1f)
        val on = (frac * 360f).coerceIn(0.5f, 359f)
        val ring = if (Link.art != null) Link.ring else Link.acc
        return LayoutElementBuilders.Arc.Builder()
            .addContent(
                LayoutElementBuilders.ArcLine.Builder()
                    .setLength(DimensionBuilders.degrees(on))
                    .setThickness(DimensionBuilders.dp(4f))
                    .setColor(ColorBuilders.argb(ring))
                    .build()
            )
            .addContent(
                LayoutElementBuilders.ArcLine.Builder()
                    .setLength(DimensionBuilders.degrees(360f - on))
                    .setThickness(DimensionBuilders.dp(4f))
                    .setColor(ColorBuilders.argb(0x33FFFFFF))
                    .build()
            )
            .build()
    }

    private fun layout(): LayoutElementBuilders.LayoutElement {
        val white = Color.WHITE
        val acc = Link.acc
        val onAcc = if ((0.299f * Color.red(acc) + 0.587f * Color.green(acc) + 0.114f * Color.blue(acc)) > 150f) 0xFF101114.toInt() else Color.WHITE
        val openClick = ModifiersBuilders.Clickable.Builder()
            .setId("open")
            .setOnClick(
                ActionBuilders.LaunchAction.Builder()
                    .setAndroidActivity(
                        ActionBuilders.AndroidActivity.Builder()
                            .setPackageName(packageName)
                            .setClassName("app.nowplaying.watch.MainActivity")
                            .build()
                    )
                    .build()
            )
            .build()
        val root = LayoutElementBuilders.Box.Builder()
            .setWidth(DimensionBuilders.expand())
            .setHeight(DimensionBuilders.expand())
            .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
            .setVerticalAlignment(LayoutElementBuilders.VERTICAL_ALIGN_CENTER)
        if (Link.art != null && Link.gotState && Link.hasSession) {
            root.addContent(
                LayoutElementBuilders.Image.Builder()
                    .setResourceId("art")
                    .setWidth(DimensionBuilders.expand())
                    .setHeight(DimensionBuilders.expand())
                    .setContentScaleMode(LayoutElementBuilders.CONTENT_SCALE_MODE_CROP)
                    .build()
            )
        }
        root.addContent(fill(if (Link.art != null && Link.hasSession) 0xB8101114.toInt() else 0xFF101114.toInt()))

        val col = LayoutElementBuilders.Column.Builder()
            .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
        if (!Link.gotState || !Link.hasSession) {
            col.addContent(
                LayoutElementBuilders.Box.Builder()
                    .setModifiers(ModifiersBuilders.Modifiers.Builder().setClickable(openClick).build())
                    .addContent(txt(if (Link.gotState) "Nothing playing" else "Open Now Playing", 16f, white))
                    .build()
            )
        } else {
            val title = if (Link.title.isEmpty()) "Playing" else Link.title
            col.addContent(
                LayoutElementBuilders.Column.Builder()
                    .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
                    .setModifiers(ModifiersBuilders.Modifiers.Builder().setClickable(openClick).build())
                    .addContent(txt(title, 15f, white))
                    .addContent(txt(Link.artist, 12f, 0xCCFFFFFF.toInt()))
                    .build()
            )
            col.addContent(vgap(6f))
            col.addContent(
                LayoutElementBuilders.Row.Builder()
                    .setVerticalAlignment(LayoutElementBuilders.VERTICAL_ALIGN_CENTER)
                    .addContent(btn("prev", "«", 0x33FFFFFF, white, 38f, 18f))
                    .addContent(gap(6f))
                    .addContent(btn("pp", if (Link.playing) "❚❚" else "▶", acc, onAcc, 48f, 18f))
                    .addContent(gap(6f))
                    .addContent(btn("next", "»", 0x33FFFFFF, white, 38f, 18f))
                    .build()
            )
            col.addContent(vgap(6f))
            val row2 = LayoutElementBuilders.Row.Builder()
                .setVerticalAlignment(LayoutElementBuilders.VERTICAL_ALIGN_CENTER)
                .addContent(btn("vdn", "−", 0x33FFFFFF, white, 32f, 18f))
                .addContent(gap(8f))
            if (Link.like > 0) {
                row2.addContent(btn("like", if (Link.like == 2) "♥" else "♡", 0x33FFFFFF, if (Link.like == 2) acc else white, 32f, 18f))
                row2.addContent(gap(8f))
            }
            row2.addContent(btn("vup", "+", 0x33FFFFFF, white, 32f, 18f))
            col.addContent(row2.build())
        }
        root.addContent(col.build())
        val arc = progressArc()
        if (arc != null && Link.gotState && Link.hasSession) root.addContent(arc)
        return root.build()
    }
}

/** Asks the tile to redraw whenever the phone sends new state. */
class TileRefresh : WearableListenerService() {
    override fun onDataChanged(events: DataEventBuffer) {
        try {
            TileService.getUpdater(applicationContext).requestUpdate(NowPlayingTile::class.java)
        } catch (e: Exception) {
        }
    }
}
