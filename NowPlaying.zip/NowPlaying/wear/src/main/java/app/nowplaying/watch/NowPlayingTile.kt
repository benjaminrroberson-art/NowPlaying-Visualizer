package app.nowplaying.watch

import androidx.wear.protolayout.ActionBuilders
import androidx.wear.protolayout.ColorBuilders
import androidx.wear.protolayout.DimensionBuilders
import androidx.wear.protolayout.LayoutElementBuilders
import androidx.wear.protolayout.ModifiersBuilders
import androidx.wear.protolayout.ResourceBuilders
import androidx.wear.protolayout.TimelineBuilders
import androidx.wear.tiles.RequestBuilders
import androidx.wear.tiles.TileBuilders
import androidx.wear.tiles.TileService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import com.google.android.gms.wearable.DataEventBuffer
import com.google.android.gms.wearable.WearableListenerService
import android.graphics.Color
import android.os.SystemClock

/** The Now Playing tile: song, artist and prev / play-pause / next. Tap the song to open the app. */
class NowPlayingTile : TileService() {

    private var lastClick = ""
    private var lastClickAt = 0L

    override fun onTileRequest(requestParams: RequestBuilders.TileRequest): ListenableFuture<TileBuilders.Tile> {
        val click = requestParams.currentState.lastClickableId
        val f = SettableFuture.create<TileBuilders.Tile>()
        val ctx = applicationContext
        Link.loadState(ctx) {
            val now = SystemClock.uptimeMillis()
            val fresh = click.isNotEmpty() && !(click == lastClick && now - lastClickAt < 700)
            if (fresh) {
                lastClick = click
                lastClickAt = now
                when (click) {
                    "pp" -> {
                        Link.toggleLocal()
                        Link.sendAsync(ctx, "/np/cmd", "pp".toByteArray(Charsets.UTF_8))
                    }
                    "prev" -> Link.sendAsync(ctx, "/np/cmd", "prev".toByteArray(Charsets.UTF_8))
                    "next" -> Link.sendAsync(ctx, "/np/cmd", "next".toByteArray(Charsets.UTF_8))
                }
            }
            f.set(buildTile())
        }
        return f
    }

    override fun onTileResourcesRequest(requestParams: RequestBuilders.ResourcesRequest): ListenableFuture<ResourceBuilders.Resources> =
        Futures.immediateFuture(ResourceBuilders.Resources.Builder().setVersion("1").build())

    private fun buildTile(): TileBuilders.Tile =
        TileBuilders.Tile.Builder()
            .setResourcesVersion("1")
            .setFreshnessIntervalMillis(60_000L)
            .setTileTimeline(TimelineBuilders.Timeline.fromLayoutElement(layout()))
            .build()

    private fun txt(s: String, size: Float, color: Int): LayoutElementBuilders.Text =
        LayoutElementBuilders.Text.Builder()
            .setText(s)
            .setMaxLines(1)
            .setOverflow(LayoutElementBuilders.TEXT_OVERFLOW_ELLIPSIZE_END)
            .setFontStyle(
                LayoutElementBuilders.FontStyle.Builder()
                    .setSize(DimensionBuilders.sp(size))
                    .setColor(ColorBuilders.argb(color))
                    .build()
            )
            .build()

    private fun btn(id: String, label: String, bg: Int, fg: Int, size: Float): LayoutElementBuilders.LayoutElement {
        val click = ModifiersBuilders.Clickable.Builder()
            .setId(id)
            .setOnClick(ActionBuilders.LoadAction.Builder().build())
            .build()
        val mods = ModifiersBuilders.Modifiers.Builder()
            .setClickable(click)
            .setBackground(
                ModifiersBuilders.Background.Builder()
                    .setColor(ColorBuilders.argb(bg))
                    .setCorner(ModifiersBuilders.Corner.Builder().setRadius(DimensionBuilders.dp(size / 2f)).build())
                    .build()
            )
            .build()
        return LayoutElementBuilders.Box.Builder()
            .setWidth(DimensionBuilders.dp(size))
            .setHeight(DimensionBuilders.dp(size))
            .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
            .setVerticalAlignment(LayoutElementBuilders.VERTICAL_ALIGN_CENTER)
            .setModifiers(mods)
            .addContent(txt(label, 18f, fg))
            .build()
    }

    private fun gap(w: Float): LayoutElementBuilders.LayoutElement =
        LayoutElementBuilders.Spacer.Builder().setWidth(DimensionBuilders.dp(w)).build()

    private fun layout(): LayoutElementBuilders.LayoutElement {
        val white = Color.WHITE
        val acc = Link.acc
        val onAcc = if ((0.299f * Color.red(acc) + 0.587f * Color.green(acc) + 0.114f * Color.blue(acc)) > 150f) 0xFF101114.toInt() else Color.WHITE
        val openClick = ModifiersBuilders.Clickable.Builder()
            .setId("open")
            .setOnClick(
                ActionBuilders.LaunchAction.Builder()
                    .setAndroidActivity(
                        ActionBuilders.AndroidActivity.Builder()
                            .setPackageName(packageName)
                            .setClassName("app.nowplaying.watch.MainActivity")
                            .build()
                    )
                    .build()
            )
            .build()
        val col = LayoutElementBuilders.Column.Builder()
            .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
        if (!Link.gotState || !Link.hasSession) {
            col.addContent(
                LayoutElementBuilders.Box.Builder()
                    .setModifiers(ModifiersBuilders.Modifiers.Builder().setClickable(openClick).build())
                    .addContent(txt(if (Link.gotState) "Nothing playing" else "Open Now Playing", 16f, white))
                    .build()
            )
        } else {
            val title = if (Link.title.isEmpty()) "Playing" else Link.title
            col.addContent(
                LayoutElementBuilders.Column.Builder()
                    .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
                    .setModifiers(ModifiersBuilders.Modifiers.Builder().setClickable(openClick).build())
                    .addContent(txt(title, 16f, white))
                    .addContent(txt(Link.artist, 13f, 0xB3FFFFFF.toInt()))
                    .build()
            )
            col.addContent(LayoutElementBuilders.Spacer.Builder().setHeight(DimensionBuilders.dp(12f)).build())
            col.addContent(
                LayoutElementBuilders.Row.Builder()
                    .setVerticalAlignment(LayoutElementBuilders.VERTICAL_ALIGN_CENTER)
                    .addContent(btn("prev", "«", 0x33FFFFFF, white, 42f))
                    .addContent(gap(8f))
                    .addContent(btn("pp", if (Link.playing) "❚❚" else "▶", acc, onAcc, 54f))
                    .addContent(gap(8f))
                    .addContent(btn("next", "»", 0x33FFFFFF, white, 42f))
                    .build()
            )
        }
        return LayoutElementBuilders.Box.Builder()
            .setWidth(DimensionBuilders.expand())
            .setHeight(DimensionBuilders.expand())
            .setHorizontalAlignment(LayoutElementBuilders.HORIZONTAL_ALIGN_CENTER)
            .setVerticalAlignment(LayoutElementBuilders.VERTICAL_ALIGN_CENTER)
            .addContent(col.build())
            .build()
    }
}

/** Asks the tile to redraw whenever the phone sends new state. */
class TileRefresh : WearableListenerService() {
    override fun onDataChanged(events: DataEventBuffer) {
        try {
            TileService.getUpdater(applicationContext).requestUpdate(NowPlayingTile::class.java)
        } catch (e: Exception) {
        }
    }
}
