package app.nowplaying.watch

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt

/** The whole watch screen: page 0 is the player, page 1 is the visualizer (tap it for controls). */
class WatchView(ctx: Context) : View(ctx) {
    var onExit: () -> Unit = {}

    /** Called whenever the page changes (and to re-announce the current page). */
    var onPage: (Int) -> Unit = {}

    var page = 0
        private set

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bp = Paint(Paint.FILTER_BITMAP_FLAG)
    private val rect = RectF()
    private val rect2 = RectF()
    private val path = Path()
    private val viz = Viz(d)
    private val shM = Matrix()

    private var pageFrac = 0f
    private var lastNs = 0L
    private var ctlUntil = 0L
    private var volUntil = 0L
    private var seeking = false
    private var seekFrac = 0f
    private var lastVolSent = -1
    private var lastVolAt = 0L
    private var crownAcc = 0f
    private var marquee = false
    private var shArt: Bitmap? = null
    private var shader: BitmapShader? = null

    private class Hit(val x: Float, val y: Float, val r: Float, val tag: Int)

    private val hits = ArrayList<Hit>()
    private val hudZone = RectF()
    private val hudBar = RectF()

    // touch
    private var downX = 0f
    private var downY = 0f
    private var mode = 0                     // 0 none, 1 volume drag, 2 seek drag
    private var moved = false

    private val onLink: () -> Unit = { postInvalidateOnAnimation() }

    private val sendVolRun = Runnable {
        if (Link.vol != lastVolSent) {
            lastVolSent = Link.vol
            Link.cmd("vol:" + Link.vol)
        }
    }

    init {
        isFocusable = true
        isFocusableInTouchMode = true
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        Link.listeners.add(onLink)
        requestFocus()
        lastNs = 0L
    }

    override fun onDetachedFromWindow() {
        Link.listeners.remove(onLink)
        removeCallbacks(sendVolRun)
        super.onDetachedFromWindow()
    }

    fun goPage(n: Int) {
        if (n == page) return
        page = n
        onPage(n)
        invalidate()
    }

    // ------------------------------------------------------------------ helpers

    private fun al(x: Float): Int = (255f * x).toInt().coerceIn(0, 255)

    private fun withAlpha(c: Int, a: Float): Int = Color.argb(al(a), Color.red(c), Color.green(c), Color.blue(c))

    private fun isLight(c: Int): Boolean =
        (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) > 150f

    private fun fill(c: Int) {
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = c
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return (s / 60).toString() + ":" + (s % 60).toString().padStart(2, '0')
    }

    private fun addHit(x: Float, y: Float, r: Float, tag: Int) {
        hits.add(Hit(x, y, r, tag))
    }

    // ------------------------------------------------------------------ drawing

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val ns = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else ((ns - lastNs) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
        lastNs = ns
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val rad = min(w, h) / 2f
        val u = rad / 114f
        marquee = false
        hits.clear()

        pageFrac += (page - pageFrac) * min(1f, dt * 14f)
        if (abs(page - pageFrac) < 0.003f) pageFrac = page.toFloat()
        if (page == 1 || pageFrac > 0.01f) viz.update(dt, now)

        drawBackground(c, w, h)
        if (pageFrac < 0.995f) {
            c.save()
            c.translate(-pageFrac * w, 0f)
            drawPlayer(c, cx, cy, u, now)
            c.restore()
        }
        if (pageFrac > 0.005f) {
            c.save()
            c.translate((1f - pageFrac) * w, 0f)
            drawVizPage(c, cx, cy, u, now)
            c.restore()
        }
        drawRing(c, cx, cy, rad)
        drawDots(c, cx, cy, u)
        drawHud(c, cx, cy, u, now)

        val fast = page == 1 || pageFrac != page.toFloat() || volUntil > now || seeking || marquee
        if (fast) postInvalidateOnAnimation() else postInvalidateDelayed(250)
    }

    private fun drawBackground(c: Canvas, w: Float, h: Float) {
        p.shader = null
        c.drawColor(Link.dark)
        val art = Link.art
        val bl = Link.blur
        rect.set(0f, 0f, w, h)
        if (art != null) {
            bp.alpha = al(1f - pageFrac)
            c.drawBitmap(art, null, rect, bp)
            if (bl != null) {
                bp.alpha = al(pageFrac)
                c.drawBitmap(bl, null, rect, bp)
            }
            bp.alpha = 255
        } else {
            fill(withAlpha(Link.acc, 0.18f))
            c.drawCircle(w / 2f, h / 2f, w * 0.45f, p)
        }
        fill(withAlpha(Link.dark, 0.35f + 0.45f * Link.bgop.coerceIn(0, 100) / 100f))
        c.drawRect(rect, p)
        // darker at the top and bottom so the text and buttons stay readable
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, h * 0.38f, 0xB3000000.toInt(), 0x00000000, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h * 0.38f, p)
        p.shader = LinearGradient(0f, h * 0.62f, 0f, h, 0x00000000, 0xB3000000.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, h * 0.62f, w, h, p)
        p.shader = null
    }

    private fun drawRing(c: Canvas, cx: Float, cy: Float, rad: Float) {
        if (!Link.showProgress || Link.durationMs <= 0 || !Link.hasSession) return
        val frac = if (seeking) seekFrac else (Link.posNow().toFloat() / Link.durationMs).coerceIn(0f, 1f)
        val sw = (if (seeking) 6f else 3.2f) * d
        val rr = rad - 5f * d
        rect2.set(cx - rr, cy - rr, cx + rr, cy + rr)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = sw
        p.color = 0x33FFFFFF
        c.drawArc(rect2, -90f, 360f, false, p)
        p.color = Link.acc
        if (frac > 0.002f) c.drawArc(rect2, -90f, 360f * frac, false, p)
        p.style = Paint.Style.FILL
    }

    private fun drawDots(c: Canvas, cx: Float, cy: Float, u: Float) {
        val y = cy - 100f * u
        for (i in 0..1) {
            fill(if (i == page) 0xFFFFFFFF.toInt() else 0x55FFFFFF)
            c.drawCircle(cx + (i - 0.5f) * 11f * u, y, 2.6f * u, p)
        }
    }

    private fun textPaint(size: Float, bold: Boolean, a: Float = 1f): Paint {
        tp.reset()
        tp.isAntiAlias = true
        tp.textSize = size
        tp.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        tp.color = withAlpha(Link.textColor, a)
        return tp
    }

    private fun drawFit(c: Canvas, text: String, paint: Paint, cx: Float, y: Float, maxW: Float, now: Long) {
        val tw = paint.measureText(text)
        if (tw <= maxW) {
            c.drawText(text, cx - tw / 2f, y, paint)
            return
        }
        marquee = true
        val gap = 36f * d
        val period = tw + gap
        val off = ((now / 1000f) * 28f * d) % period
        c.save()
        c.clipRect(cx - maxW / 2f, y - paint.textSize * 1.1f, cx + maxW / 2f, y + paint.textSize * 0.4f)
        c.drawText(text, cx - maxW / 2f - off, y, paint)
        c.drawText(text, cx - maxW / 2f - off + period, y, paint)
        c.restore()
    }

    private fun drawCentered(c: Canvas, text: String, paint: Paint, cx: Float, y: Float) {
        c.drawText(text, cx - paint.measureText(text) / 2f, y, paint)
    }

    // ---- page 0: the player

    private fun drawPlayer(c: Canvas, cx: Float, cy: Float, u: Float, now: Long) {
        if (!Link.gotState || !Link.hasSession) {
            drawCentered(c, if (Link.gotState) "Nothing playing" else "Waiting for the phone", textPaint(17f * u, true), cx, cy)
            drawCentered(c, if (Link.gotState) "Start music on your phone" else "Open the phone app > Watch", textPaint(12f * u, false, 0.7f), cx, cy + 22f * u)
            return
        }
        drawFit(c, Link.title, textPaint(17f * u, Link.titleBold), cx, cy - 56f * u, 150f * u, now)
        drawFit(c, Link.artist, textPaint(13f * u, false, 0.8f), cx, cy - 36f * u, 150f * u, now)
        drawControlsBlock(c, cx, cy, u)
    }

    /** Prev / play / next, the time, and the like and volume buttons. */
    private fun drawControlsBlock(c: Canvas, cx: Float, cy: Float, u: Float) {
        val y = cy + 8f * u
        val big = Link.controlStyle == 0
        val onAcc = if (isLight(Link.acc)) 0xFF101114.toInt() else Color.WHITE
        val ico = if (big) onAcc else Color.WHITE
        // prev / next
        fill(Color.WHITE)
        icoSkip(c, cx - 62f * u, y, 11f * u, false)
        icoSkip(c, cx + 62f * u, y, 11f * u, true)
        addHit(cx - 62f * u, y, 28f * u, 1)
        addHit(cx + 62f * u, y, 28f * u, 3)
        // play / pause
        if (big) {
            fill(Link.acc)
            c.drawCircle(cx, y, 30f * u, p)
        }
        fill(ico)
        if (Link.playing) icoPause(c, cx, y, 14f * u) else icoPlay(c, cx + 2f * u, y, 14f * u)
        addHit(cx, y, 34f * u, 2)
        // time
        val dur = Link.durationMs
        if (dur > 0) {
            val paint = textPaint(11f * u, false, 0.75f)
            drawCentered(c, fmt(if (seeking) (seekFrac * dur).toLong() else Link.posNow()) + " / " + fmt(dur), paint, cx, cy + 55f * u)
        }
        // like + volume
        val by = cy + 82f * u
        val vx = if (Link.like > 0) cx + 34f * u else cx
        if (Link.like > 0) {
            icoHeart(c, cx - 34f * u, by, 9.5f * u, Link.like == 2)
            addHit(cx - 34f * u, by, 22f * u, 4)
        }
        fill(Color.WHITE)
        icoVol(c, vx, by, 9.5f * u)
        addHit(vx, by, 22f * u, 5)
    }

    // ---- page 1: the visualizer

    private fun drawVizPage(c: Canvas, cx: Float, cy: Float, u: Float, now: Long) {
        if (!Link.gotState || !Link.hasSession) {
            drawCentered(c, if (Link.gotState) "Nothing playing" else "Waiting for the phone", textPaint(17f * u, true), cx, cy)
            return
        }
        if (!Link.vizOn) {
            drawFit(c, Link.title, textPaint(15f * u, Link.titleBold), cx, cy - 56f * u, 150f * u, now)
            drawCentered(c, "Visualizer is off", textPaint(14f * u, true), cx, cy - 4f * u)
            val on = Link.acc
            rect.set(cx - 50f * u, cy + 12f * u, cx + 50f * u, cy + 44f * u)
            fill(on)
            c.drawRoundRect(rect, 16f * u, 16f * u, p)
            val pt = textPaint(14f * u, true)
            pt.color = if (isLight(on)) 0xFF101114.toInt() else Color.WHITE
            drawCentered(c, "Turn on", pt, cx, cy + 33f * u)
            addHit(cx, cy + 28f * u, 50f * u, 6)
            return
        }
        val circ = Link.style == 4
        val artR = 33f * u
        if (circ) {
            drawArtCircle(c, cx, cy, artR)
        }
        rect.set(cx - 92f * u, cy - 40f * u, cx + 92f * u, cy + 40f * u)
        viz.draw(c, rect, cx, cy, artR)
        drawFit(c, Link.title, textPaint(14f * u, Link.titleBold), cx, cy - 76f * u, 140f * u, now)
        drawFit(c, Link.artist, textPaint(11f * u, false, 0.8f), cx, cy - 62f * u, 140f * u, now)
        if (ctlUntil > now) {
            fill(0xA6000000.toInt())
            c.drawRect(cx - 400f * u, cy - 400f * u, cx + 400f * u, cy + 400f * u, p)
            drawFit(c, Link.title, textPaint(15f * u, Link.titleBold), cx, cy - 56f * u, 150f * u, now)
            drawFit(c, Link.artist, textPaint(12f * u, false, 0.8f), cx, cy - 38f * u, 150f * u, now)
            drawControlsBlock(c, cx, cy, u)
        }
    }

    private fun drawArtCircle(c: Canvas, cx: Float, cy: Float, r: Float) {
        val a = Link.art
        if (a == null) {
            fill(0x33FFFFFF)
            c.drawCircle(cx, cy, r, p)
            return
        }
        if (shArt !== a) {
            shArt = a
            shader = BitmapShader(a, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        }
        val sh = shader ?: return
        val sc = 2f * r / min(a.width, a.height)
        shM.reset()
        shM.setScale(sc, sc)
        shM.postTranslate(cx - a.width * sc / 2f, cy - a.height * sc / 2f)
        sh.setLocalMatrix(shM)
        p.style = Paint.Style.FILL
        p.shader = sh
        c.drawCircle(cx, cy, r, p)
        p.shader = null
    }

    // ---- volume overlay

    private fun drawHud(c: Canvas, cx: Float, cy: Float, u: Float, now: Long) {
        hudZone.set(cx - 100f * u, cy - 48f * u, cx + 100f * u, cy + 48f * u)
        hudBar.set(cx - 68f * u, cy + 8f * u, cx + 68f * u, cy + 24f * u)
        if (volUntil <= now) return
        rect.set(cx - 92f * u, cy - 42f * u, cx + 92f * u, cy + 42f * u)
        fill(0xE6000000.toInt())
        c.drawRoundRect(rect, 24f * u, 24f * u, p)
        val frac = (Link.vol.toFloat() / Link.volMax).coerceIn(0f, 1f)
        fill(Color.WHITE)
        icoVol(c, cx - 56f * u, cy - 16f * u, 9f * u)
        drawCentered(c, (frac * 100f).roundToInt().toString() + "%", textPaint(18f * u, true).also { it.color = Color.WHITE }, cx + 8f * u, cy - 9f * u)
        fill(0x44FFFFFF)
        c.drawRoundRect(hudBar, 8f * u, 8f * u, p)
        rect2.set(hudBar.left, hudBar.top, hudBar.left + hudBar.width() * frac, hudBar.bottom)
        fill(Link.acc)
        c.drawRoundRect(rect2, 8f * u, 8f * u, p)
    }

    // ------------------------------------------------------------------ icons (paint color set by the caller)

    private fun icoPlay(c: Canvas, x: Float, y: Float, s: Float) {
        path.reset()
        path.moveTo(x - s * 0.6f, y - s)
        path.lineTo(x + s * 1.0f, y)
        path.lineTo(x - s * 0.6f, y + s)
        path.close()
        c.drawPath(path, p)
    }

    private fun icoPause(c: Canvas, x: Float, y: Float, s: Float) {
        rect.set(x - s * 0.75f, y - s, x - s * 0.2f, y + s)
        c.drawRoundRect(rect, s * 0.12f, s * 0.12f, p)
        rect.set(x + s * 0.2f, y - s, x + s * 0.75f, y + s)
        c.drawRoundRect(rect, s * 0.12f, s * 0.12f, p)
    }

    private fun icoSkip(c: Canvas, x: Float, y: Float, s: Float, next: Boolean) {
        val k = if (next) 1f else -1f
        path.reset()
        path.moveTo(x - k * s * 0.8f, y - s * 0.8f)
        path.lineTo(x + k * s * 0.5f, y)
        path.lineTo(x - k * s * 0.8f, y + s * 0.8f)
        path.close()
        c.drawPath(path, p)
        val bx = x + k * s * 0.75f
        rect.set(bx - s * 0.15f, y - s * 0.8f, bx + s * 0.15f, y + s * 0.8f)
        c.drawRoundRect(rect, s * 0.1f, s * 0.1f, p)
    }

    private fun icoHeart(c: Canvas, x: Float, y: Float, s: Float, on: Boolean) {
        path.reset()
        path.moveTo(x, y + s * 0.9f)
        path.cubicTo(x - s * 1.5f, y - s * 0.1f, x - s * 0.7f, y - s * 1.2f, x, y - s * 0.35f)
        path.cubicTo(x + s * 0.7f, y - s * 1.2f, x + s * 1.5f, y - s * 0.1f, x, y + s * 0.9f)
        path.close()
        p.shader = null
        if (on) {
            p.style = Paint.Style.FILL
            p.color = Link.acc
        } else {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2.2f * d
            p.strokeJoin = Paint.Join.ROUND
            p.color = Color.WHITE
        }
        c.drawPath(path, p)
        p.style = Paint.Style.FILL
    }

    private fun icoVol(c: Canvas, x: Float, y: Float, s: Float) {
        path.reset()
        path.moveTo(x - s * 1.0f, y - s * 0.35f)
        path.lineTo(x - s * 0.45f, y - s * 0.35f)
        path.lineTo(x + s * 0.15f, y - s * 0.85f)
        path.lineTo(x + s * 0.15f, y + s * 0.85f)
        path.lineTo(x - s * 0.45f, y + s * 0.35f)
        path.lineTo(x - s * 1.0f, y + s * 0.35f)
        path.close()
        p.style = Paint.Style.FILL
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.8f * d
        p.strokeCap = Paint.Cap.ROUND
        rect.set(x + s * 0.15f - s * 0.5f, y - s * 0.5f, x + s * 0.15f + s * 0.5f, y + s * 0.5f)
        c.drawArc(rect, -45f, 90f, false, p)
        rect.set(x + s * 0.15f - s * 0.95f, y - s * 0.95f, x + s * 0.15f + s * 0.95f, y + s * 0.95f)
        c.drawArc(rect, -45f, 90f, false, p)
        p.style = Paint.Style.FILL
    }

    // ------------------------------------------------------------------ volume

    private fun setVol(v: Int) {
        Link.vol = v.coerceIn(0, Link.volMax)
        Link.volLockUntil = SystemClock.uptimeMillis() + 900
        val now = SystemClock.uptimeMillis()
        removeCallbacks(sendVolRun)
        if (Link.vol != lastVolSent && now - lastVolAt > 110) {
            lastVolAt = now
            lastVolSent = Link.vol
            Link.cmd("vol:" + Link.vol)
        } else {
            postDelayed(sendVolRun, 90)
        }
        volUntil = now + 2600
        invalidate()
    }

    override fun onGenericMotionEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_SCROLL && ev.isFromSource(InputDevice.SOURCE_ROTARY_ENCODER)) {
            crownAcc += -ev.getAxisValue(MotionEvent.AXIS_SCROLL)
            var steps = 0
            while (crownAcc >= 0.8f) { crownAcc -= 0.8f; steps++ }
            while (crownAcc <= -0.8f) { crownAcc += 0.8f; steps-- }
            if (steps != 0) setVol(Link.vol + steps)
            return true
        }
        return super.onGenericMotionEvent(ev)
    }

    // ------------------------------------------------------------------ touch

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val now = SystemClock.uptimeMillis()
        val cx = width / 2f
        val cy = height / 2f
        val rad = min(width, height) / 2f
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = ev.x
                downY = ev.y
                moved = false
                mode = 0
                if (volUntil > now && hudZone.contains(ev.x, ev.y)) {
                    mode = 1
                    volFromX(ev.x)
                } else if (Link.showProgress && Link.durationMs > 0 && Link.hasSession &&
                    hypot(ev.x - cx, ev.y - cy) > rad - 26f * d && abs(ev.y - cy) > rad * 0.45f
                ) {
                    mode = 2
                    seeking = true
                    seekFromPoint(ev.x, ev.y, cx, cy)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == 1) {
                    volFromX(ev.x)
                } else if (mode == 2) {
                    seekFromPoint(ev.x, ev.y, cx, cy)
                } else if (abs(ev.x - downX) > 10f * d || abs(ev.y - downY) > 10f * d) {
                    moved = true
                }
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                val dx = ev.x - downX
                val dy = ev.y - downY
                if (mode == 1) {
                    volUntil = now + 2000
                } else if (mode == 2) {
                    seeking = false
                    val ms = (seekFrac * Link.durationMs).toLong()
                    Link.seekLocal(ms)
                    Link.cmd("seek:$ms")
                } else if (moved && abs(dx) > 46f * d && abs(dx) > abs(dy) * 1.3f) {
                    if (dx < 0) {
                        if (page == 0) goPage(1)
                    } else {
                        if (page == 1) goPage(0) else onExit()
                    }
                } else if (!moved) {
                    tap(ev.x, ev.y, now)
                }
                mode = 0
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                seeking = false
                mode = 0
                invalidate()
            }
        }
        return true
    }

    private fun volFromX(x: Float) {
        val f = ((x - hudBar.left) / hudBar.width()).coerceIn(0f, 1f)
        setVol((f * Link.volMax).roundToInt())
    }

    private fun seekFromPoint(x: Float, y: Float, cx: Float, cy: Float) {
        var a = Math.toDegrees(atan2((y - cy).toDouble(), (x - cx).toDouble())).toFloat() + 90f
        if (a < 0f) a += 360f
        seekFrac = (a / 360f).coerceIn(0f, 1f)
    }

    private fun tap(x: Float, y: Float, now: Long) {
        var tag = 0
        for (h in hits) {
            if (hypot(x - h.x, y - h.y) <= h.r) {
                tag = h.tag
                break
            }
        }
        if (tag == 0) {
            if (page == 1 && Link.vizOn) ctlUntil = if (ctlUntil > now) 0L else now + 5000
            return
        }
        if (page == 1) ctlUntil = now + 5000
        when (tag) {
            1 -> Link.cmd("prev")
            2 -> {
                Link.toggleLocal()
                Link.cmd("pp")
            }
            3 -> Link.cmd("next")
            4 -> {
                Link.like = if (Link.like == 2) 1 else 2
                Link.cmd("like")
            }
            5 -> volUntil = now + 3000
            6 -> {
                Link.cmd("viz:1")
                postDelayed({ onPage(page) }, 700)
            }
        }
    }
}
