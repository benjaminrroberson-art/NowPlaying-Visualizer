package app.nowplaying.watch

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** The watch's visualizer drawing: the same four styles as the phone, driven by the frames the phone streams. */
class Viz(private val d: Float) {
    private val smD = FloatArray(32)
    private val smW = FloatArray(48)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()
    private var hue = 0f
    private var rot = 0f
    private var level = 0f

    fun update(dt: Float, now: Long) {
        val f = Link.frame(now)
        val fall = Link.fall.coerceIn(10, 400) / 100f
        val up = 1f - exp(-dt / 0.03f)
        val down = 1f - exp(-dt / (0.18f / fall))
        for (i in 0 until 32) {
            val t = if (f != null) f.bands[i] else 0f
            smD[i] += (t - smD[i]) * (if (t > smD[i]) up else down)
        }
        val wk = 1f - exp(-dt / (0.03f / fall.coerceAtLeast(0.2f)))
        for (j in 0 until 48) {
            val t = if (f != null) f.wave[j] else 0f
            smW[j] += (t - smW[j]) * wk
        }
        val lv = if (f != null) f.level else 0f
        level += (lv - level) * min(1f, dt * 12f)
        hue = (hue + dt * 40f) % 360f
        rot = (rot + dt * 10f) % 360f
    }

    // ------------------------------------------------------------------ colors

    private fun lerp(a: Int, b: Int, t: Float): Int = Color.argb(
        (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * t).toInt(),
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    private fun palette(t: Float): Int {
        val pal = Link.pal
        val n = pal.size
        if (n < 2) return Link.acc
        val x = t.coerceIn(0f, 1f) * n
        val i = x.toInt()
        return lerp(pal[i % n], pal[(i + 1) % n], x - i)
    }

    private fun col(t: Float): Int {
        val tt = t.coerceIn(0f, 1f)
        return when (Link.cm) {
            0 -> Link.c1
            1 -> lerp(Link.c1, Link.c2, tt)
            2 -> lerp(Link.acc, Link.acc2, tt)
            4 -> palette(tt)
            else -> Color.HSVToColor(floatArrayOf((hue + tt * 300f) % 360f, 0.72f, 1f))
        }
    }

    private fun al(x: Float): Int = (255f * x).toInt().coerceIn(0, 255)

    private fun withAlpha(c: Int, a: Float): Int = Color.argb(al(a), Color.red(c), Color.green(c), Color.blue(c))

    private fun hGrad(x0: Float, x1: Float): Shader {
        val cols = IntArray(6) { col(it / 5f) }
        return LinearGradient(x0, 0f, x1, 0f, cols, null, Shader.TileMode.CLAMP)
    }

    // ------------------------------------------------------------------ levels

    private fun gate(v: Float): Float {
        val thr = (100 - Link.sens).coerceIn(0, 100) / 100f * 0.5f
        return if (thr <= 0f) v else ((v - thr) / (1f - thr)).coerceAtLeast(0f)
    }

    private fun waveGate(): Float {
        val thr = (100 - Link.sens).coerceIn(0, 100) / 100f * 0.25f
        return if (thr <= 0f) 1f else ((level - thr * 0.5f) / 0.08f).coerceIn(0f, 1f)
    }

    private fun bandS(i: Int, n: Int): Float {
        val a = i * 32 / n
        val b = max(a + 1, (i + 1) * 32 / n)
        var s = 0f
        for (k in a until min(b, 32)) s += smD[k]
        return s / (min(b, 32) - a)
    }

    private fun levelAt(i: Int, n: Int): Float = gate(bandS(i, n))

    private fun lowMode(): Int = Link.low.coerceIn(0, 3)

    private fun vertMode(): Int = Link.vert.coerceIn(0, 2)

    private inline fun eachSlot(n: Int, f: (Int, Int, Int) -> Unit) {
        when (lowMode()) {
            0 -> for (i in 0 until n) f(i, n, i)
            1 -> for (i in 0 until n) f(i, n, n - 1 - i)
            else -> {
                val m = n / 2
                val centre = lowMode() == 2
                for (i in 0 until m) {
                    if (centre) { f(i, m, m + i); f(i, m, m - 1 - i) } else { f(i, m, i); f(i, m, n - 1 - i) }
                }
            }
        }
    }

    private fun spec(u: Float): Float = when (lowMode()) {
        0 -> u
        1 -> 1f - u
        2 -> abs(2f * u - 1f)
        else -> 1f - abs(2f * u - 1f)
    }

    // ------------------------------------------------------------------ drawing

    /** Strip styles use [r]; the circular style draws around (cx, cy) outside radius [artR]. */
    fun draw(c: Canvas, r: RectF, cx: Float, cy: Float, artR: Float) {
        val a = Link.vop / 100f
        p.shader = null
        p.style = Paint.Style.FILL
        when (Link.style) {
            0 -> drawBars(c, r, a)
            2 -> drawScope(c, r, a)
            3 -> drawFilled(c, r, a)
            else -> drawRadial(c, cx, cy, artR, a)
        }
    }

    private fun drawBars(c: Canvas, r: RectF, a: Float) {
        var n = Link.bars.coerceIn(8, 48)
        if (lowMode() >= 2) n = (n / 2) * 2
        val vert = vertMode()
        val base = when (vert) {
            0 -> r.bottom
            1 -> r.top
            else -> r.centerY()
        }
        val hh = when (vert) {
            0 -> r.height()
            1 -> r.height()
            else -> r.height() / 2f
        } * Link.reach.coerceIn(10, 100) / 100f
        val pitch = r.width() / n
        val bw = max(pitch * 0.62f, 2f)
        eachSlot(n) { i, cnt, slot ->
            val v = levelAt(i, cnt).coerceIn(0f, 1.1f)
            val bh = max(bw, v * hh)
            val x = r.left + pitch * slot + (pitch - bw) / 2f
            p.color = withAlpha(col(i / (cnt - 1f).coerceAtLeast(1f)), a)
            when (vert) {
                0 -> rect.set(x, base - bh, x + bw, base)
                1 -> rect.set(x, base, x + bw, base + bh)
                else -> rect.set(x, base - bh, x + bw, base + bh)
            }
            c.drawRoundRect(rect, bw / 2f, bw / 2f, p)
        }
    }

    private fun smoothPath(pts: Int, xAt: (Int) -> Float, yAt: (Int) -> Float) {
        path.reset()
        path.moveTo(xAt(0), yAt(0))
        for (j in 1 until pts) {
            val mx = (xAt(j - 1) + xAt(j)) / 2f
            val my = (yAt(j - 1) + yAt(j)) / 2f
            path.quadTo(xAt(j - 1), yAt(j - 1), mx, my)
        }
        path.lineTo(xAt(pts - 1), yAt(pts - 1))
    }

    private fun drawScope(c: Canvas, r: RectF, a: Float) {
        val yc = r.centerY()
        val half = r.height() / 2f * 0.92f
        val pts = 48
        val gain = (Link.reach / 100f).coerceIn(0.1f, 1.2f) * waveGate()
        val flip = if (vertMode() == 1) -1f else 1f
        smoothPath(pts, { r.left + r.width() * it / (pts - 1f) }, { yc - flip * (smW[it] * gain).coerceIn(-1f, 1f) * half })
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.shader = hGrad(r.left, r.right)
        if (Link.glow) {
            p.strokeWidth = 9f * d; p.alpha = al(a * 0.10f); c.drawPath(path, p)
            p.strokeWidth = 5f * d; p.alpha = al(a * 0.20f); c.drawPath(path, p)
        }
        p.strokeWidth = 2.2f * d
        p.alpha = al(a)
        c.drawPath(path, p)
        p.shader = null
        p.alpha = 255
        p.style = Paint.Style.FILL
    }

    private fun drawFilled(c: Canvas, r: RectF, a: Float) {
        val pts = 40
        val vert = vertMode()
        val hh = (if (vert == 2) r.height() / 2f else r.height()) * 0.95f * Link.reach.coerceIn(10, 100) / 100f
        val yc = r.centerY()
        fun vAt(j: Int): Float {
            val x = spec(j / (pts - 1f)) * 31f
            val i = x.toInt().coerceIn(0, 30)
            val f = x - i
            return gate(smD[i] * (1f - f) + smD[i + 1] * f).coerceIn(0f, 1.1f)
        }
        val xAt = { j: Int -> r.left + r.width() * j / (pts - 1f) }
        val line = Path()
        val line2 = Path()
        val fill = Path()
        when (vert) {
            0 -> {
                smoothPath(pts, xAt) { r.bottom - max(2f * d, vAt(it) * hh) }
                line.set(path)
                path.lineTo(r.right, r.bottom); path.lineTo(r.left, r.bottom); path.close()
                fill.set(path)
            }
            1 -> {
                smoothPath(pts, xAt) { r.top + max(2f * d, vAt(it) * hh) }
                line.set(path)
                path.lineTo(r.right, r.top); path.lineTo(r.left, r.top); path.close()
                fill.set(path)
            }
            else -> {
                smoothPath(pts, xAt) { yc - max(1.5f * d, vAt(it) * hh) }
                line.set(path)
                smoothPath(pts, xAt) { yc + max(1.5f * d, vAt(it) * hh) }
                line2.set(path)
                fill.set(line)
                for (j in pts - 1 downTo 0) fill.lineTo(xAt(j), yc + max(1.5f * d, vAt(j) * hh))
                fill.close()
            }
        }
        p.shader = hGrad(r.left, r.right)
        p.style = Paint.Style.FILL
        p.alpha = al(a * 0.32f)
        c.drawPath(fill, p)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        if (Link.glow) {
            p.strokeWidth = 7f * d; p.alpha = al(a * 0.14f); c.drawPath(line, p)
            if (vert == 2) c.drawPath(line2, p)
        }
        p.strokeWidth = 2.2f * d
        p.alpha = al(a)
        c.drawPath(line, p)
        if (vert == 2) c.drawPath(line2, p)
        p.shader = null
        p.alpha = 255
        p.style = Paint.Style.FILL
    }

    private fun drawRadial(c: Canvas, cx: Float, cy: Float, artR: Float, a: Float) {
        val depth = Link.depth * d * 0.8f
        val r0 = artR + 4f * d
        val n = (Link.bars.coerceIn(8, 64) / 2) * 2
        val m = n / 2
        val bw = (6.2831855f * r0 / n * 0.55f).coerceIn(2f * d, 5f * d)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = bw
        c.save()
        c.translate(cx, cy)
        c.rotate(if (Link.spin) rot else 0f)
        for (k in 0 until m) {
            val v = levelAt(m - 1 - k, m).coerceIn(0f, 1.15f)
            val len = 3f * d + depth * v * (Link.reach.coerceIn(10, 100) / 100f)
            val ang = Math.toRadians((-90f + 180f * (k + 0.5f) / m).toDouble())
            val ca = cos(ang).toFloat()
            val sa = sin(ang).toFloat()
            p.color = withAlpha(col(k / (m - 1f).coerceAtLeast(1f)), a)
            c.drawLine(ca * r0, sa * r0, ca * (r0 + len), sa * (r0 + len), p)
            c.drawLine(-ca * r0, sa * r0, -ca * (r0 + len), sa * (r0 + len), p)
        }
        c.restore()
        p.style = Paint.Style.FILL
    }
}
