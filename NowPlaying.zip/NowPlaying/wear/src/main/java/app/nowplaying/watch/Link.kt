package app.nowplaying.watch

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.google.android.gms.wearable.DataClient
import com.google.android.gms.wearable.DataEvent
import com.google.android.gms.wearable.DataItem
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.MessageClient
import com.google.android.gms.wearable.Wearable

/** The watch's side of the link: what the phone last told us, plus a way to send it commands. */
object Link {
    class Frame(val t: Long, val bands: FloatArray, val wave: FloatArray, val level: Float, val beat: Float)

    // what is playing
    var gotState = false
    var hasSession = false
    var title = ""
    var artist = ""
    var playing = false
    var durationMs = 0L
    private var posMs = 0L
    private var posAt = 0L
    var vol = 0
    var volMax = 15
    var like = 0                       // 0 none, 1 can like, 2 liked
    var vizOn = false
    var delayMs = 0

    // look (from the phone)
    var style = 4
    var cm = 2
    var c1 = 0xFF00E5FF.toInt()
    var c2 = 0xFFFF4081.toInt()
    var acc = 0xFF00E5FF.toInt()
    var acc2 = 0xFFFF4081.toInt()
    var dark = 0xFF14161A.toInt()
    var pal = intArrayOf(0xFF00E5FF.toInt(), 0xFFFF4081.toInt(), 0xFFFFD740.toInt(), 0xFF69F0AE.toInt())
    var bars = 32
    var sens = 90
    var reach = 100
    var fall = 100
    var vert = 0
    var low = 0
    var depth = 26
    var glow = true
    var spin = true
    var vop = 95
    var textColor = 0xFFFFFFFF.toInt()
    var titleBold = true
    var controlStyle = 0
    var showProgress = true
    var bgop = 88
    var blurAmount = 60

    var art: Bitmap? = null
    var blur: Bitmap? = null
    private var artSig = -1

    /** While set (uptime ms), the phone's volume is ignored so it doesn't fight a drag in progress. */
    @Volatile
    var volLockUntil = 0L

    val listeners = ArrayList<() -> Unit>()

    private val main = Handler(Looper.getMainLooper())
    private var app: Context? = null
    private var nodes: List<String> = emptyList()
    private var nodesAt = 0L
    private val queue = ArrayDeque<Frame>()
    private var started = false
    private var needHello = true

    private fun fire() {
        for (l in ArrayList(listeners)) l()
    }

    // ------------------------------------------------------------------ lifecycle

    private val dataListener = DataClient.OnDataChangedListener { buf ->
        for (e in buf) {
            if (e.type != DataEvent.TYPE_CHANGED) continue
            when (e.dataItem.uri.path) {
                "/np/state" -> readState(e.dataItem)
                "/np/art" -> readArt(e.dataItem)
            }
        }
    }

    private val msgListener = MessageClient.OnMessageReceivedListener { ev ->
        if (ev.path == "/np/viz") onViz(ev.data)
    }

    fun start(ctx: Context) {
        val a = ctx.applicationContext
        app = a
        if (started) return
        started = true
        try {
            Wearable.getDataClient(a).addListener(dataListener)
            Wearable.getMessageClient(a).addListener(msgListener)
        } catch (e: Exception) {
        }
        fetch("/np/state") { readState(it) }
        fetch("/np/art") { readArt(it) }
        needHello = true
        refreshNodes(true)
    }

    fun stop() {
        val a = app ?: return
        if (!started) return
        started = false
        try {
            Wearable.getDataClient(a).removeListener(dataListener)
            Wearable.getMessageClient(a).removeListener(msgListener)
        } catch (e: Exception) {
        }
        queue.clear()
    }

    private fun fetch(path: String, f: (DataItem) -> Unit) {
        val a = app ?: return
        try {
            val uri = Uri.Builder().scheme("wear").path(path).build()
            Wearable.getDataClient(a).getDataItems(uri).addOnSuccessListener { buf ->
                try {
                    for (item in buf) f(item)
                } finally {
                    buf.release()
                }
            }
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------ reading what the phone sent

    private fun readState(item: DataItem) {
        val m = DataMapItem.fromDataItem(item).dataMap
        gotState = true
        hasSession = m.getBoolean("has", false)
        title = m.getString("t", "")
        artist = m.getString("a", "")
        playing = m.getBoolean("pl", false)
        durationMs = m.getLong("dur", 0L)
        posMs = m.getLong("pos", 0L)
        posAt = SystemClock.elapsedRealtime()
        if (SystemClock.uptimeMillis() > volLockUntil) vol = m.getInt("vol", 0)
        volMax = m.getInt("vmax", 15).coerceAtLeast(1)
        like = m.getInt("like", 0)
        vizOn = m.getBoolean("viz", false)
        delayMs = m.getInt("delay", 0)
        style = m.getInt("style", 4)
        cm = m.getInt("cm", 2)
        c1 = m.getInt("c1", c1)
        c2 = m.getInt("c2", c2)
        acc = m.getInt("acc", acc)
        acc2 = m.getInt("acc2", acc2)
        dark = m.getInt("dark", dark)
        val pl = m.getIntegerArrayList("pal")
        if (pl != null && pl.size >= 2) pal = pl.toIntArray()
        bars = m.getInt("bars", 32)
        sens = m.getInt("sens", 90)
        reach = m.getInt("reach", 100)
        fall = m.getInt("fall", 100)
        vert = m.getInt("vert", 0)
        low = m.getInt("low", 0)
        depth = m.getInt("depth", 26)
        glow = m.getBoolean("glow", true)
        spin = m.getBoolean("spin", true)
        vop = m.getInt("vop", 95)
        textColor = m.getInt("tc", textColor)
        titleBold = m.getBoolean("tb", true)
        controlStyle = m.getInt("cs", 0)
        showProgress = m.getBoolean("prog", true)
        bgop = m.getInt("bgop", 88)
        blurAmount = m.getInt("blur", 60)
        fire()
    }

    private fun readArt(item: DataItem) {
        val m = DataMapItem.fromDataItem(item).dataMap
        val sig = m.getInt("sig", 0)
        val asset = m.getAsset("img")
        if (asset == null) {
            art = null
            blur = null
            artSig = sig
            fire()
            return
        }
        if (sig == artSig && art != null) return
        val a = app ?: return
        try {
            Wearable.getDataClient(a).getFdForAsset(asset).addOnSuccessListener { r ->
                Thread {
                    var bmp: Bitmap? = null
                    try { bmp = BitmapFactory.decodeStream(r.inputStream) } catch (e: Exception) {}
                    try { r.release() } catch (e: Exception) {}
                    var bl: Bitmap? = null
                    if (bmp != null) {
                        try { bl = SoftBlur.make(bmp, blurAmount, 96) } catch (e: Exception) {}
                    }
                    main.post {
                        art = bmp
                        blur = bl
                        artSig = sig
                        fire()
                    }
                }.start()
            }
        } catch (e: Exception) {
        }
    }

    private fun onViz(d: ByteArray) {
        if (d.size < 83) return
        val bands = FloatArray(32) { (d[3 + it].toInt() and 0xFF) / 255f * 1.2f }
        val wave = FloatArray(48) { ((d[35 + it].toInt() and 0xFF) / 255f) * 2f - 1f }
        val level = (d[1].toInt() and 0xFF) / 255f
        val beat = (d[2].toInt() and 0xFF) / 255f
        queue.addLast(Frame(SystemClock.uptimeMillis(), bands, wave, level, beat))
        while (queue.size > 60) queue.removeFirst()
        fire()
    }

    /** The visualizer frame to show right now (held back by the delay setting), or null if none is fresh. */
    fun frame(now: Long): Frame? {
        val cut = now - delayMs
        while (queue.size > 1 && queue[1].t <= cut) queue.removeFirst()
        val head = queue.firstOrNull() ?: return null
        if (head.t > cut) return null
        if (cut - head.t > 700) return null
        return head
    }

    fun posNow(): Long {
        if (!playing) return posMs
        val p = posMs + (SystemClock.elapsedRealtime() - posAt)
        return if (durationMs > 0) minOf(p, durationMs) else p
    }

    /** Flips play/pause on screen right away (the phone's answer follows). */
    fun toggleLocal() {
        posMs = posNow()
        posAt = SystemClock.elapsedRealtime()
        playing = !playing
    }

    fun seekLocal(ms: Long) {
        posMs = ms
        posAt = SystemClock.elapsedRealtime()
    }

    // ------------------------------------------------------------------ sending

    private fun refreshNodes(force: Boolean) {
        val a = app ?: return
        val now = SystemClock.uptimeMillis()
        if (!force && now - nodesAt < 15000) return
        nodesAt = now
        try {
            Wearable.getNodeClient(a).connectedNodes.addOnSuccessListener { list ->
                nodes = list.map { it.id }
                if (nodes.isEmpty()) nodesAt = SystemClock.uptimeMillis() - 10000
                else if (needHello) {
                    needHello = false
                    send("/np/hello", ByteArray(0))
                }
            }
        } catch (e: Exception) {
        }
    }

    fun send(path: String, data: ByteArray) {
        val a = app ?: return
        if (nodes.isEmpty()) {
            refreshNodes(false)
            return
        }
        for (n in nodes) {
            try {
                Wearable.getMessageClient(a).sendMessage(n, path, data)
            } catch (e: Exception) {
            }
        }
    }

    fun cmd(s: String) = send("/np/cmd", s.toByteArray(Charsets.UTF_8))

    /** For the tile: reads the latest state from the data layer, then calls [done] (also when nothing could be read). */
    fun loadState(ctx: Context, done: () -> Unit) {
        val a = ctx.applicationContext
        app = a
        try {
            val uri = Uri.Builder().scheme("wear").path("/np/state").build()
            Wearable.getDataClient(a).getDataItems(uri)
                .addOnSuccessListener { buf ->
                    try {
                        for (item in buf) readState(item)
                    } finally {
                        buf.release()
                    }
                    done()
                }
                .addOnFailureListener { done() }
        } catch (e: Exception) {
            done()
        }
    }

    /** Looks up the phone and sends one message (used by the tile, where nothing has connected yet). */
    fun sendAsync(ctx: Context, path: String, data: ByteArray) {
        val a = ctx.applicationContext
        try {
            Wearable.getNodeClient(a).connectedNodes.addOnSuccessListener { list ->
                for (n in list) {
                    try {
                        Wearable.getMessageClient(a).sendMessage(n.id, path, data)
                    } catch (e: Exception) {
                    }
                }
            }
        } catch (e: Exception) {
        }
    }
}
