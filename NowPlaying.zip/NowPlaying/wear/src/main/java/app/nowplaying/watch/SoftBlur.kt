package app.nowplaying.watch

import android.graphics.Bitmap

/** Smooth, soft blur: shrink the picture, run a few box blurs (close to a gaussian), and let the caller scale it up. */
object SoftBlur {
    /** amount 0..100. Returns a small blurred square; draw it scaled up with bitmap filtering on. */
    fun make(src: Bitmap, amount: Int, size: Int = 128): Bitmap {
        val mid = Bitmap.createScaledBitmap(src, size * 2, size * 2, true)
        val b = Bitmap.createScaledBitmap(mid, size, size, true).copy(Bitmap.Config.ARGB_8888, true)
        val r = (2 + amount.coerceIn(0, 100) / 100f * 12f).toInt()
        val px = IntArray(size * size)
        b.getPixels(px, 0, size, 0, 0, size, size)
        repeat(3) {
            pass(px, size, size, r, true)
            pass(px, size, size, r, false)
        }
        b.setPixels(px, 0, size, 0, 0, size, size)
        return b
    }

    private var scratch = IntArray(0)

    /** Blurs a mutable bitmap of any size in place (two box-blur rounds). */
    fun blurInPlace(b: Bitmap, r: Int) {
        val w = b.width
        val h = b.height
        if (scratch.size < w * h) scratch = IntArray(w * h)
        val px = scratch
        b.getPixels(px, 0, w, 0, 0, w, h)
        repeat(2) {
            pass(px, w, h, r, true)
            pass(px, w, h, r, false)
        }
        b.setPixels(px, 0, w, 0, 0, w, h)
    }

    private fun pass(px: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val len = if (horizontal) w else h
        val lines = if (horizontal) h else w
        val tmp = IntArray(len)
        val div = 2 * r + 1
        for (line in 0 until lines) {
            for (i in 0 until len) tmp[i] = px[if (horizontal) line * w + i else i * w + line]
            var sr = 0
            var sg = 0
            var sb = 0
            for (k in -r..r) {
                val c = tmp[k.coerceIn(0, len - 1)]
                sr += (c shr 16) and 255
                sg += (c shr 8) and 255
                sb += c and 255
            }
            for (i in 0 until len) {
                val o = if (horizontal) line * w + i else i * w + line
                px[o] = (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = tmp[(i + r + 1).coerceAtMost(len - 1)]
                val rem = tmp[(i - r).coerceAtLeast(0)]
                sr += ((add shr 16) and 255) - ((rem shr 16) and 255)
                sg += ((add shr 8) and 255) - ((rem shr 8) and 255)
                sb += (add and 255) - (rem and 255)
            }
        }
    }
}
