import java.io.File

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// When the build runs with a keystore (GitHub secrets), sign with it so every
// build has the same signature and updates install over the top.
val ksPath: String? = System.getenv("KEYSTORE_PATH")?.takeIf { File(it).length() > 0L }

android {
    namespace = "app.nowplaying"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.nowplaying"
        minSdk = 30
        targetSdk = 35
        versionCode = 22
        versionName = "3.3"
    }

    signingConfigs {
        if (ksPath != null) {
            create("fixed") {
                storeFile = file(ksPath)
                storePassword = System.getenv("KEYSTORE_PASS")
                keyAlias = "edge"
                keyPassword = System.getenv("KEYSTORE_PASS")
            }
        }
    }

    buildTypes {
        debug {
            if (ksPath != null) signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
