package app.nowplaying

import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** The "What's new" message. Shows once after an update, covering every version you skipped. */
object WhatsNew {
    class Entry(val code: Int, val name: String, val sections: List<Pair<String, List<String>>>)

    val entries = listOf(
        Entry(
            24, "3.5", listOf(
                "Look" to listOf(
                    "The settings screens have a new cleaner look: rounded cards, clearer section headings, accent buttons and sliders, and light and dark follow your phone. Nothing moved and no setting changed."
                )
            )
        ),
        Entry(
            23, "3.4", listOf(
                "Watch" to listOf(
                    "New Watch menu: connects to a Wear OS watch running the Now Playing watch app. The watch shows the song, album art, progress ring, play / skip, volume (the crown works too) and a like button when your music app has one.",
                    "The watch has an optional visualizer page that uses your own style, colors and settings. It only runs while that page is open on the watch."
                )
            )
        ),
        Entry(
            22, "3.3", listOf(
                "Visualizer" to listOf(
                    "Every visualizer style now remembers its own settings (colors, bars, sensitivity, reach, fall speed, direction and more). Your current settings were the starting point for each style.",
                    "The front page has style pickers for the panel, bubble and screen saver (or one picker for all three). \"Visualizer styles\" holds each style's own settings, and the panel, bubble and screen saver pages only hold opacity, height and similar graphic settings.",
                    "Sensitivity now means how quiet a sound can be and still move the visualizer (higher reacts to quieter sound). It no longer changes how tall things get.",
                    "New Reach setting: how much of the graphic's height the bars or wave may use. Height is now the total size of the graphic.",
                    "Screen saver visualizer opacity and height are its own settings; its custom-visualizer switch is gone."
                ),
                "Menus" to listOf(
                    "Reorganized: Visualizer, Floating Bubble, Panel and Screen Saver come first. Panel now holds looks and presets, the visualizer graphic, album art and background. Text & Controls are one menu.",
                    "Panel, bubble and screen saver each have their own style picker, in step with the front page."
                ),
                "Fixes" to listOf(
                    "Bubble filled wave now follows the direction and low-end settings.",
                    "Screen saver big visualizer fills the album art edge to edge.",
                    "Fall speed now works for every style and each surface (card, bubble, screen saver) has its own.",
                    "\"Mirrored bars\" is folded into Bars: set Direction to Mirrored and Low end to Center. Anyone using it was moved over."
                ),
                "Bubble" to listOf(
                    "With album art opacity at 0%, the dark tint behind the visualizer is gone too, so you can have a fully transparent bubble.",
                    "The bubble has its own visualizer bars and height."
                )
            )
        ),
        Entry(
            21, "3.2", listOf(
                "Visualizer" to listOf(
                    "New Fall speed slider: how fast the bars drop back after a peak.",
                    "New Direction (up, down, mirrored) and Low end (left, right, center, edges) options for the bar and wave styles, including a mirrored wave.",
                    "The timeline now sits above the visualizer on the card."
                ),
                "Screen saver" to listOf(
                    "Clock position now uses across/down sliders plus presets, so you can move it clear of the camera.",
                    "Art + visualizer layout can swap the two vertically.",
                    "Big visualizer layout now puts the visualizer inside the album art square.",
                    "Tapping the screen saver centers the controls and blurs the picture behind them."
                ),
                "Bubble" to listOf(
                    "Separate opacity for the visualizer, the album art and the border."
                ),
                "App" to listOf(
                    "Equalizer and Floating bubble settings sit right under their on/off switches on the front page.",
                    "What's new and the full-screen player are at the top of the front page.",
                    "Saved looks have an Update button after you change a loaded look.",
                    "Starting playback capture from the pop-up card no longer opens the app."
                )
            )
        ),
        Entry(
            20, "3.1", listOf(
                "Fixes" to listOf(
                    "Closing the screen saver now returns to your home screen.",
                    "The blurred background (card, player and screen saver) is a soft blur now, with no pixelated look.",
                    "Screen saver: \"Drift the picture\" is its own switch, separate from the blurred background."
                )
            )
        ),
        Entry(
            19, "3.0", listOf(
                "Equalizer" to listOf(
                    "A full parametric EQ for all your audio, including Bluetooth headphones: bell, shelf, high-pass and low-pass bands, plus post gain.",
                    "Import presets from Ozone (XML), APO or plain \"frequency gain Q\" text. Save your own, update a saved preset after editing it, or delete it.",
                    "Presets and imports now also set post gain.",
                    "EQ button on the card to switch presets or turn the EQ off.",
                    "Per-device presets: pick a preset for Bluetooth headphones, wired, USB or the phone speaker. It loads, and the EQ turns on, when you connect that output.",
                    "On Bluetooth the EQ works per app after a one-time permission. The Setup page explains how to grant it."
                ),
                "Visualizer" to listOf(
                    "Bluetooth: optional playback capture gets the visualizer moving when the phone won't give it sound. One confirm, with its own page explaining when you need it.",
                    "Now covers 20 Hz to 16 kHz with a built-in lift on the high end, so highs react as much as bass.",
                    "New multi-color album-art option for bars, lines and particles, on the card and the bubble. It pulls up to six real colors from the artwork.",
                    "The visualizer hides when there is no sound."
                ),
                "Card and panel" to listOf(
                    "Long titles, artists and albums scroll slowly. Set the speed in Text.",
                    "Clearer progress line with a dot at the current position.",
                    "Icon buttons no longer cover the song title."
                ),
                "Bubble" to listOf(
                    "Starts by itself and comes back after a reboot or update.",
                    "Hides while the music app or this app is open (needs Usage access).",
                    "Fling it sideways to tuck it into the screen edge.",
                    "Minimize to a dot: drag it onto the target that appears at the bottom, or tap the – button on the pop-up card. Tap to bring it back.",
                    "The visualizer now fills the bubble edge to edge."
                ),
                "Screen saver" to listOf(
                    "New: a charging screen saver with art + visualizer, big visualizer, clock + track, and visualizer-only layouts.",
                    "Quiet hours: switch the automatic screen saver off overnight on a schedule.",
                    "A Quick Settings tile starts it any time, even when not charging. Add \"Screen saver\" from the tile editor.",
                    "Tap for playback controls. Adjust brightness, clock position and size, album art size, burn-in protection (drift and/or a blurred album-art background), frame rate and its own visualizer look, with a live preview."
                ),
                "The app" to listOf(
                    "Menus reorganized: setup and main switches up front, everything else in sub-menus.",
                    "The card preview only shows where it's useful, and the bubble has its own preview.",
                    "Plain-language help for setup, the EQ permission and audio capture."
                )
            )
        )
    )

    private fun code(act: Activity): Int = try {
        act.packageManager.getPackageInfo(act.packageName, 0).longVersionCode.toInt()
    } catch (e: Exception) { Int.MAX_VALUE }

    private fun build(act: Activity, list: List<Entry>): ScrollView {
        val d = act.resources.displayMetrics.density
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * d).toInt(), (8 * d).toInt(), (20 * d).toInt(), (8 * d).toInt())
        }
        for (e in list) {
            if (list.size > 1) col.addView(TextView(act).apply {
                text = "Version " + e.name
                textSize = 18f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, (10 * d).toInt(), 0, 0)
            })
            for ((head, items) in e.sections) {
                col.addView(TextView(act).apply {
                    text = head
                    textSize = 15f
                    setTypeface(typeface, Typeface.BOLD)
                    setPadding(0, (12 * d).toInt(), 0, (2 * d).toInt())
                })
                for (it in items) col.addView(TextView(act).apply {
                    text = "•  " + it
                    textSize = 14f
                    setPadding(0, (3 * d).toInt(), 0, (3 * d).toInt())
                })
            }
        }
        return ScrollView(act).apply { addView(col) }
    }

    fun show(act: Activity, all: Boolean, p: Prefs) {
        val cur = code(act)
        val list = if (all) entries else entries.filter { it.code > p.seenVer }
        if (list.isEmpty()) return
        AlertDialog.Builder(act)
            .setTitle("What's new")
            .setView(build(act, list.sortedByDescending { it.code }))
            .setPositiveButton("Got it") { _, _ -> p.seenVer = cur }
            .setOnCancelListener { p.seenVer = cur }
            .show()
    }

    /** Called when the app opens: shows what changed since the last version this phone saw. */
    fun maybeShow(act: Activity, p: Prefs) {
        val cur = code(act)
        if (p.seenVer >= cur) return
        val fresh = try {
            val pi = act.packageManager.getPackageInfo(act.packageName, 0)
            pi.firstInstallTime == pi.lastUpdateTime
        } catch (e: PackageManager.NameNotFoundException) { false }
        if (fresh) {
            p.seenVer = cur
            return
        }
        show(act, false, p)
    }
}
