package app.nowplaying

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * The small floating bubble: mini album art with the visualizer around or on it. Tap, long-press
 * and drag are reported to the service, which owns the window.
 */
class BubbleView(context: Context, val prefs: Prefs) : View(context) {

    /** Own preferences reader so the bubble can look up the settings of its own visualizer style. */
    private val vp = Prefs(context)

    var onTap: (() -> Unit)? = null
    var onLong: (() -> Unit)? = null
    var onDrag: ((dx: Float, dy: Float) -> Unit)? = null
    var onRelease: (() -> Unit)? = null
    /** Called with the release velocity (px/s). Return true if the fling was used. */
    var onFling: ((vx: Float, vy: Float) -> Boolean)? = null
    private var vt: VelocityTracker? = null

    private val d = resources.displayMetrics.density
    private val sizePx = prefs.bubbleSize * d

    /** Room around the artwork for rings, glow and particles. */
    val inset = sizePx * 0.34f
    val totalPx = (sizePx + 2f * inset).toInt()

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val rect2 = RectF()
    private val path = Path()
    private val artPath = Path()
    private val src = Rect()
    private val rnd = java.util.Random(11)
    private var hue = 0f
    private var rot = 0f
    private var lastFrame = 0L
    private var lastBeat = 0
    private var held = false
    private var screenOn = true
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val uiHandler = Handler(Looper.getMainLooper())

    private val rAge = FloatArray(4) { 9f }
    private val pn = 50
    private val px = FloatArray(pn)
    private val py = FloatArray(pn)
    private val pvx = FloatArray(pn)
    private val pvy = FloatArray(pn)
    private val plife = FloatArray(pn)
    private val pmax = FloatArray(pn) { 1f }
    private val phue = FloatArray(pn)
    private var spawnAcc = 0f

    private val listener: () -> Unit = {
        syncAudio()
        invalidate()
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        setMeasuredDimension(totalPx, totalPx)
    }

    fun setScreenOn(on: Boolean) {
        screenOn = on
        syncAudio()
        if (on) invalidate()
    }

    private fun syncAudio() {
        val want = isAttachedToWindow && screenOn && MediaState.playing
        if (want && !held) {
            held = true
            Audio.start(context)
        } else if (!want && held) {
            held = false
            Audio.stop()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        MediaState.ensureStarted(context)
        MediaState.addListener(listener)
        lastFrame = SystemClock.uptimeMillis()
        syncAudio()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        MediaState.removeListener(listener)
        uiHandler.removeCallbacksAndMessages(null)
        if (held) {
            held = false
            Audio.stop()
        }
        super.onDetachedFromWindow()
    }

    // ------------------------------------------------------------------ colors

    private fun lerp(a: Int, b: Int, t: Float): Int = Color.argb(
        (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * t).toInt(),
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    private fun palette(t: Float): Int {
        val pal = MediaState.palette
        val n = pal.size
        if (n < 2) return MediaState.accent
        val x = t.coerceIn(0f, 1f) * n
        val i = x.toInt()
        return lerp(pal[i % n], pal[(i + 1) % n], x - i)
    }

    private fun vizCol(t: Float): Int {
        val tt = t.coerceIn(0f, 1f)
        return when (vp.vizColorMode) {
            0 -> vp.vizColor
            1 -> lerp(vp.vizColor, vp.vizColor2, tt)
            2 -> lerp(MediaState.accent, MediaState.accent2, tt)
            4 -> palette(tt)
            else -> Color.HSVToColor(floatArrayOf((hue + tt * 300f) % 360f, 0.72f, 1f))
        }
    }

    private fun hGradPaint(x0: Float, x1: Float, alpha: Float) {
        if (vp.vizColorMode == 0) {
            p.shader = null
            p.color = withAlpha(vp.vizColor, alpha)
            return
        }
        val cols = IntArray(9) { vizCol(it / 8f) }
        p.shader = LinearGradient(x0, 0f, x1, 0f, cols, null, Shader.TileMode.CLAMP)
        p.color = Color.argb(al(alpha), 255, 255, 255)
    }

    private fun al(x: Float): Int = (255f * x).toInt().coerceIn(0, 255)

    private fun withAlpha(c: Int, a: Float): Int =
        Color.argb(al(a), Color.red(c), Color.green(c), Color.blue(c))

    // ------------------------------------------------------------------ effects state

    private fun onBeat(style: Int, cx: Float, cy: Float, r: Float) {
        if (style == 5) {
            var idx = 0
            var oldest = -1f
            for (i in rAge.indices) if (rAge[i] > oldest) { oldest = rAge[i]; idx = i }
            rAge[idx] = 0f
        } else if (style == 6) {
            for (i in 0 until 6) spawn(cx, cy, r, 2.2f)
        }
    }

    private fun spawn(cx: Float, cy: Float, r: Float, mul: Float) {
        var idx = -1
        for (i in 0 until pn) if (plife[i] <= 0f) { idx = i; break }
        if (idx < 0) return
        val ang = rnd.nextFloat() * 6.2831855f
        val ca = cos(ang)
        val sa = sin(ang)
        val speed = (14f + rnd.nextFloat() * 34f) * d * mul
        px[idx] = cx + ca * r
        py[idx] = cy + sa * r
        pvx[idx] = ca * speed
        pvy[idx] = sa * speed
        pmax[idx] = 0.6f + rnd.nextFloat() * 0.7f
        plife[idx] = pmax[idx]
        phue[idx] = rnd.nextFloat()
    }

    private fun hasMotion(): Boolean {
        for (a in rAge) if (a < 1.1f) return true
        for (l in plife) if (l > 0f) return true
        return false
    }

    // ------------------------------------------------------------------ draw

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = ((now - lastFrame) / 1000f).coerceIn(0.001f, 0.05f)
        lastFrame = now
        vp.ov["vizStyle"] = prefs.bubbleStyle
        val sens = vp.vizReach / 100f
        Audio.gain = 1f
        Audio.fall = vp.vizFall / 100f
        Audio.update(false)
        hue = (hue + dt * 20f) % 360f
        if (vp.vizSpin) rot = (rot + dt * 6f) % 360f

        val style = prefs.bubbleStyle
        val cx = totalPx / 2f
        val cy = cx
        var r = sizePx / 2f
        val playing = MediaState.playing
        val a = prefs.bubbleVizOp / 100f

        if (Audio.beatCount != lastBeat) {
            lastBeat = Audio.beatCount
            onBeat(style, cx, cy, r)
        }
        for (i in rAge.indices) if (rAge[i] < 9f) rAge[i] += dt
        if (style == 6 && playing) {
            spawnAcc += dt * (4f + 40f * vp.gate(Audio.level) * sens)
            while (spawnAcc >= 1f) { spawnAcc -= 1f; spawn(cx, cy, r, 1f) }
        }
        for (i in 0 until pn) {
            if (plife[i] <= 0f) continue
            plife[i] -= dt
            px[i] += pvx[i] * dt
            py[i] += pvy[i] * dt
            pvx[i] *= 1f - 0.8f * dt
            pvy[i] *= 1f - 0.8f * dt
        }

        if (style == 5) r *= 1f + 0.06f * Audio.beatEnv + 0.03f * Audio.level
        val shape = prefs.bubbleShape
        val ringR = if (shape == 0) r + 3f * d else r * 1.12f + 3f * d
        val reach = max(4f * d, inset - (ringR - sizePx / 2f) - 2f * d)

        val sig = !Audio.noSignal()
        if (sig) when (style) {
            7 -> drawGlow(c, cx, cy, r, a)
            6 -> drawParticles(c, a)
            4 -> drawRing(c, cx, cy, ringR, reach, a)
            5 -> drawPulse(c, cx, cy, ringR, reach, a)
        }
        drawArt(c, cx, cy, r, shape)
        if (sig && style in 0..3) drawOverlay(c, cx, cy, r, style, a)
        if (!playing) drawPaused(c, cx, cy, r)
        if (flashT > 0f) {
            drawFlash(c, cx, cy, r)
            flashT -= dt / 0.7f
        }

        if (playing || Audio.active() || hasMotion() || flashT > 0f) postInvalidateOnAnimation()
    }

    private fun drawArt(c: Canvas, cx: Float, cy: Float, r: Float, shape: Int) {
        rect.set(cx - r, cy - r, cx + r, cy + r)
        val rr = when (shape) {
            0 -> r
            1 -> r * 0.42f
            else -> 4f * d
        }
        p.shader = null
        p.style = Paint.Style.FILL
        for (i in 0..2) {
            p.color = Color.argb((30 * prefs.bubbleArtOp / 100f).toInt(), 0, 0, 0)
            val g = (i + 1) * 1.6f * d
            rect2.set(rect.left - g, rect.top - g + 2f * d, rect.right + g, rect.bottom + g + 2f * d)
            c.drawRoundRect(rect2, rr + g, rr + g, p)
        }
        artPath.reset()
        artPath.addRoundRect(rect, rr, rr, Path.Direction.CW)
        c.save()
        c.clipPath(artPath)
        val art = MediaState.art
        if (art != null) {
            val s = min(art.width, art.height)
            src.set((art.width - s) / 2, (art.height - s) / 2, (art.width + s) / 2, (art.height + s) / 2)
            p.isFilterBitmap = true
            p.alpha = (255 * prefs.bubbleArtOp / 100f).toInt().coerceIn(0, 255)
            c.drawBitmap(art, src, rect, p)
            p.alpha = 255
        } else {
            p.shader = LinearGradient(
                rect.left, rect.top, rect.right, rect.bottom,
                MediaState.accent, MediaState.accent2, Shader.TileMode.CLAMP
            )
            p.alpha = (255 * prefs.bubbleArtOp / 100f).toInt().coerceIn(0, 255)
            c.drawRect(rect, p)
            p.alpha = 255
            p.shader = null
            p.typeface = Typeface.DEFAULT
            p.textAlign = Paint.Align.CENTER
            p.textSize = r * 0.95f
            p.color = withAlpha(Color.WHITE, 0.85f * prefs.bubbleArtOp / 100f)
            c.drawText("♪", cx, cy + r * 0.32f, p)
        }
        c.restore()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.4f * d
        p.color = withAlpha(Color.WHITE, 0.30f * prefs.bubbleBorderOp / 100f)
        c.drawRoundRect(rect, rr, rr, p)
        p.style = Paint.Style.FILL
    }

    private var flashT = 0f
    private var flashPlay = false

    /** Brief play / pause glyph over the art after a tap-to-toggle. */
    fun flashAction(willPlay: Boolean) {
        flashPlay = willPlay
        flashT = 1f
        lastFrame = SystemClock.uptimeMillis()
        invalidate()
    }

    private fun drawFlash(c: Canvas, cx: Float, cy: Float, r: Float) {
        val t = flashT.coerceIn(0f, 1f)
        val a = if (t > 0.75f) 1f else t / 0.75f
        val k = 1f + 0.25f * (1f - t)
        c.save()
        c.clipPath(artPath)
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = Color.argb((120 * a).toInt(), 0, 0, 0)
        c.drawRect(cx - r, cy - r, cx + r, cy + r, p)
        c.restore()
        p.color = withAlpha(Color.WHITE, 0.95f * a)
        val s = r * 0.46f * k
        if (flashPlay) {
            path.reset()
            path.moveTo(cx - s * 0.55f, cy - s)
            path.lineTo(cx + s * 0.95f, cy)
            path.lineTo(cx - s * 0.55f, cy + s)
            path.close()
            c.drawPath(path, p)
        } else {
            rect.set(cx - s * 0.62f, cy - s, cx - s * 0.16f, cy + s)
            c.drawRoundRect(rect, s * 0.12f, s * 0.12f, p)
            rect.set(cx + s * 0.16f, cy - s, cx + s * 0.62f, cy + s)
            c.drawRoundRect(rect, s * 0.12f, s * 0.12f, p)
        }
    }

    private fun buzz(type: Int) {
        if (!prefs.bubbleHaptic) return
        try { performHapticFeedback(type, HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING) } catch (e: Exception) {}
    }

    private fun drawPaused(c: Canvas, cx: Float, cy: Float, r: Float) {
        c.save()
        c.clipPath(artPath)
        p.shader = null
        p.color = Color.argb(110, 0, 0, 0)
        c.drawRect(cx - r, cy - r, cx + r, cy + r, p)
        c.restore()
        p.color = withAlpha(Color.WHITE, 0.92f)
        val s = r * 0.42f
        rect.set(cx - s * 0.62f, cy - s, cx - s * 0.16f, cy + s)
        c.drawRoundRect(rect, s * 0.12f, s * 0.12f, p)
        rect.set(cx + s * 0.16f, cy - s, cx + s * 0.62f, cy + s)
        c.drawRoundRect(rect, s * 0.12f, s * 0.12f, p)
    }

    private fun drawRing(c: Canvas, cx: Float, cy: Float, ringR: Float, reach: Float, a: Float) {
        val n = (prefs.bubbleBars.coerceIn(8, 64) / 2) * 2
        val m = n / 2
        val bw = (6.2831855f * ringR / n * 0.55f).coerceIn(1.5f * d, 4f * d)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = bw
        c.save()
        c.translate(cx, cy)
        c.rotate(if (vp.vizSpin) rot else 0f)
        for (k in 0 until m) {
            val v = vp.gate(Audio.band(m - 1 - k, m)).coerceIn(0f, 1.15f)
            val len = 2f * d + reach * v
            val ang = Math.toRadians((-90f + 180f * (k + 0.5f) / m).toDouble())
            val ca = cos(ang).toFloat()
            val sa = sin(ang).toFloat()
            p.color = withAlpha(vizCol(k / (m - 1f)), a)
            c.drawLine(ca * ringR, sa * ringR, ca * (ringR + len), sa * (ringR + len), p)
            c.drawLine(-ca * ringR, sa * ringR, -ca * (ringR + len), sa * (ringR + len), p)
        }
        c.restore()
        p.style = Paint.Style.FILL
    }

    private fun drawPulse(c: Canvas, cx: Float, cy: Float, ringR: Float, reach: Float, a: Float) {
        val be = Audio.beatEnv
        val lv = vp.gate(Audio.level) * (vp.vizReach / 100f)
        p.shader = RadialGradient(
            cx, cy, ringR + reach,
            intArrayOf(withAlpha(vizCol(0.3f), a * (0.30f + 0.35f * be)), 0x00000000),
            floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, ringR + reach, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.8f * d
        p.color = withAlpha(vizCol(0.1f), a * (0.55f + 0.4f * be))
        c.drawCircle(cx, cy, ringR + lv * 3f * d, p)
        for (i in rAge.indices) {
            val age = rAge[i]
            if (age >= 1.0f) continue
            val t = age / 1.0f
            val e = 1f - (1f - t) * (1f - t)
            p.strokeWidth = 2f * d
            p.color = withAlpha(vizCol(0.5f + 0.5f * t), a * 0.6f * (1f - t))
            c.drawCircle(cx, cy, ringR + reach * e, p)
        }
        p.style = Paint.Style.FILL
    }

    private fun drawGlow(c: Canvas, cx: Float, cy: Float, r: Float, a: Float) {
        val be = Audio.beatEnv
        val lv = vp.gate(Audio.level) * (vp.vizReach / 100f) * 2f
        val rad = (r + inset) * (0.8f + 0.1f * be + 0.1f * lv.coerceAtMost(1f))
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            cx, cy, rad,
            intArrayOf(withAlpha(vizCol(0.2f), a * (0.55f + 0.4f * be)), 0x00000000),
            floatArrayOf(0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, rad, p)
        p.shader = null
    }

    private fun drawParticles(c: Canvas, a: Float) {
        p.shader = null
        p.style = Paint.Style.FILL
        for (i in 0 until pn) {
            val life = plife[i]
            if (life <= 0f) continue
            val f = (life / pmax[i]).coerceIn(0f, 1f)
            p.color = withAlpha(vizCol(phue[i]), a * f)
            c.drawCircle(px[i], py[i], (1f + 1.6f * f) * d, p)
        }
    }

    private fun smoothPath(pts: Int, xAt: (Int) -> Float, yAt: (Int) -> Float) {
        path.reset()
        path.moveTo(xAt(0), yAt(0))
        for (j in 1 until pts) {
            val mx = (xAt(j - 1) + xAt(j)) / 2f
            val my = (yAt(j - 1) + yAt(j)) / 2f
            path.quadTo(xAt(j - 1), yAt(j - 1), mx, my)
        }
        path.lineTo(xAt(pts - 1), yAt(pts - 1))
    }

    /** Visualizer drawn on top of the artwork (clipped to its shape). */
    private fun drawOverlay(c: Canvas, cx: Float, cy: Float, r: Float, style: Int, a: Float) {
        c.save()
        c.clipPath(artPath)
        val x0 = cx - r
        val x1 = cx + r
        val bottom = cy + r
        val top = cy - r * 0.64f
        val hh = (bottom - top) * prefs.bubbleVizHeight / 100f
        val reachK = vp.vizReach.coerceIn(10, 100) / 100f
        p.shader = null
        p.style = Paint.Style.FILL
        if (style == 0 || style == 3) {
            p.shader = LinearGradient(
                0f, cy, 0f, cy + r, 0x00000000, Color.argb((136 * prefs.bubbleArtOp / 100f).toInt(), 0, 0, 0), Shader.TileMode.CLAMP
            )
            c.drawRect(cx - r, cy, cx + r, cy + r, p)
            p.shader = null
        } else {
            p.color = Color.argb((60 * prefs.bubbleArtOp / 100f).toInt(), 0, 0, 0)
            c.drawRect(cx - r, cy - r, cx + r, cy + r, p)
        }
        val n = (prefs.bubbleBars / 2).coerceIn(6, 24)
        when (style) {
            0 -> {
                val pitch = (x1 - x0) / n
                val bw = max(pitch * 0.64f, 1.5f * d)
                for (i in 0 until n) {
                    val v = vp.gate(Audio.band(i, n)).coerceIn(0f, 1.1f)
                    val bh = max(bw, v * hh * 0.62f * reachK)
                    val x = x0 + pitch * i + (pitch - bw) / 2f
                    p.color = withAlpha(vizCol(i / (n - 1f)), a)
                    rect.set(x, bottom - bh, x + bw, bottom)
                    c.drawRoundRect(rect, bw / 2f, bw / 2f, p)
                }
            }

            1 -> {
                val nn = (n / 2) * 2
                val m = nn / 2
                val pitch = (x1 - x0) / nn
                val bw = max(pitch * 0.64f, 1.5f * d)
                for (i in 0 until m) {
                    val v = vp.gate(Audio.band(i, m)).coerceIn(0f, 1.1f)
                    val bh = max(bw, v * hh * 0.8f * reachK)
                    p.color = withAlpha(vizCol(i / (m - 1f)), a)
                    for (side in 0..1) {
                        val x = if (side == 0) cx + i * pitch + (pitch - bw) / 2f else cx - (i + 1) * pitch + (pitch - bw) / 2f
                        rect.set(x, cy - bh / 2f, x + bw, cy + bh / 2f)
                        c.drawRoundRect(rect, bw / 2f, bw / 2f, p)
                    }
                }
            }

            2 -> {
                val pts = Audio.W
                val gain = (vp.vizReach / 100f).coerceIn(0.1f, 1.2f) * vp.waveGate(Audio.level)
                smoothPath(pts,
                    { x0 + (x1 - x0) * it / (pts - 1f) },
                    { cy - (Audio.wave[it] * gain).coerceIn(-1f, 1f) * hh * 0.42f })
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeJoin = Paint.Join.ROUND
                if (vp.vizGlow) {
                    p.strokeWidth = 5f * d
                    hGradPaint(x0, x1, a * 0.22f)
                    c.drawPath(path, p)
                }
                p.strokeWidth = 1.8f * d
                hGradPaint(x0, x1, a)
                c.drawPath(path, p)
                p.shader = null
                p.style = Paint.Style.FILL
            }

            else -> {
                val pts = 32
                smoothPath(pts,
                    { x0 + (x1 - x0) * it / (pts - 1f) },
                    {
                        val x = it * (Audio.N - 1f) / (pts - 1f)
                        val i = x.toInt().coerceIn(0, Audio.N - 2)
                        val f = x - i
                        val v = vp.gate(Audio.disp[i] * (1f - f) + Audio.disp[i + 1] * f)
                        bottom - max(1.5f * d, v.coerceIn(0f, 1.1f) * hh * 0.7f * reachK)
                    })
                val line = Path(path)
                path.lineTo(x1, bottom)
                path.lineTo(x0, bottom)
                path.close()
                hGradPaint(x0, x1, a * 0.35f)
                c.drawPath(path, p)
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = 1.8f * d
                hGradPaint(x0, x1, a)
                c.drawPath(line, p)
                p.shader = null
                p.style = Paint.Style.FILL
            }
        }
        c.restore()
    }

    // ------------------------------------------------------------------ touch

    private var downRawX = 0f
    private var downRawY = 0f
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var moved = false
    private var longFired = false
    private val longRun = Runnable {
        longFired = true
        buzz(HapticFeedbackConstants.LONG_PRESS)
        onLong?.invoke()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downRawX = e.rawX; downRawY = e.rawY
                lastRawX = e.rawX; lastRawY = e.rawY
                moved = false
                longFired = false
                vt?.recycle()
                vt = VelocityTracker.obtain()
                vt?.addMovement(e)
                uiHandler.postDelayed(longRun, 500)
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                if (!moved && (Math.abs(e.rawX - downRawX) > slop || Math.abs(e.rawY - downRawY) > slop)) {
                    moved = true
                    uiHandler.removeCallbacks(longRun)
                }
                if (moved) onDrag?.invoke(e.rawX - lastRawX, e.rawY - lastRawY)
                lastRawX = e.rawX; lastRawY = e.rawY
                return true
            }

            MotionEvent.ACTION_UP -> {
                uiHandler.removeCallbacks(longRun)
                vt?.addMovement(e)
                var used = false
                if (moved) {
                    vt?.computeCurrentVelocity(1000)
                    used = onFling?.invoke(vt?.xVelocity ?: 0f, vt?.yVelocity ?: 0f) ?: false
                }
                vt?.recycle(); vt = null
                if (moved) { if (!used) onRelease?.invoke() }
                else if (!longFired) {
                    buzz(HapticFeedbackConstants.VIRTUAL_KEY)
                    onTap?.invoke()
                }
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                uiHandler.removeCallbacks(longRun)
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}
