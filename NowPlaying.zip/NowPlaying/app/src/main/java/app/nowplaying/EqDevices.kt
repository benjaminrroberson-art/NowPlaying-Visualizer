package app.nowplaying

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager

/** Remembers which EQ preset to use for each audio output (Bluetooth headphones, wired, speaker...). */
object EqDevices {
    const val FLAT = "__flat"
    private var lastKey: String? = null

    private fun store(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("np_eqdev", Context.MODE_PRIVATE)

    /** Name of the output that sound is going to right now, or null if unknown. */
    fun current(ctx: Context): String? {
        val am = ctx.getSystemService(AudioManager::class.java)
        var best: AudioDeviceInfo? = null
        var bestRank = 0
        for (d in am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
            val r = when (d.type) {
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLE_HEADSET,
                AudioDeviceInfo.TYPE_BLE_BROADCAST, AudioDeviceInfo.TYPE_BLE_SPEAKER,
                AudioDeviceInfo.TYPE_HEARING_AID -> 4
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET,
                AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE,
                AudioDeviceInfo.TYPE_USB_ACCESSORY, AudioDeviceInfo.TYPE_LINE_ANALOG -> 3
                AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> 1
                else -> 0
            }
            if (r > bestRank) { best = d; bestRank = r }
        }
        val d = best ?: return null
        val name = d.productName?.toString()?.trim().orEmpty()
        return when (bestRank) {
            4 -> "Bluetooth: " + name.ifEmpty { "headphones" }
            3 -> if (d.type == AudioDeviceInfo.TYPE_USB_HEADSET || d.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
                d.type == AudioDeviceInfo.TYPE_USB_ACCESSORY) "USB audio: " + name.ifEmpty { "device" }
            else "Wired headphones"
            else -> "Phone speaker"
        }
    }

    fun assignments(ctx: Context): Map<String, String> =
        store(ctx).all.mapValues { it.value.toString() }

    fun assign(ctx: Context, device: String, preset: String?) {
        val e = store(ctx).edit()
        if (preset == null) e.remove(device) else e.putString(device, preset)
        e.apply()
        lastKey = null
        applyForCurrent(ctx)
    }

    /** Loads the preset assigned to the current output, once per change of output. */
    fun applyForCurrent(ctx: Context, force: Boolean = false) {
        val key = current(ctx) ?: return
        if (!force && key == lastKey) return
        lastKey = key
        val preset = store(ctx).getString(key, null) ?: return
        val p = Prefs(ctx)
        val wasOn = p.eqOn
        if (preset == FLAT) {
            p.eqBands = ""
            p.eqPost = 0
            p.eqCurrent = ""
            p.eqOn = false
        } else {
            val s = EqPresets.store(ctx).getString(preset, null) ?: return
            val parts = s.split("#")
            p.eqBands = parts.getOrElse(0) { "" }
            p.eqPost = parts.getOrNull(1)?.toIntOrNull() ?: 0
            p.eqCurrent = preset
            p.eqOn = true
        }
        EqEngine.ctx = ctx.applicationContext
        if (p.eqOn != wasOn) EqService.sync(ctx)
        EqEngine.apply(p)
    }

    fun resetLast() { lastKey = null }

    private var cb: android.media.AudioDeviceCallback? = null
    private val h = android.os.Handler(android.os.Looper.getMainLooper())

    /** Watches for outputs coming and going (always on, even when the EQ is off). */
    fun watch(ctx: Context) {
        if (cb != null) return
        val app = ctx.applicationContext
        val c = object : android.media.AudioDeviceCallback() {
            override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>?) { later(app) }
            override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>?) { later(app) }
        }
        cb = c
        try { app.getSystemService(AudioManager::class.java).registerAudioDeviceCallback(c, h) } catch (e: Exception) {}
        applyForCurrent(app)
    }

    fun unwatch(ctx: Context) {
        val c = cb ?: return
        cb = null
        try { ctx.applicationContext.getSystemService(AudioManager::class.java).unregisterAudioDeviceCallback(c) } catch (e: Exception) {}
    }

    private fun later(app: Context) {
        h.removeCallbacksAndMessages(null)
        h.postDelayed({ applyForCurrent(app) }, 1200)
    }
}
