package app.nowplaying

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * The screen saver picture: a black screen with the visualizer, album art, track text and a clock.
 * Used by the system screen saver, the full-screen preview, and the small preview in settings.
 */
class SaverView(ctx: Context, private val embedded: Boolean, private val honorQuiet: Boolean = false) : View(ctx) {

    var onClose: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val pref = Prefs(ctx)
    private val vp = Prefs(ctx)
    private val renderer = CardRenderer(ctx, vp).apply { fullScreen = true }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()
    private val listener: () -> Unit = { invalidate() }
    private var audioHeld = false
    private var lastFrame = 0L

    // burn-in drift
    private var shiftX = 0f
    private var shiftY = 0f
    private var tx = 0f
    private var ty = 0f
    private var nextShift = 0L
    private val rnd = java.util.Random()

    // tap-to-reveal controls
    private var ctlUntil = 0L
    private val hitPrev = RectF()
    private val hitPlay = RectF()
    private val hitNext = RectF()
    private val hitClose = RectF()

    private fun holdAudio(on: Boolean) {
        if (on && !audioHeld) {
            audioHeld = true
            Audio.start(context)
        } else if (!on && audioHeld) {
            audioHeld = false
            Audio.stop()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        MediaState.ensureStarted(context)
        MediaState.addListener(listener)
        holdAudio(windowVisibility == VISIBLE)
        lastFrame = SystemClock.uptimeMillis()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        MediaState.removeListener(listener)
        holdAudio(false)
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (isAttachedToWindow) holdAudio(visibility == VISIBLE)
        if (visibility == VISIBLE) invalidate()
    }

    private fun applyOverrides() {
        val o = vp.ov
        if (pref.saverStyle >= 0) o["vizStyle"] = pref.saverStyle else o.remove("vizStyle")
        if (pref.has("saverOpacity")) o["vizOpacity"] = pref.saverOpacity else o.remove("vizOpacity")
        renderer.stripScale = pref.saverVizHeight / 100f
        o["showControls"] = false
        o["showProgress"] = false
        o["showEqChip"] = false
        o["showCapChip"] = false
        o["idleBreath"] = false
    }

    private fun clockText(): String {
        val f = if (pref.saverClock24) "HH:mm" else "h:mm"
        return SimpleDateFormat(f, Locale.getDefault()).format(Date())
    }

    private fun fitText(t: String, paint: Paint, maxW: Float): String {
        if (paint.measureText(t) <= maxW) return t
        val n = paint.breakText(t, true, max(maxW - paint.measureText("…"), 0f), null)
        return t.substring(0, n).trimEnd() + "…"
    }

    private fun drawClockLayout(c: Canvas, w: Float, h: Float) {
        val big = min(w * 0.30f, h * 0.15f) * pref.saverBigClock / 100f
        p.style = Paint.Style.FILL
        p.shader = null
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        p.color = Color.argb(235, 255, 255, 255)
        p.textSize = big
        val cy = h * 0.42f
        if (pref.saverClock || pref.saverLayout != 2) c.drawText(clockText(), w / 2f, cy, p)
        val title = MediaState.title
        if (pref.saverText && title.isNotEmpty() && MediaState.hasSession) {
            p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            p.textSize = 20f * d
            p.color = Color.argb(210, 255, 255, 255)
            c.drawText(fitText(title, p, w - 48f * d), w / 2f, cy + 48f * d, p)
            val ar = MediaState.artist
            if (ar.isNotEmpty()) {
                p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                p.textSize = 15f * d
                p.color = Color.argb(150, 255, 255, 255)
                c.drawText(fitText(ar, p, w - 48f * d), w / 2f, cy + 76f * d, p)
            }
        }
    }

    private fun drawSmallClock(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL
        p.shader = null
        p.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        p.color = Color.argb(185, 255, 255, 255)
        val size = pref.saverClockSize * d
        p.textSize = size
        val m = 22f * d
        if (pref.saverClockFree) {
            p.textAlign = Paint.Align.CENTER
            val txt = clockText()
            val tw = p.measureText(txt)
            val cxp = (w * pref.saverClockX / 100f).coerceIn(tw / 2f + 8f * d, max(tw / 2f + 8f * d, w - tw / 2f - 8f * d))
            val cyp = (h * pref.saverClockYp / 100f).coerceIn(size, max(size, h - 12f * d))
            c.drawText(txt, cxp, cyp + size * 0.35f, p)
            return
        }
        val topY = pref.saverClockY * d + size
        val pos = pref.saverClockPos
        when (pos) {
            0 -> { p.textAlign = Paint.Align.LEFT; c.drawText(clockText(), m, topY, p) }
            1 -> { p.textAlign = Paint.Align.CENTER; c.drawText(clockText(), w / 2f, topY, p) }
            2 -> { p.textAlign = Paint.Align.RIGHT; c.drawText(clockText(), w - m, topY, p) }
            3 -> { p.textAlign = Paint.Align.CENTER; c.drawText(clockText(), w / 2f, h / 2f + size * 0.35f, p) }
            else -> { p.textAlign = Paint.Align.CENTER; c.drawText(clockText(), w / 2f, h - 44f * d, p) }
        }
    }

    // ---- blurred, slowly turning album art behind everything (keeps the lit pixels changing)
    private var bdKey: Bitmap? = null
    private var bdBmp: Bitmap? = null
    private var bdAngle = 0f

    private fun drawBackdrop(c: Canvas, w: Float, h: Float, dt: Float) {
        val art = MediaState.art ?: return
        if (art !== bdKey) {
            bdKey = art
            try {
                bdBmp = SoftBlur.make(art, 90)
            } catch (e: Exception) { bdBmp = null }
        }
        val bmp = bdBmp ?: return
        bdAngle = (bdAngle + dt * 4f) % 360f
        val diag = Math.hypot(w.toDouble(), h.toDouble()).toFloat()
        p.shader = null
        p.style = Paint.Style.FILL
        p.isFilterBitmap = true
        p.alpha = (255f * pref.saverBackdrop / 100f).toInt().coerceIn(0, 255)
        c.save()
        c.translate(w / 2f, h / 2f)
        c.rotate(bdAngle)
        rect.set(-diag / 2f, -diag / 2f, diag / 2f, diag / 2f)
        c.drawBitmap(bmp, null, rect, p)
        c.restore()
        p.alpha = 255
    }

    private var sceneBlank = false
    private var sceneClockOnly = false
    private var sceneBackdrop = false

    private fun drawScene(c: Canvas, w: Float, h: Float, dt: Float, now: Long) {
        applyOverrides()
        c.drawColor(Color.BLACK)

        val playing = MediaState.playing
        val layout = pref.saverLayout
        val clockOnly = layout == 2 || (!playing && pref.saverPaused == 0)
        val blank = !playing && pref.saverPaused == 1 && layout != 2
        sceneBlank = blank
        sceneClockOnly = clockOnly

        // slow drift so no pixel stays lit in one place
        val drift = pref.saverDrift
        val backdrop = pref.saverBackdropOn
        sceneBackdrop = backdrop
        if (backdrop && !blank) drawBackdrop(c, w, h, dt)
        if (!embedded && drift) {
            if (now >= nextShift) {
                nextShift = now + pref.saverShift * 1000L
                val r = 22f * d
                tx = (rnd.nextFloat() * 2f - 1f) * r
                ty = (rnd.nextFloat() * 2f - 1f) * r
            }
            shiftX += (tx - shiftX) * min(1f, dt * 0.6f)
            shiftY += (ty - shiftY) * min(1f, dt * 0.6f)
        } else if (!drift) {
            shiftX = 0f
            shiftY = 0f
        }
        c.save()
        c.translate(shiftX, shiftY)
        if (!blank) {
            if (clockOnly) {
                drawClockLayout(c, w, h)
            } else {
                Audio.gain = 1f
                Audio.fall = vp.vizFall / 100f
                Audio.update(false)
                renderer.artScale = pref.saverArtSize / 100f
                renderer.saverLayout = if (layout == 1 || layout == 3) layout else 0
                renderer.saverSwap = pref.saverSwap
                renderer.hideArt = !pref.saverArt || layout == 3
                renderer.hideText = !pref.saverText || layout == 3
                renderer.draw(c, w, h, dt)
                if (pref.saverClock && layout != 3) drawSmallClock(c, w, h)
            }
        }
        c.restore()

        // dimming
        if (!embedded) {
            val dim = (1f - pref.saverBright / 100f).coerceIn(0f, 0.93f)
            if (dim > 0f) c.drawColor(Color.argb((dim * 255f).toInt(), 0, 0, 0))
        }
    }

    // low-resolution copy of the picture, blurred, shown behind the controls
    private var offBmp: Bitmap? = null
    private var offCanvas: Canvas? = null
    private val offDiv = 6

    override fun onDraw(c: Canvas) {
        if (honorQuiet && pref.saverQuietNow()) {
            c.drawColor(Color.BLACK)
            post { onClose?.invoke() }
            return
        }
        val now = SystemClock.uptimeMillis()
        val dt = ((now - lastFrame) / 1000f).coerceIn(0.001f, 0.1f)
        lastFrame = now
        val w = width.toFloat()
        val h = height.toFloat()
        val playing = MediaState.playing
        val showCtl = !embedded && now < ctlUntil

        if (showCtl) {
            val ow = max(8, (w / offDiv).toInt())
            val oh = max(8, (h / offDiv).toInt())
            var bm = offBmp
            if (bm == null || bm.width != ow || bm.height != oh) {
                bm = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
                offBmp = bm
                offCanvas = Canvas(bm)
            }
            val oc = offCanvas!!
            oc.save()
            oc.scale(ow / w, oh / h)
            drawScene(oc, w, h, dt, now)
            oc.restore()
            SoftBlur.blurInPlace(bm, 5)
            p.shader = null
            p.alpha = 255
            p.isFilterBitmap = true
            rect.set(0f, 0f, w, h)
            c.drawBitmap(bm, null, rect, p)
            c.drawColor(Color.argb(90, 0, 0, 0))
            drawControls(c, w, h)
        } else {
            drawScene(c, w, h, dt, now)
            hitPrev.setEmpty(); hitPlay.setEmpty(); hitNext.setEmpty(); hitClose.setEmpty()
        }

        val fps = pref.saverFps.coerceIn(10, 60)
        val busy = playing || Audio.active() || renderer.hasMotion() || showCtl || (playing && sceneBackdrop)
        postInvalidateDelayed(if (busy && !sceneBlank && !(sceneClockOnly && !showCtl)) (1000L / fps) else 1000L)
    }

    private fun drawControls(c: Canvas, w: Float, h: Float) {
        val cy = h / 2f
        val s = 54f * d
        val ps = 70f * d
        val gap = 14f * d
        val total = s + ps + s + 2f * gap
        var x = w / 2f - total / 2f
        hitPrev.set(x, cy - s / 2f, x + s, cy + s / 2f); x += s + gap
        hitPlay.set(x, cy - ps / 2f, x + ps, cy + ps / 2f); x += ps + gap
        hitNext.set(x, cy - s / 2f, x + s, cy + s / 2f)
        hitClose.set(w - 72f * d, 40f * d, w - 16f * d, 96f * d)

        p.shader = null
        p.style = Paint.Style.FILL
        p.color = Color.argb(70, 255, 255, 255)
        for (r in arrayOf(hitPrev, hitPlay, hitNext, hitClose)) c.drawCircle(r.centerX(), r.centerY(), r.width() / 2f, p)
        p.color = Color.WHITE
        p.strokeCap = Paint.Cap.ROUND
        // play / pause
        val px = hitPlay.centerX()
        val py = hitPlay.centerY()
        if (MediaState.playing) {
            rect.set(px - 11f * d, py - 14f * d, px - 3f * d, py + 14f * d); c.drawRoundRect(rect, 2f * d, 2f * d, p)
            rect.set(px + 3f * d, py - 14f * d, px + 11f * d, py + 14f * d); c.drawRoundRect(rect, 2f * d, 2f * d, p)
        } else {
            path.reset()
            path.moveTo(px - 9f * d, py - 14f * d); path.lineTo(px - 9f * d, py + 14f * d); path.lineTo(px + 14f * d, py); path.close()
            c.drawPath(path, p)
        }
        // next / prev
        val nx = hitNext.centerX(); val ny = hitNext.centerY()
        path.reset()
        path.moveTo(nx - 9f * d, ny - 10f * d); path.lineTo(nx - 9f * d, ny + 10f * d); path.lineTo(nx + 6f * d, ny); path.close()
        c.drawPath(path, p)
        rect.set(nx + 7f * d, ny - 10f * d, nx + 10f * d, ny + 10f * d); c.drawRect(rect, p)
        val vx = hitPrev.centerX(); val vy = hitPrev.centerY()
        path.reset()
        path.moveTo(vx + 9f * d, vy - 10f * d); path.lineTo(vx + 9f * d, vy + 10f * d); path.lineTo(vx - 6f * d, vy); path.close()
        c.drawPath(path, p)
        rect.set(vx - 10f * d, vy - 10f * d, vx - 7f * d, vy + 10f * d); c.drawRect(rect, p)
        // close
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.4f * d
        val kx = hitClose.centerX(); val ky = hitClose.centerY()
        c.drawLine(kx - 8f * d, ky - 8f * d, kx + 8f * d, ky + 8f * d, p)
        c.drawLine(kx - 8f * d, ky + 8f * d, kx + 8f * d, ky - 8f * d, p)
        p.style = Paint.Style.FILL
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (embedded) return false
        if (e.actionMasked == MotionEvent.ACTION_DOWN) return true
        if (e.actionMasked != MotionEvent.ACTION_UP) return true
        val now = SystemClock.uptimeMillis()
        if (!pref.saverControls) {
            onClose?.invoke()
            return true
        }
        if (now < ctlUntil) {
            when {
                hitClose.contains(e.x, e.y) -> { onClose?.invoke(); return true }
                hitPlay.contains(e.x, e.y) -> MediaState.playPause()
                hitPrev.contains(e.x, e.y) -> MediaState.prev()
                hitNext.contains(e.x, e.y) -> MediaState.next()
            }
        }
        ctlUntil = now + 4000L
        invalidate()
        return true
    }
}
