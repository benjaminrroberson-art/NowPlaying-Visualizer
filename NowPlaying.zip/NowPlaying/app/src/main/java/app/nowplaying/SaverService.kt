package app.nowplaying

import android.service.dreams.DreamService

/** The Android screen saver ("daydream"). Pick it in Settings > Display > Screen saver. */
class SaverService : DreamService() {
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        isInteractive = true
        isFullscreen = true
        isScreenBright = true
        if (Prefs(this).saverQuietNow()) {
            finish()
            return
        }
        val v = SaverView(this, false, true)
        v.onClose = { finish() }
        setContentView(v)
    }
}
