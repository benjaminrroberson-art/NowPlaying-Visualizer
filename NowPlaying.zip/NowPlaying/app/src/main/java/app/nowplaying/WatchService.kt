package app.nowplaying

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder

/** Keeps the link to the watch alive while the "Connect to the watch" switch is on. */
class WatchService : Service() {

    companion object {
        @Volatile
        var running = false

        /** Starts the link if it is switched on. Safe to call repeatedly. */
        fun ensure(ctx: Context) {
            if (running) return
            if (!Prefs(ctx).watchOn) return
            try {
                ctx.startForegroundService(Intent(ctx, WatchService::class.java))
            } catch (e: Exception) {
            }
        }

        fun halt(ctx: Context) {
            ctx.stopService(Intent(ctx, WatchService::class.java))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("np_watch", "Watch link", NotificationManager.IMPORTANCE_MIN)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, WatchService::class.java).setAction("np.STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "np_watch")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Watch link is on")
            .setContentText("Tap to open settings")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "Turn off", stop
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(4, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(4, n)
        }
        running = true
        WatchLink.start(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "np.STOP") {
            Prefs(this).watchOn = false
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        WatchLink.stop()
        super.onDestroy()
    }
}
