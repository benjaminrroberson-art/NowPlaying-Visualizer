package app.nowplaying

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlin.math.max
import kotlin.math.min

/**
 * The single source of truth for what is playing. Follows the active media session
 * (needs notification access) or fake demo data.
 */
object MediaState {
    var title = ""
    var artist = ""
    var album = ""
    var art: Bitmap? = null
    var playing = false
    var durationMs = 0L
    var pkg = ""

    /** Colors pulled from the artwork. */
    var accent = 0xFF00E5FF.toInt()
    var accent2 = 0xFFFF4081.toInt()
    var dark = 0xFF14161A.toInt()
    var light = 0xFFFFFFFF.toInt()

    /** Several distinct colors pulled from the artwork (always at least 4), for the multi-color visualizer. */
    var palette = intArrayOf(0xFF00E5FF.toInt(), 0xFFFF4081.toInt(), 0xFFFFD740.toInt(), 0xFF69F0AE.toInt())
    var paletteSig = 0

    @Volatile
    var status = "Not started"

    private var posBase = 0L
    private var posTime = 0L
    private var speed = 1f

    private val main = Handler(Looper.getMainLooper())
    private val listeners = ArrayList<() -> Unit>()
    private var started = false
    private var appCtx: Context? = null
    private var controller: MediaController? = null
    private var demoOn = false
    private var demoPlaying = true
    private var demoStart = 0L
    private var demoArt: Bitmap? = null

    val demo: Boolean get() = demoOn

    /** True while a music app has a media session (gone once the app is fully closed). */
    val hasSession: Boolean get() = demoOn || controller != null

    fun addListener(l: () -> Unit) {
        if (!listeners.contains(l)) listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    private fun fire() {
        for (l in ArrayList(listeners)) l()
    }

    fun ensureStarted(ctx: Context) {
        if (started) return
        started = true
        appCtx = ctx.applicationContext
        refreshSessions()
    }

    private val sessionsChanged = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        pick(list ?: emptyList())
    }

    private fun refreshSessions() {
        val c = appCtx ?: return
        try {
            val msm = c.getSystemService(MediaSessionManager::class.java)
            val cn = ComponentName(c, MediaListener::class.java)
            try { msm.removeOnActiveSessionsChangedListener(sessionsChanged) } catch (e: Exception) {}
            msm.addOnActiveSessionsChangedListener(sessionsChanged, cn, main)
            pick(msm.getActiveSessions(cn))
            status = if (controller != null) "Connected to " + pkg else "Connected. Nothing is playing."
        } catch (e: SecurityException) {
            status = "Needs notification access (see Setup)"
            fire()
        } catch (e: Exception) {
            status = "Error: " + e.javaClass.simpleName
            fire()
        }
    }

    /** Called when the user comes back to the app after granting access. */
    fun retry() {
        if (started) refreshSessions()
    }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            readMetadata(metadata)
            fire()
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            readState(state)
            fire()
        }

        override fun onSessionDestroyed() {
            refreshSessions()
        }
    }

    private fun pick(list: List<MediaController>) {
        val best = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list.firstOrNull()
        if (best?.sessionToken == controller?.sessionToken && best != null) {
            return
        }
        try { controller?.unregisterCallback(callback) } catch (e: Exception) {}
        controller = best
        if (best == null) {
            title = ""; artist = ""; album = ""; art = null; playing = false; durationMs = 0; pkg = ""
            fire()
            return
        }
        best.registerCallback(callback, main)
        pkg = best.packageName ?: ""
        readMetadata(best.metadata)
        readState(best.playbackState)
        fire()
    }

    private fun readMetadata(m: MediaMetadata?) {
        if (m == null) return
        title = m.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: m.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        album = m.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        durationMs = m.getLong(MediaMetadata.METADATA_KEY_DURATION)
        val b = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        applyArt(b)
    }

    private fun readState(s: PlaybackState?) {
        if (s == null) {
            playing = false
            return
        }
        playing = s.state == PlaybackState.STATE_PLAYING || s.state == PlaybackState.STATE_BUFFERING
        posBase = s.position
        posTime = SystemClock.elapsedRealtime()
        speed = s.playbackSpeed
    }

    private fun applyArt(b: Bitmap?) {
        if (b == null) {
            art = null
            computeColors(null)
            return
        }
        // Artwork can arrive as a GPU-only bitmap, which the widget's software canvas can't draw.
        val soft = if (b.config == Bitmap.Config.HARDWARE) (b.copy(Bitmap.Config.ARGB_8888, false) ?: return) else b
        val m = max(soft.width, soft.height)
        art = if (m > 640) {
            val k = 640f / m
            Bitmap.createScaledBitmap(soft, (soft.width * k).toInt().coerceAtLeast(1), (soft.height * k).toInt().coerceAtLeast(1), true)
        } else soft
        computeColors(art)
    }

    /** Picks a vivid accent, a second accent, a dark tint and a light tint from the artwork. */
    private fun computeColors(b: Bitmap?) {
        if (b == null) {
            accent = 0xFF00E5FF.toInt(); accent2 = 0xFFFF4081.toInt()
            dark = 0xFF14161A.toInt(); light = 0xFFFFFFFF.toInt()
            palette = intArrayOf(0xFF00E5FF.toInt(), 0xFFFF4081.toInt(), 0xFFFFD740.toInt(), 0xFF69F0AE.toInt())
            paletteSig = palette.contentHashCode()
            return
        }
        val s = Bitmap.createScaledBitmap(b, 24, 24, true)
        val hsv = FloatArray(3)
        var bestScore = -1f
        var best = 0
        var avgR = 0f; var avgG = 0f; var avgB = 0f
        val px = IntArray(24 * 24)
        s.getPixels(px, 0, 24, 0, 0, 24, 24)
        for (p in px) {
            avgR += Color.red(p); avgG += Color.green(p); avgB += Color.blue(p)
            Color.colorToHSV(p, hsv)
            val score = hsv[1] * hsv[2] * (if (hsv[2] < 0.25f) 0.2f else 1f)
            if (score > bestScore) { bestScore = score; best = p }
        }
        val n = px.size
        Color.colorToHSV(best, hsv)
        hsv[1] = max(hsv[1], 0.55f); hsv[2] = max(hsv[2], 0.85f)
        accent = Color.HSVToColor(hsv)
        buildPalette(px, accent)
        accent2 = if (palette.size > 1) palette[1] else Color.HSVToColor(floatArrayOf((hsv[0] + 40f) % 360f, hsv[1], hsv[2]))
        val avg = Color.rgb((avgR / n).toInt(), (avgG / n).toInt(), (avgB / n).toInt())
        val dh = FloatArray(3)
        Color.colorToHSV(avg, dh)
        dh[1] = min(dh[1], 0.6f); dh[2] = 0.16f
        dark = Color.HSVToColor(dh)
        val lh = floatArrayOf(hsv[0], 0.12f, 1f)
        light = Color.HSVToColor(lh)
    }

    /** Groups the artwork's colorful pixels by hue and keeps the strongest groups as the palette. */
    private fun buildPalette(px: IntArray, first: Int) {
        val bins = 12
        val wt = FloatArray(bins)
        val sx = FloatArray(bins)
        val sy = FloatArray(bins)
        val ss = FloatArray(bins)
        val sv = FloatArray(bins)
        val hsv = FloatArray(3)
        for (p in px) {
            Color.colorToHSV(p, hsv)
            if (hsv[1] < 0.22f || hsv[2] < 0.22f) continue
            val w = hsv[1] * hsv[2]
            val bi = ((hsv[0] / 360f) * bins).toInt().coerceIn(0, bins - 1)
            val rad = Math.toRadians(hsv[0].toDouble())
            wt[bi] += w
            sx[bi] += (Math.cos(rad) * w).toFloat()
            sy[bi] += (Math.sin(rad) * w).toFloat()
            ss[bi] += hsv[1] * w
            sv[bi] += hsv[2] * w
        }
        val order = (0 until bins).filter { wt[it] > 0f }.sortedByDescending { wt[it] }
        val out = ArrayList<FloatArray>()
        if (order.isNotEmpty()) {
            val top = wt[order[0]]
            for (bi in order) {
                if (out.size >= 6) break
                if (wt[bi] < top * 0.06f) break
                var hue = Math.toDegrees(Math.atan2(sy[bi].toDouble(), sx[bi].toDouble())).toFloat()
                if (hue < 0f) hue += 360f
                // skip a hue that is almost the same as one already kept
                if (out.any { val dd = Math.abs(it[0] - hue); Math.min(dd, 360f - dd) < 24f }) continue
                out.add(floatArrayOf(hue, max(ss[bi] / wt[bi], 0.55f), max(sv[bi] / wt[bi], 0.85f)))
            }
        }
        if (out.isEmpty()) {
            Color.colorToHSV(first, hsv)
            out.add(floatArrayOf(hsv[0], hsv[1], hsv[2]))
        }
        // too few real colors (plain or black-and-white art): add tints and neighbouring hues
        var k = 0
        while (out.size < 4 && k < 8) {
            val b = out[k % out.size]
            val v = k / out.size
            out.add(
                when (v) {
                    0 -> floatArrayOf((b[0] + 28f) % 360f, max(b[1] * 0.85f, 0.45f), 1f)
                    else -> floatArrayOf((b[0] + 332f) % 360f, max(b[1] * 0.6f, 0.35f), 1f)
                }
            )
            k++
        }
        // order around the color wheel, starting at the main accent, so neighbours blend smoothly
        val h0 = out[0][0]
        out.sortBy { (it[0] - h0 + 360f) % 360f }
        palette = IntArray(out.size) { Color.HSVToColor(out[it]) }
        paletteSig = palette.contentHashCode()
    }

    fun positionMs(): Long {
        if (demoOn) {
            val t = SystemClock.elapsedRealtime() - demoStart
            return t % durationMs.coerceAtLeast(1)
        }
        if (!playing) return posBase
        val p = posBase + ((SystemClock.elapsedRealtime() - posTime) * speed).toLong()
        return if (durationMs > 0) min(p, durationMs) else p
    }

    // ------------------------------------------------------------------ controls

    fun playPause() {
        if (demoOn) {
            demoPlaying = !demoPlaying
            playing = demoPlaying
            fire()
            return
        }
        val c = controller ?: return
        if (playing) c.transportControls.pause() else c.transportControls.play()
    }

    fun next() {
        if (!demoOn) controller?.transportControls?.skipToNext()
    }

    fun prev() {
        if (!demoOn) controller?.transportControls?.skipToPrevious()
    }

    fun seekTo(ms: Long) {
        if (demoOn) {
            demoStart = SystemClock.elapsedRealtime() - ms
            return
        }
        controller?.transportControls?.seekTo(ms)
    }

    /** Opens the app that is playing (or null if unknown). */
    fun launchIntent(ctx: Context) = if (pkg.isEmpty()) null else ctx.packageManager.getLaunchIntentForPackage(pkg)

    // ------------------------------------------------------------------ demo

    fun setDemo(on: Boolean) {
        demoOn = on
        if (on) {
            title = "Midnight City"
            artist = "Demo Artist"
            album = "Demo Album"
            durationMs = 215000
            demoStart = SystemClock.elapsedRealtime() - 62000
            demoPlaying = true
            playing = true
            pkg = ""
            if (demoArt == null) demoArt = makeDemoArt()
            art = demoArt
            computeColors(art)
        } else {
            title = ""; artist = ""; album = ""; art = null; playing = false; durationMs = 0
            computeColors(null)
            if (started) refreshSessions()
        }
        fire()
    }

    private fun makeDemoArt(): Bitmap {
        val s = 512
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, s.toFloat(), s.toFloat(),
            intArrayOf(0xFF3A1C71.toInt(), 0xFFD76D77.toInt(), 0xFFFFAF7B.toInt()), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, s.toFloat(), s.toFloat(), p)
        p.shader = RadialGradient(s * 0.65f, s * 0.35f, s * 0.35f,
            intArrayOf(0xCCFFFFFF.toInt(), 0x00FFFFFF), null, Shader.TileMode.CLAMP)
        c.drawCircle(s * 0.65f, s * 0.35f, s * 0.35f, p)
        return b
    }
}
