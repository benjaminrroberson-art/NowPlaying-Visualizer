package app.nowplaying

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration

/**
 * The live now-playing card. Animates only while something is moving, so it costs nothing
 * when music is paused.
 */
class CardView(context: Context, val prefs: Prefs) : View(context) {

    val renderer = CardRenderer(context, prefs)

    /** Tap on the card body (not on a control). */
    var onTap: (() -> Unit)? = null
    var onMinimize: (() -> Unit)? = null

    /** Any touch on the card (lets a pop-up restart its auto-close timer). */
    var onInteract: (() -> Unit)? = null

    /** Set for the floating card: dragging the card body moves the window. */
    var onDrag: ((dx: Float, dy: Float) -> Unit)? = null

    var fullScreen: Boolean
        get() = renderer.fullScreen
        set(v) { renderer.fullScreen = v }

    private var lastFrame = 0L
    private var audioHeld = false
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val listener: () -> Unit = { invalidate() }

    private var downX = 0f
    private var downY = 0f
    private var lastRawX = 0f
    private var lastRawY = 0f
    private var zone = 0   // 1 prev, 2 play, 3 next, 4 seek, 5 body
    private var moved = false

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec)
        val hMode = MeasureSpec.getMode(heightSpec)
        val h = if (hMode == MeasureSpec.EXACTLY) MeasureSpec.getSize(heightSpec)
        else {
            val want = renderer.heightFor().toInt()
            if (hMode == MeasureSpec.AT_MOST) minOf(want, MeasureSpec.getSize(heightSpec)) else want
        }
        setMeasuredDimension(w, h)
    }

    private fun holdAudio(on: Boolean) {
        if (on && !audioHeld) {
            audioHeld = true
            Audio.start(context)
        } else if (!on && audioHeld) {
            audioHeld = false
            Audio.stop()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        MediaState.ensureStarted(context)
        MediaState.addListener(listener)
        holdAudio(windowVisibility == VISIBLE)
        lastFrame = SystemClock.uptimeMillis()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        MediaState.removeListener(listener)
        holdAudio(false)
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (isAttachedToWindow) holdAudio(visibility == VISIBLE)
        if (visibility == VISIBLE) invalidate()
    }

    /** Settings changed: re-measure (heights can change) and redraw. */
    fun reload() {
        requestLayout()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = ((now - lastFrame) / 1000f).coerceIn(0.001f, 0.05f)
        lastFrame = now
        Audio.gain = prefs.vizSens / 100f
        Audio.fall = prefs.vizFall / 100f
        Audio.update(prefs.idleBreath)
        renderer.draw(canvas, width.toFloat(), height.toFloat(), dt)
        val animate = MediaState.playing || Audio.active() || renderer.hasMotion() ||
            prefs.idleBreath || renderer.dragFrac >= 0f
        if (animate) postInvalidateOnAnimation()
    }

    private fun zoneAt(x: Float, y: Float): Int = when {
        renderer.hitEq.contains(x, y) -> 6
        renderer.hitCap.contains(x, y) -> 7
        renderer.hitMin.contains(x, y) -> 8
        renderer.hitPlay.contains(x, y) -> 2
        renderer.hitPrev.contains(x, y) -> 1
        renderer.hitNext.contains(x, y) -> 3
        renderer.hitSeek.contains(x, y) -> 4
        else -> 5
    }

    private fun fracAt(x: Float): Float {
        val pad = 16f * resources.displayMetrics.density
        return ((x - pad) / (width - 2f * pad)).coerceIn(0f, 1f)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                onInteract?.invoke()
                downX = e.x; downY = e.y
                lastRawX = e.rawX; lastRawY = e.rawY
                moved = false
                zone = zoneAt(e.x, e.y)
                if (zone == 4) {
                    parent?.requestDisallowInterceptTouchEvent(true)
                    renderer.dragFrac = fracAt(e.x)
                    invalidate()
                }
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (zone == 4) {
                    renderer.dragFrac = fracAt(e.x)
                    invalidate()
                } else if (zone == 5 && onDrag != null) {
                    if (!moved && (Math.abs(e.x - downX) > slop || Math.abs(e.y - downY) > slop)) moved = true
                    if (moved) {
                        onDrag?.invoke(e.rawX - lastRawX, e.rawY - lastRawY)
                    }
                }
                lastRawX = e.rawX; lastRawY = e.rawY
                return true
            }

            MotionEvent.ACTION_UP -> {
                when (zone) {
                    1 -> MediaState.prev()
                    2 -> MediaState.playPause()
                    3 -> MediaState.next()
                    4 -> {
                        val f = fracAt(e.x)
                        if (MediaState.durationMs > 0) MediaState.seekTo((f * MediaState.durationMs).toLong())
                        renderer.dragFrac = -1f
                    }
                    6 -> EqMenu.show(this) { invalidate() }
                    7 -> {
                        if (CaptureService.running) {
                            CaptureService.stop(context)
                        } else {
                            val i = Intent(context, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                            try { context.startActivity(i) } catch (e: Exception) {}
                        }
                    }
                    8 -> onMinimize?.invoke()
                    else -> if (!moved) onTap?.invoke()
                }
                invalidate()
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                renderer.dragFrac = -1f
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}
