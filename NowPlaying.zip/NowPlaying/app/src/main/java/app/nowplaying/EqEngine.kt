package app.nowplaying

import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * System-wide parametric EQ + post gain, applied to the global audio output (session 0), so it works
 * with any app and any output and does not use playback capture (the visualizer keeps working).
 *
 * The bands you define (type, frequency, gain, Q) are turned into a smooth curve, which is sampled
 * onto a 40-band system equalizer. Falls back to the classic Equalizer + LoudnessEnhancer.
 */
object EqEngine {
    /** type: 0 bell, 1 low shelf, 2 high shelf, 3 high-pass, 4 low-pass */
    class Band(var type: Int, var f: Float, var g: Float, var q: Float)

    val TYPES = listOf("Bell", "Low shelf", "High shelf", "High-pass", "Low-pass")

    const val GRID = 40
    private val gridF = FloatArray(GRID) { (20.0 * 1000.0.pow(it / (GRID - 1.0))).toFloat() }

    @Volatile
    var status = "EQ: off"

    private var dp: DynamicsProcessing? = null
    private var eq: Equalizer? = null
    private var loud: LoudnessEnhancer? = null

    fun parse(s: String): MutableList<Band> {
        val out = ArrayList<Band>()
        for (part in s.split("|")) {
            val x = part.split(":")
            if (x.size < 4) continue
            val t = x[0].toIntOrNull() ?: continue
            val f = x[1].toFloatOrNull() ?: continue
            val g = x[2].toFloatOrNull() ?: continue
            val q = x[3].toFloatOrNull() ?: continue
            out.add(Band(t.coerceIn(0, 4), f, g, q))
        }
        return out
    }

    fun encode(l: List<Band>): String = l.joinToString("|") {
        "${it.type}:${String.format(java.util.Locale.US, "%.1f", it.f)}:${String.format(java.util.Locale.US, "%.2f", it.g)}:${String.format(java.util.Locale.US, "%.2f", it.q)}"
    }

    // ------------------------------------------------------------------ filter maths

    private fun magDb(b: Band, f: Float): Double {
        val sr = 48000.0
        val f0 = b.f.toDouble().coerceIn(10.0, 22000.0)
        val q = b.q.toDouble().coerceIn(0.1, 20.0)
        val w0 = 2.0 * PI * f0 / sr
        val a = 10.0.pow(b.g / 40.0)
        val alpha = sin(w0) / (2.0 * q)
        val c = cos(w0)
        val b0: Double; val b1: Double; val b2: Double; val a0: Double; val a1: Double; val a2: Double
        when (b.type) {
            1 -> {
                val s = 2.0 * sqrt(a) * alpha
                b0 = a * ((a + 1) - (a - 1) * c + s); b1 = 2 * a * ((a - 1) - (a + 1) * c)
                b2 = a * ((a + 1) - (a - 1) * c - s)
                a0 = (a + 1) + (a - 1) * c + s; a1 = -2 * ((a - 1) + (a + 1) * c); a2 = (a + 1) + (a - 1) * c - s
            }
            2 -> {
                val s = 2.0 * sqrt(a) * alpha
                b0 = a * ((a + 1) + (a - 1) * c + s); b1 = -2 * a * ((a - 1) + (a + 1) * c)
                b2 = a * ((a + 1) + (a - 1) * c - s)
                a0 = (a + 1) - (a - 1) * c + s; a1 = 2 * ((a - 1) - (a + 1) * c); a2 = (a + 1) - (a - 1) * c - s
            }
            3 -> {
                b0 = (1 + c) / 2; b1 = -(1 + c); b2 = (1 + c) / 2
                a0 = 1 + alpha; a1 = -2 * c; a2 = 1 - alpha
            }
            4 -> {
                b0 = (1 - c) / 2; b1 = 1 - c; b2 = (1 - c) / 2
                a0 = 1 + alpha; a1 = -2 * c; a2 = 1 - alpha
            }
            else -> {
                b0 = 1 + alpha * a; b1 = -2 * c; b2 = 1 - alpha * a
                a0 = 1 + alpha / a; a1 = -2 * c; a2 = 1 - alpha / a
            }
        }
        val w = 2.0 * PI * f.toDouble().coerceAtMost(23000.0) / sr
        val cw = cos(w); val sw = sin(w); val c2 = cos(2 * w); val s2 = sin(2 * w)
        val nr = b0 + b1 * cw + b2 * c2
        val ni = b1 * sw + b2 * s2
        val dr = a0 + a1 * cw + a2 * c2
        val di = a1 * sw + a2 * s2
        val num = nr * nr + ni * ni
        val den = dr * dr + di * di
        if (den <= 0.0 || num <= 0.0) return -60.0
        return 10.0 * log10(num / den)
    }

    fun curve(bands: List<Band>, f: Float): Float {
        var s = 0.0
        for (b in bands) s += magDb(b, f)
        return s.toFloat().coerceIn(-15f, 15f)
    }

    // ------------------------------------------------------------------ apply

    @Synchronized
    fun apply(p: Prefs) {
        if (!p.eqOn) {
            release()
            status = "EQ: off"
            return
        }
        val bands = parse(p.eqBands)
        val post = p.eqPost / 10f
        if (dp != null) {
            if (updateDp(bands, post)) return
            release()
        }
        if (eq == null && loud == null) {
            if (!startDp(bands, post)) startClassic(bands, post)
        } else {
            updateClassic(bands, post)
        }
    }

    @Synchronized
    fun release() {
        try { dp?.setEnabled(false) } catch (e: Throwable) {}
        try { dp?.release() } catch (e: Throwable) {}
        try { eq?.setEnabled(false) } catch (e: Throwable) {}
        try { eq?.release() } catch (e: Throwable) {}
        try { loud?.setEnabled(false) } catch (e: Throwable) {}
        try { loud?.release() } catch (e: Throwable) {}
        dp = null
        eq = null
        loud = null
    }

    // ------------------------------------------------------------------ DynamicsProcessing

    private fun cutoff(i: Int): Float =
        if (i >= GRID - 1) 22000f else sqrt(gridF[i] * gridF[i + 1])

    private fun startDp(bands: List<Band>, post: Float): Boolean {
        return try {
            val cfg = DynamicsProcessing.Config.Builder(
                DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                2, true, GRID, false, 0, false, 0, true
            ).build()
            val d = DynamicsProcessing(0, 0, cfg)
            dp = d
            if (!updateDp(bands, post)) throw IllegalStateException("update failed")
            d.setEnabled(true)
            status = "EQ: active (" + bands.size + " bands, system DSP)"
            true
        } catch (e: Throwable) {
            try { dp?.release() } catch (x: Throwable) {}
            dp = null
            status = "EQ: DSP unavailable (" + e.javaClass.simpleName + "), trying classic"
            false
        }
    }

    private fun updateDp(bands: List<Band>, post: Float): Boolean {
        val d = dp ?: return false
        return try {
            for (i in 0 until GRID) {
                d.setPreEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, cutoff(i), curve(bands, gridF[i])))
            }
            d.setLimiterAllChannelsTo(
                DynamicsProcessing.Limiter(true, true, 0, 1f, 80f, 10f, -1f, post.coerceIn(-20f, 12f))
            )
            status = "EQ: active (" + bands.size + " bands, system DSP)"
            true
        } catch (e: Throwable) {
            false
        }
    }

    // ------------------------------------------------------------------ classic fallback

    private fun startClassic(bands: List<Band>, post: Float) {
        var ok = false
        try {
            val e = Equalizer(0, 0)
            e.setEnabled(true)
            eq = e
            ok = true
        } catch (t: Throwable) {
            eq = null
        }
        try {
            loud = LoudnessEnhancer(0)
            ok = true
        } catch (t: Throwable) {
            loud = null
        }
        if (!ok) {
            status = "EQ: couldn't attach to the system output on this phone"
            return
        }
        updateClassic(bands, post)
    }

    private fun updateClassic(bands: List<Band>, post: Float) {
        val e = eq
        if (e != null) {
            try {
                val range = e.bandLevelRange
                for (b in 0 until e.numberOfBands) {
                    val hz = e.getCenterFreq(b.toShort()) / 1000f
                    val mb = (curve(bands, hz) * 100f).toInt().coerceIn(range[0].toInt(), range[1].toInt())
                    e.setBandLevel(b.toShort(), mb.toShort())
                }
            } catch (t: Throwable) {}
        }
        val l = loud
        if (l != null) {
            try {
                l.setTargetGain((max(0f, post) * 100f).toInt())
                l.setEnabled(post > 0.05f)
            } catch (t: Throwable) {}
        }
        status = "EQ: active (classic " + (e?.numberOfBands ?: 0) + "-band, system DSP)"
    }
}
