package app.nowplaying

import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sqrt

/**
 * System-wide equalizer + post gain, applied to the global audio output (session 0), so it works with
 * any app and any output, and does not use playback capture (the visualizer keeps working).
 * Tries a 10-band DynamicsProcessing first, then falls back to the classic Equalizer + LoudnessEnhancer.
 */
object EqEngine {
    val FREQ = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)

    @Volatile
    var status = "EQ: off"

    private var dp: DynamicsProcessing? = null
    private var eq: Equalizer? = null
    private var loud: LoudnessEnhancer? = null

    fun parse(s: String): FloatArray {
        val out = FloatArray(FREQ.size)
        val parts = s.split(",")
        for (i in out.indices) out[i] = parts.getOrNull(i)?.trim()?.toFloatOrNull() ?: 0f
        return out
    }

    fun encode(b: FloatArray): String = b.joinToString(",") { String.format(java.util.Locale.US, "%.1f", it) }

    @Synchronized
    fun apply(p: Prefs) {
        if (!p.eqOn) {
            release()
            status = "EQ: off"
            return
        }
        val bands = parse(p.eqBands)
        val post = p.eqPost / 10f
        if (dp != null) {
            if (updateDp(bands, post)) return
            release()
        }
        if (eq == null && loud == null) {
            if (!startDp(bands, post)) startClassic(bands, post)
        } else {
            updateClassic(bands, post)
        }
    }

    @Synchronized
    fun release() {
        try { dp?.setEnabled(false) } catch (e: Throwable) {}
        try { dp?.release() } catch (e: Throwable) {}
        try { eq?.setEnabled(false) } catch (e: Throwable) {}
        try { eq?.release() } catch (e: Throwable) {}
        try { loud?.setEnabled(false) } catch (e: Throwable) {}
        try { loud?.release() } catch (e: Throwable) {}
        dp = null
        eq = null
        loud = null
    }

    // ------------------------------------------------------------------ DynamicsProcessing

    private fun cutoff(i: Int): Float =
        if (i >= FREQ.size - 1) 20000f else sqrt(FREQ[i].toFloat() * FREQ[i + 1])

    private fun startDp(bands: FloatArray, post: Float): Boolean {
        return try {
            val cfg = DynamicsProcessing.Config.Builder(
                DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                2, true, FREQ.size, false, 0, false, 0, true
            ).build()
            val d = DynamicsProcessing(0, 0, cfg)
            dp = d
            if (!updateDp(bands, post)) throw IllegalStateException("update failed")
            d.setEnabled(true)
            status = "EQ: active (10-band, system DSP)"
            true
        } catch (e: Throwable) {
            try { dp?.release() } catch (x: Throwable) {}
            dp = null
            status = "EQ: DSP unavailable (" + e.javaClass.simpleName + "), trying classic"
            false
        }
    }

    private fun updateDp(bands: FloatArray, post: Float): Boolean {
        val d = dp ?: return false
        return try {
            for (i in FREQ.indices) {
                d.setPreEqBandAllChannelsTo(i, DynamicsProcessing.EqBand(true, cutoff(i), bands[i].coerceIn(-15f, 15f)))
            }
            d.setLimiterAllChannelsTo(
                DynamicsProcessing.Limiter(true, true, 0, 1f, 80f, 10f, -1f, post.coerceIn(-20f, 12f))
            )
            true
        } catch (e: Throwable) {
            false
        }
    }

    // ------------------------------------------------------------------ classic fallback

    private fun startClassic(bands: FloatArray, post: Float) {
        var ok = false
        try {
            val e = Equalizer(0, 0)
            e.setEnabled(true)
            eq = e
            ok = true
        } catch (t: Throwable) {
            eq = null
        }
        try {
            val l = LoudnessEnhancer(0)
            loud = l
            ok = true
        } catch (t: Throwable) {
            loud = null
        }
        if (!ok) {
            status = "EQ: couldn't attach to the system output on this phone"
            return
        }
        updateClassic(bands, post)
    }

    private fun updateClassic(bands: FloatArray, post: Float) {
        val e = eq
        if (e != null) {
            try {
                val range = e.bandLevelRange
                for (b in 0 until e.numberOfBands) {
                    val hz = e.getCenterFreq(b.toShort()) / 1000f
                    var best = 0
                    var bd = Float.MAX_VALUE
                    for (i in FREQ.indices) {
                        val dd = abs(ln(hz / FREQ[i]))
                        if (dd < bd) { bd = dd; best = i }
                    }
                    val mb = (bands[best] * 100f).toInt().coerceIn(range[0].toInt(), range[1].toInt())
                    e.setBandLevel(b.toShort(), mb.toShort())
                }
            } catch (t: Throwable) {}
        }
        val l = loud
        if (l != null) {
            try {
                l.setTargetGain((max(0f, post) * 100f).toInt())
                l.setEnabled(post > 0.05f)
            } catch (t: Throwable) {}
        }
        status = "EQ: active (classic " + (e?.numberOfBands ?: 0) + "-band, system DSP)"
    }
}
