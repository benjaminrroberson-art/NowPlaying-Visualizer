package app.nowplaying

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws the whole now-playing card (background, artwork, text, visualizer, controls, progress)
 * onto any Canvas. Used by the live view, the full-screen player, the floating card and the
 * home-screen widget (which renders it to a bitmap).
 */
class CardRenderer(private val ctx: Context, private val prefs: Prefs) {

    companion object {
        val FONTS = listOf("Clean", "Light", "Condensed", "Medium", "Serif", "Mono", "Casual", "Script")
        private val FAMILIES = listOf(
            "sans-serif", "sans-serif-light", "sans-serif-condensed", "sans-serif-medium",
            "serif", "monospace", "casual", "cursive"
        )
        val STYLES = listOf(
            "Bars", "Mirrored bars", "Oscilloscope", "Filled wave",
            "Circular spectrum", "Pulse ring", "Particles", "Blurred glow"
        )
    }

    /** Widget: no drawn controls (real buttons sit in the reserved band), static visualizer. */
    var widgetMode = false
    var frozen = false
    var fullScreen = false
    var reserveBottomDp = 0f

    /** Screen saver: -1 normal card, 0 art + viz, 1 big viz, 3 viz only. */
    var saverLayout = -1
    var hideArt = false
    var hideText = false
    var artScale = 1f
    var saverSwap = false
    private var vizOnArt = false
    private val vizClip = Path()

    /** Pop-up card: show a small "minimise bubble" button. */
    var showMinChip = false
    val hitMin = RectF()

    /** 0 everything, 1 background/art/text/controls only, 2 visualizer + progress only (widget layers). */
    var layerMode = 0

    /** 0..1 while the user is dragging the progress line, else -1. */
    var dragFrac = -1f

    val hitPrev = RectF()
    val hitPlay = RectF()
    val hitNext = RectF()
    val hitSeek = RectF()
    val hitEq = RectF()
    val hitCap = RectF()
    var hasControls = false

    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val rect2 = RectF()
    private val path = Path()
    private val clipPath = Path()
    private val src = Rect()
    private val rnd = java.util.Random(7)

    // layout results
    private var portrait = false
    private var radial = false
    private var strip = false
    private var artCx = 0f
    private var artCy = 0f
    private var artR = 0f
    private val stripRect = RectF()
    private var textX = 0f
    private var textRight = 0f
    private var titleY = 0f
    private var artistY = 0f
    private var ctlCy = 0f
    private var progCy = 0f
    private var centered = false

    // animation state
    private var hueShift = 0f
    private var rot = 0f
    private var time = 0f
    private var lastBeat = 0
    private val rAge = FloatArray(6) { 9f }
    private var rNext = 0
    private val pn = 90
    private val px = FloatArray(pn)
    private val py = FloatArray(pn)
    private val pvx = FloatArray(pn)
    private val pvy = FloatArray(pn)
    private val plife = FloatArray(pn)
    private val pmax = FloatArray(pn) { 1f }
    private val psize = FloatArray(pn)
    private val phue = FloatArray(pn)
    private var spawnAcc = 0f

    // caches
    private var blurSrc: Bitmap? = null
    private var blurKey = -1
    private var blurBmp: Bitmap? = null
    private var gradSig = 0
    private var gradX0 = 0f
    private var gradX1 = 0f
    private var grad: Shader? = null
    private var tfKey = -1
    private var tfBold: Typeface = Typeface.DEFAULT_BOLD
    private var tfReg: Typeface = Typeface.DEFAULT

    private var scrolling = false
    private var lastTextKey = ""
    private var textT0 = 0L

    fun hasMotion(): Boolean {
        if (scrolling) return true
        for (a in rAge) if (a < 1.3f) return true
        for (l in plife) if (l > 0f) return true
        return false
    }

    // ------------------------------------------------------------------ layout

    private fun progArea(): Float = if (prefs.showProgress) 26f * d else 12f * d

    private fun compactArt(rad: Boolean): Float =
        if (rad) prefs.artSize * 0.72f * d else prefs.artSize * d

    /** Natural height for a compact (wrap_content) card of width w. */
    fun heightFor(): Float {
        val style = prefs.vizStyle
        val rad = style == 4 || style == 5
        val st = style in 0..3
        val ring = if (rad) prefs.vizDepth * d + 6f * d else 0f
        val block = compactArt(rad) + 2f * ring
        return 16f * d + block + (if (st) 6f * d + prefs.vizHeight * d else 0f) +
            progArea() + reserveBottomDp * d
    }

    private fun layout(w: Float, h: Float) {
        cardW = w
        val style = prefs.vizStyle
        radial = style == 4 || style == 5
        strip = style in 0..3
        val pad = 16f * d
        val reserve = reserveBottomDp * d
        val prog = progArea()
        val progTop = strip && prefs.showProgress && saverLayout != 1 && saverLayout != 3
        val bottomLimit = h - reserve - (if (progTop) 12f * d else prog)
        progCy = h - reserve - (if (prefs.showProgress) 13f * d else 6f * d)
        portrait = fullScreen || h > w * 1.15f
        centered = portrait
        hasControls = prefs.showControls && !widgetMode
        val ring = if (radial) prefs.vizDepth * d + 6f * d else 0f
        val ts = prefs.titleSize * d
        val asz = prefs.artistSize * d

        if (!portrait) {
            var a = compactArt(radial)
            val stripH = if (strip) 6f * d + prefs.vizHeight * d else 0f
            val availTop = bottomLimit - pad - stripH
            var block = a + 2f * ring
            if (block > availTop) {
                block = max(availTop, 48f * d)
                a = max(block - 2f * ring, 32f * d)
                block = a + 2f * ring
            }
            artR = a / 2f
            val left = prefs.artPos == 0
            val blockLeft = if (left) pad else w - pad - block
            artCx = blockLeft + block / 2f
            artCy = pad + block / 2f
            textX = if (left) blockLeft + block + 12f * d else pad
            textRight = if (left) w - pad else blockLeft - 12f * d
            val top = pad + 2f * d
            if (hasControls) {
                ctlCy = pad + block - 22f * d
                titleY = top + ts * 0.95f
                artistY = titleY + asz * 1.5f
            } else {
                val groupH = ts * 1.0f + asz * 1.5f
                titleY = pad + (block - groupH) / 2f + ts * 0.95f
                artistY = titleY + asz * 1.5f
            }
            if (strip) {
                if (progTop) {
                    progCy = pad + block + 13f * d
                    stripRect.set(pad, pad + block + 20f * d, w - pad, bottomLimit - 4f * d)
                } else {
                    stripRect.set(pad, pad + block + 6f * d, w - pad, bottomLimit - 4f * d)
                }
            }
        } else {
            val top = pad + (if (fullScreen) 36f * d else 0f)
            var a = if (strip) min(w * 0.56f, h * 0.30f) else min(w * 0.70f, h * 0.40f)
            if (radial) a = min(a, w - 2f * pad - 2f * ring)
            val block = a + 2f * ring
            artR = a / 2f
            artCx = w / 2f
            artCy = top + block / 2f
            textX = w / 2f
            textRight = w - pad
            titleY = artCy + block / 2f + 14f * d + ts
            artistY = titleY + asz * 1.6f
            ctlCy = bottomLimit - 50f * d
            if (strip) {
                var t = artistY + 22f * d
                if (progTop) { progCy = t + 2f * d; t += 24f * d }
                var b = ctlCy - 46f * d
                if (b - t < 40f * d) b = t + 40f * d
                if (saverSwap && saverLayout == 0) {
                    // visualizer on top, art below it, then the text
                    val sh = b - t
                    stripRect.set(pad, top, w - pad, top + sh)
                    artCy = top + sh + 12f * d + block / 2f
                    titleY = artCy + block / 2f + 14f * d + ts
                    artistY = titleY + asz * 1.6f
                } else {
                    stripRect.set(pad, t, w - pad, b)
                }
            }
        }

        if (saverLayout == 1 || saverLayout == 3) {
            val m = 24f * d
            val ringD = if (radial) prefs.vizDepth * d + 6f * d else 0f
            val half = min(w, h) / 2f - m
            artR = max(40f * d, (half - ringD) * 0.8f)
            artCx = w / 2f
            artCy = h / 2f
            stripRect.set(m, h * 0.16f, w - m, h * 0.72f)
            textX = w / 2f
            textRight = w - pad
            centered = true
            titleY = h - 110f * d
            artistY = titleY + asz * 1.6f
        }

        artR *= artScale
        vizOnArt = strip && saverLayout == 1
        if (vizOnArt) {
            val half2 = min(w, h) / 2f - 24f * d
            artR = half2 * artScale
            val ins = artR * 0.07f
            stripRect.set(artCx - artR + ins, artCy - artR + ins, artCx + artR - ins, artCy + artR - ins)
        }

        // controls
        if (hasControls) {
            if (portrait) {
                val s = 52f * d
                val ps = 68f * d
                val gap = 10f * d
                val total = s + ps + s + 2f * gap
                var x = w / 2f - total / 2f
                hitPrev.set(x, ctlCy - s / 2f, x + s, ctlCy + s / 2f); x += s + gap
                hitPlay.set(x, ctlCy - ps / 2f, x + ps, ctlCy + ps / 2f); x += ps + gap
                hitNext.set(x, ctlCy - s / 2f, x + s, ctlCy + s / 2f)
            } else {
                val s = 40f * d
                val ps = 48f * d
                val gap = 6f * d
                var x = textX - 4f * d
                hitPrev.set(x, ctlCy - s / 2f, x + s, ctlCy + s / 2f); x += s + gap
                hitPlay.set(x, ctlCy - ps / 2f, x + ps, ctlCy + ps / 2f); x += ps + gap
                hitNext.set(x, ctlCy - s / 2f, x + s, ctlCy + s / 2f)
            }
        } else {
            hitPrev.setEmpty(); hitPlay.setEmpty(); hitNext.setEmpty()
        }
        if (prefs.showProgress && !widgetMode) {
            hitSeek.set(pad - 8f * d, progCy - 18f * d, w - pad + 8f * d, progCy + 18f * d)
        } else {
            hitSeek.setEmpty()
        }
    }

    // ------------------------------------------------------------------ colors

    private fun lerp(a: Int, b: Int, t: Float): Int = Color.argb(
        (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * t).toInt(),
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    private fun palette(t: Float): Int {
        val pal = MediaState.palette
        val n = pal.size
        if (n < 2) return MediaState.accent
        val x = t.coerceIn(0f, 1f) * n
        val i = x.toInt()
        return lerp(pal[i % n], pal[(i + 1) % n], x - i)
    }

    private fun vizCol(t: Float): Int {
        val tt = t.coerceIn(0f, 1f)
        return when (prefs.vizColorMode) {
            0 -> prefs.vizColor
            1 -> lerp(prefs.vizColor, prefs.vizColor2, tt)
            2 -> lerp(MediaState.accent, MediaState.accent2, tt)
            4 -> palette(tt)
            else -> Color.HSVToColor(floatArrayOf((hueShift + tt * 300f) % 360f, 0.72f, 1f))
        }
    }

    private fun al(x: Float): Int = (255f * x).toInt().coerceIn(0, 255)

    private fun withAlpha(c: Int, a: Float): Int =
        Color.argb(al(a), Color.red(c), Color.green(c), Color.blue(c))

    fun textColorNow(): Int = textCol()

    private fun textCol(): Int = when (prefs.textMode) {
        0 -> Color.WHITE
        1 -> 0xFF101114.toInt()
        2 -> MediaState.light
        else -> prefs.textColor
    }

    private fun isLight(c: Int): Boolean =
        (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) > 150f

    /** Horizontal gradient across the strip for line/fill styles. */
    private fun hGrad(x0: Float, x1: Float): Shader {
        val sig = prefs.vizColorMode * 31 + vizCol(0f) * 7 + vizCol(1f) * 3 + MediaState.paletteSig * 5 +
            (if (prefs.vizColorMode == 3) (hueShift / 4f).toInt() else 0)
        if (grad == null || sig != gradSig || x0 != gradX0 || x1 != gradX1) {
            grad = LinearGradient(
                x0, 0f, x1, 0f,
                IntArray(9) { vizCol(it / 8f) }, null, Shader.TileMode.CLAMP
            )
            gradSig = sig; gradX0 = x0; gradX1 = x1
        }
        return grad!!
    }

    private fun fonts() {
        val key = prefs.font
        if (key != tfKey) {
            tfKey = key
            val fam = FAMILIES[key.coerceIn(0, FAMILIES.size - 1)]
            tfBold = Typeface.create(fam, Typeface.BOLD)
            tfReg = Typeface.create(fam, Typeface.NORMAL)
        }
    }

    // ------------------------------------------------------------------ main draw

    fun draw(c: Canvas, w: Float, h: Float, dt: Float) {
        layout(w, h)
        time += dt
        hueShift = (hueShift + dt * 20f) % 360f
        if (prefs.vizSpin) rot = (rot + dt * 6f) % 360f
        val sens = prefs.vizSens / 100f
        updateEffects(dt, sens)

        val corner = if (fullScreen) 0f else prefs.corner * d
        c.save()
        rect.set(0f, 0f, w, h)
        clipPath.reset()
        clipPath.addRoundRect(rect, corner, corner, Path.Direction.CW)
        c.clipPath(clipPath)

        val base = layerMode != 2
        val live = layerMode != 1
        val sig = !Audio.noSignal()
        if (base) drawBackground(c, w, h)
        val style = prefs.vizStyle
        if (live && sig) {
            if (style == 7) drawGlow(c, w, h)
            if (style == 6) drawParticles(c)
            if (strip && !vizOnArt) drawStrip(c)
            if (radial) drawRadial(c)
        }
        if (base) {
            if (!hideArt) drawArt(c)
            if (!hideText) drawTexts(c)
            if (hasControls) drawControls(c)
        }
        if (vizOnArt && live && sig) {
            val shape = prefs.artShape
            val rr = when (shape) { 0 -> 4f * d; 1 -> artR * 0.22f; else -> artR }
            rect.set(artCx - artR, artCy - artR, artCx + artR, artCy + artR)
            vizClip.reset()
            vizClip.addRoundRect(rect, rr, rr, Path.Direction.CW)
            c.save()
            c.clipPath(vizClip)
            if (!hideArt) {
                p.shader = null
                p.style = Paint.Style.FILL
                p.color = Color.argb(95, 0, 0, 0)
                c.drawRect(rect, p)
            }
            drawStrip(c)
            c.restore()
        }
        if (live && prefs.showProgress) drawProgress(c, w)
        if (base && !widgetMode) drawChips(c, w) else { hitEq.setEmpty(); hitCap.setEmpty(); hitMin.setEmpty() }
        c.restore()
    }

    private val chipPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var cardW = 0f

    /** Width taken by the icon buttons in the top-right corner (0 when hidden). */
    private fun chipsReserve(): Float {
        if (widgetMode) return 0f
        val n = (if (prefs.showEqChip) 1 else 0) + (if (prefs.showCapChip) 1 else 0) + (if (showMinChip) 1 else 0)
        return if (n == 0) 0f else n * 34f * d + 8f * d
    }

    private fun drawIconBtn(c: Canvas, cx: Float, cy: Float, kind: Int, on: Boolean, hit: RectF) {
        val r = 14f * d
        chipPaint.style = Paint.Style.FILL
        chipPaint.shader = null
        chipPaint.color = if (on) withAlpha(MediaState.accent, 0.92f) else Color.argb(120, 0, 0, 0)
        c.drawCircle(cx, cy, r, chipPaint)
        chipPaint.color = Color.WHITE
        chipPaint.strokeCap = Paint.Cap.ROUND
        chipPaint.strokeWidth = 1.8f * d
        if (kind == 0) {
            // equalizer: three sliders
            val xs = floatArrayOf(-5f, 0f, 5f)
            val ks = floatArrayOf(-2f, 3f, -1f)
            chipPaint.style = Paint.Style.STROKE
            for (k in 0..2) {
                c.drawLine(cx + xs[k] * d, cy - 6.5f * d, cx + xs[k] * d, cy + 6.5f * d, chipPaint)
            }
            chipPaint.style = Paint.Style.FILL
            for (k in 0..2) c.drawCircle(cx + xs[k] * d, cy + ks[k] * d, 2.3f * d, chipPaint)
        } else if (kind == 2) {
            chipPaint.style = Paint.Style.STROKE
            c.drawLine(cx - 6f * d, cy, cx + 6f * d, cy, chipPaint)
        } else {
            // record / capture: ring, filled when running
            chipPaint.style = Paint.Style.STROKE
            c.drawCircle(cx, cy, 6f * d, chipPaint)
            if (on) {
                chipPaint.style = Paint.Style.FILL
                c.drawCircle(cx, cy, 3f * d, chipPaint)
            }
        }
        chipPaint.style = Paint.Style.FILL
        hit.set(cx - r - 4f * d, cy - r - 4f * d, cx + r + 4f * d, cy + r + 4f * d)
    }

    private fun drawChips(c: Canvas, w: Float) {
        var cx = w - 12f * d - 14f * d
        val cy = (if (fullScreen) 40f else 22f) * d
        if (prefs.showEqChip) {
            drawIconBtn(c, cx, cy, 0, prefs.eqOn, hitEq)
            cx -= 34f * d
        } else {
            hitEq.setEmpty()
        }
        if (prefs.showCapChip) {
            drawIconBtn(c, cx, cy, 1, CaptureService.running, hitCap)
            cx -= 34f * d
        } else {
            hitCap.setEmpty()
        }
        if (showMinChip) {
            drawIconBtn(c, cx, cy, 2, false, hitMin)
        } else {
            hitMin.setEmpty()
        }
    }

    // ------------------------------------------------------------------ background

    private fun drawBackground(c: Canvas, w: Float, h: Float) {
        val op = if (fullScreen) 1f else prefs.bgOpacity / 100f
        p.shader = null
        p.style = Paint.Style.FILL
        if (fullScreen) {
            p.color = Color.BLACK
            c.drawRect(0f, 0f, w, h, p)
        }
        when (prefs.bgMode) {
            0 -> {
                p.color = withAlpha(prefs.bgColor, Color.alpha(prefs.bgColor) / 255f * op)
                c.drawRect(0f, 0f, w, h, p)
            }

            1 -> {
                p.color = withAlpha(MediaState.dark, op)
                c.drawRect(0f, 0f, w, h, p)
                p.shader = RadialGradient(
                    artCx, artCy, max(w, h) * 0.8f,
                    intArrayOf(withAlpha(MediaState.accent, 0.35f * op), 0x00000000),
                    null, Shader.TileMode.CLAMP
                )
                c.drawRect(0f, 0f, w, h, p)
                p.shader = null
            }

            else -> {
                p.color = withAlpha(MediaState.dark, op)
                c.drawRect(0f, 0f, w, h, p)
                val bb = blurred()
                if (bb != null) {
                    val s = min(bb.width, bb.height)
                    src.set((bb.width - s) / 2, (bb.height - s) / 2, (bb.width + s) / 2, (bb.height + s) / 2)
                    // cover: crop the source to the card's aspect ratio
                    val ar = w / h
                    if (ar >= 1f) {
                        val hh = (s / ar).toInt().coerceAtLeast(1)
                        src.set((bb.width - s) / 2, (bb.height - hh) / 2, (bb.width + s) / 2, (bb.height + hh) / 2)
                    } else {
                        val ww = (s * ar).toInt().coerceAtLeast(1)
                        src.set((bb.width - ww) / 2, (bb.height - s) / 2, (bb.width + ww) / 2, (bb.height + s) / 2)
                    }
                    rect2.set(0f, 0f, w, h)
                    p.isFilterBitmap = true
                    p.alpha = al(op)
                    c.drawBitmap(bb, src, rect2, p)
                    p.alpha = 255
                }
                p.color = withAlpha(Color.BLACK, 0.42f * op)
                c.drawRect(0f, 0f, w, h, p)
            }
        }
    }

    /** Soft blur of the artwork (see SoftBlur). */
    private fun blurred(): Bitmap? {
        val a = MediaState.art ?: return null
        val key = System.identityHashCode(a) * 31 + prefs.blurAmount
        if (blurBmp == null || key != blurKey) {
            blurBmp = SoftBlur.make(a, prefs.blurAmount)
            blurKey = key
            blurSrc = a
        }
        return blurBmp
    }

    // ------------------------------------------------------------------ art

    private fun drawArt(c: Canvas) {
        var r = artR
        if (prefs.vizStyle == 5 && !frozen) r *= 1f + 0.05f * Audio.beatEnv + 0.03f * Audio.level
        val shape = if (radial) 2 else prefs.artShape
        rect.set(artCx - r, artCy - r, artCx + r, artCy + r)
        val rr = when (shape) {
            0 -> 4f * d
            1 -> r * 0.22f
            else -> r
        }
        if (prefs.artShadow) {
            p.shader = null
            p.style = Paint.Style.FILL
            for (i in 0..3) {
                p.color = Color.argb(26, 0, 0, 0)
                val g = (i + 1) * 3f * d
                rect2.set(rect.left - g, rect.top - g + 6f * d, rect.right + g, rect.bottom + g + 6f * d)
                c.drawRoundRect(rect2, rr + g, rr + g, p)
            }
        }
        val art = MediaState.art
        c.save()
        path.reset()
        path.addRoundRect(rect, rr, rr, Path.Direction.CW)
        c.clipPath(path)
        if (art != null) {
            val s = min(art.width, art.height)
            src.set((art.width - s) / 2, (art.height - s) / 2, (art.width + s) / 2, (art.height + s) / 2)
            p.isFilterBitmap = true
            p.shader = null
            p.alpha = 255
            c.drawBitmap(art, src, rect, p)
        } else {
            p.shader = LinearGradient(
                rect.left, rect.top, rect.right, rect.bottom,
                MediaState.accent, MediaState.accent2, Shader.TileMode.CLAMP
            )
            c.drawRect(rect, p)
            p.shader = null
            tp.typeface = Typeface.DEFAULT
            tp.textAlign = Paint.Align.CENTER
            tp.textSize = r * 0.9f
            tp.color = withAlpha(Color.WHITE, 0.85f)
            c.drawText("♪", artCx, artCy + r * 0.3f, tp)
        }
        c.restore()
    }

    // ------------------------------------------------------------------ text

    private fun fit(t: String, paint: Paint, maxW: Float): String {
        if (maxW <= 0f) return ""
        if (paint.measureText(t) <= maxW) return t
        val ell = paint.measureText("…")
        val n = paint.breakText(t, true, max(maxW - ell, 0f), null)
        return t.substring(0, n).trimEnd() + "…"
    }

    private fun drawTexts(c: Canvas) {
        fonts()
        val col = textCol()
        var title = MediaState.title
        var artist = MediaState.artist
        if (prefs.showAlbum && MediaState.album.isNotEmpty() && artist.isNotEmpty()) {
            artist = artist + "  ·  " + MediaState.album
        }
        if (title.isEmpty()) {
            title = "Nothing playing"
            artist = if (MediaState.status.startsWith("Needs")) "Turn on notification access" else "Start music in any app"
        }
        val rsv = if (!centered && textRight >= cardW - 20f * d) chipsReserve() else 0f
        val maxW = textRight - rsv - (if (centered) 16f * d else textX)
        val align = if (centered) Paint.Align.CENTER else Paint.Align.LEFT
        val x = if (centered) textX else textX
        tp.shader = null
        tp.textAlign = align
        tp.typeface = if (prefs.titleBold) tfBold else tfReg
        tp.textSize = prefs.titleSize * d * (if (portrait) 1.25f else 1f)
        tp.color = col
        val availW = if (centered) textRight - 16f * d - 16f * d else maxW
        val key = title + "|" + artist + "|" + availW.toInt()
        if (key != lastTextKey) { lastTextKey = key; textT0 = SystemClock.uptimeMillis() }
        scrolling = false
        scrollText(c, title, tp, x, titleY, availW, align, 0)
        tp.typeface = tfReg
        tp.textSize = prefs.artistSize * d * (if (portrait) 1.15f else 1f)
        tp.color = withAlpha(col, 0.68f)
        scrollText(c, artist, tp, x, artistY, availW, align, 1)
    }

    /** Draws text that fits normally, or slowly scrolls it in a loop when it is too long. */
    private fun scrollText(c: Canvas, t: String, paint: Paint, x: Float, y: Float, availW: Float, align: Paint.Align, line: Int) {
        if (availW <= 0f) return
        val w = paint.measureText(t)
        if (w <= availW) {
            c.drawText(t, x, y, paint)
            return
        }
        scrolling = true
        val left = if (align == Paint.Align.CENTER) x - availW / 2f else x
        val gap = 40f * d
        val speed = prefs.scrollSpeed * d
        val delay = 1800L
        val el = SystemClock.uptimeMillis() - textT0 - delay - line * 400L
        val period = w + gap
        val off = if (el <= 0) 0f else (el / 1000f * speed) % period
        val fm = paint.fontMetrics
        val saved = paint.textAlign
        paint.textAlign = Paint.Align.LEFT
        c.save()
        c.clipRect(left, y + fm.ascent, left + availW, y + fm.descent)
        c.drawText(t, left - off, y, paint)
        if (off > 0f) c.drawText(t, left - off + period, y, paint)
        c.restore()
        paint.textAlign = saved
    }

    // ------------------------------------------------------------------ controls

    private fun drawControls(c: Canvas) {
        val col = textCol()
        val minimal = prefs.controlStyle == 1
        p.shader = null
        p.style = Paint.Style.FILL
        // play button
        val pcx = hitPlay.centerX()
        val pcy = hitPlay.centerY()
        val ps = hitPlay.width()
        if (!minimal) {
            p.color = col
            c.drawCircle(pcx, pcy, ps * 0.5f, p)
        }
        val playIconCol = if (minimal) col else (if (isLight(col)) 0xFF101114.toInt() else Color.WHITE)
        p.color = playIconCol
        p.pathEffect = CornerPathEffect(ps * 0.07f)
        if (MediaState.playing) {
            val s = ps * (if (minimal) 0.5f else 0.36f)
            rect.set(pcx - s * 0.5f, pcy - s * 0.6f, pcx - s * 0.12f, pcy + s * 0.6f)
            c.drawRoundRect(rect, s * 0.1f, s * 0.1f, p)
            rect.set(pcx + s * 0.12f, pcy - s * 0.6f, pcx + s * 0.5f, pcy + s * 0.6f)
            c.drawRoundRect(rect, s * 0.1f, s * 0.1f, p)
        } else {
            val s = ps * (if (minimal) 0.5f else 0.38f)
            path.reset()
            path.moveTo(pcx - s * 0.38f, pcy - s * 0.62f)
            path.lineTo(pcx - s * 0.38f, pcy + s * 0.62f)
            path.lineTo(pcx + s * 0.62f, pcy)
            path.close()
            c.drawPath(path, p)
        }
        // prev / next
        p.color = col
        val s2 = hitPrev.width() * 0.36f
        val nx = hitNext.centerX()
        val ny = hitNext.centerY()
        path.reset()
        path.moveTo(nx - s2 * 0.9f, ny - s2)
        path.lineTo(nx - s2 * 0.9f, ny + s2)
        path.lineTo(nx + s2 * 0.5f, ny)
        path.close()
        c.drawPath(path, p)
        rect.set(nx + s2 * 0.62f, ny - s2, nx + s2 * 0.98f, ny + s2)
        c.drawRoundRect(rect, s2 * 0.15f, s2 * 0.15f, p)
        val vx = hitPrev.centerX()
        val vy = hitPrev.centerY()
        path.reset()
        path.moveTo(vx + s2 * 0.9f, vy - s2)
        path.lineTo(vx + s2 * 0.9f, vy + s2)
        path.lineTo(vx - s2 * 0.5f, vy)
        path.close()
        c.drawPath(path, p)
        rect.set(vx - s2 * 0.98f, vy - s2, vx - s2 * 0.62f, vy + s2)
        c.drawRoundRect(rect, s2 * 0.15f, s2 * 0.15f, p)
        p.pathEffect = null
    }

    private fun drawProgress(c: Canvas, w: Float) {
        val pad = 16f * d
        val dur = MediaState.durationMs
        val frac = if (dragFrac >= 0f) dragFrac else if (dur > 0) (MediaState.positionMs().toFloat() / dur).coerceIn(0f, 1f) else 0f
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 4f * d
        p.color = withAlpha(textCol(), 0.32f)
        c.drawLine(pad, progCy, w - pad, progCy, p)
        val kx = pad + (w - 2f * pad) * frac
        if (frac > 0f) {
            p.strokeWidth = 4.5f * d
            p.shader = hGrad(pad, w - pad)
            c.drawLine(pad, progCy, kx, progCy, p)
            p.shader = null
        }
        // knob so the position is easy to see
        p.style = Paint.Style.FILL
        p.color = Color.argb(90, 0, 0, 0)
        c.drawCircle(kx, progCy + 0.5f * d, (if (dragFrac >= 0f) 9f else 7f) * d, p)
        p.color = textCol()
        c.drawCircle(kx, progCy, (if (dragFrac >= 0f) 7.5f else 5.5f) * d, p)
        p.style = Paint.Style.FILL
    }

    // ------------------------------------------------------------------ effects state

    private fun onBeat() {
        val style = prefs.vizStyle
        if (style == 5) {
            var idx = 0
            var oldest = -1f
            for (i in rAge.indices) if (rAge[i] > oldest) { oldest = rAge[i]; idx = i }
            rAge[idx] = 0f
        } else if (style == 6) {
            for (i in 0 until 10) spawn(2.4f)
        }
    }

    private fun spawn(speedMul: Float) {
        var idx = -1
        for (i in 0 until pn) if (plife[i] <= 0f) { idx = i; break }
        if (idx < 0) return
        val ang = rnd.nextFloat() * 6.2831855f
        val ca = cos(ang)
        val sa = sin(ang)
        val speed = (25f + rnd.nextFloat() * 60f) * d * speedMul
        px[idx] = artCx + ca * artR
        py[idx] = artCy + sa * artR
        pvx[idx] = ca * speed
        pvy[idx] = sa * speed
        pmax[idx] = 1.2f + rnd.nextFloat() * 1.4f
        plife[idx] = pmax[idx]
        psize[idx] = (1.5f + rnd.nextFloat() * 2.8f) * d
        phue[idx] = rnd.nextFloat()
    }

    private fun updateEffects(dt: Float, sens: Float) {
        if (frozen) return
        val bc = Audio.beatCount
        if (bc != lastBeat) {
            lastBeat = bc
            onBeat()
        }
        for (i in rAge.indices) if (rAge[i] < 9f) rAge[i] += dt
        if (prefs.vizStyle == 6) {
            if (MediaState.playing) {
                spawnAcc += dt * (6f + 70f * Audio.level * sens)
                while (spawnAcc >= 1f) {
                    spawnAcc -= 1f
                    spawn(1f)
                }
            }
        }
        for (i in 0 until pn) {
            if (plife[i] <= 0f) continue
            plife[i] -= dt
            px[i] += pvx[i] * dt
            py[i] += pvy[i] * dt
            pvy[i] -= 10f * d * dt
            val k = 1f - 0.5f * dt
            pvx[i] *= k
            pvy[i] *= k
        }
    }

    // ------------------------------------------------------------------ visualizers

    private fun frozenV(i: Int, n: Int): Float =
        (0.30f + 0.62f * abs(sin(i * 0.55f + 1.3f)) * (1f - 0.45f * i / n)).coerceIn(0f, 1f)

    private fun levelAt(i: Int, n: Int): Float =
        if (frozen) frozenV(i, n) else Audio.band(i, n)

    private fun drawStrip(c: Canvas) {
        val a = prefs.vizOpacity / 100f
        val sens = prefs.vizSens / 100f
        p.shader = null
        p.style = Paint.Style.FILL
        when (prefs.vizStyle) {
            0 -> drawBars(c, a)
            1 -> drawBars(c, a)
            2 -> drawScope(c, a, sens)
            else -> drawFilled(c, a)
        }
    }

    private fun lowMode(): Int =
        if (prefs.vizStyle == 1 && !prefs.has("vizLow")) 2 else prefs.vizLow.coerceIn(0, 3)

    private fun vertMode(): Int = if (prefs.vizStyle == 1) 2 else prefs.vizVert.coerceIn(0, 2)

    /** Calls f(band, bandCount, slot) for every bar, placing the low end where the user chose. */
    private inline fun eachSlot(n: Int, f: (Int, Int, Int) -> Unit) {
        when (lowMode()) {
            0 -> for (i in 0 until n) f(i, n, i)
            1 -> for (i in 0 until n) f(i, n, n - 1 - i)
            else -> {
                val m = n / 2
                val centre = lowMode() == 2
                for (i in 0 until m) {
                    if (centre) { f(i, m, m + i); f(i, m, m - 1 - i) } else { f(i, m, i); f(i, m, n - 1 - i) }
                }
            }
        }
    }

    /** Position along the strip (0..1) to position along the spectrum (0 = low end). */
    private fun spec(u: Float): Float = when (lowMode()) {
        0 -> u
        1 -> 1f - u
        2 -> abs(2f * u - 1f)
        else -> 1f - abs(2f * u - 1f)
    }

    private fun drawOneBar(c: Canvas, x: Float, bw: Float, y0: Float, len: Float, up: Boolean) {
        val cell = 5f * d
        val gap = 2f * d
        if (prefs.vizSegments) {
            val cnt = max(1, (len / (cell + gap)).toInt())
            for (k in 0 until cnt) {
                val off = k * (cell + gap)
                if (up) rect.set(x, y0 - off - cell, x + bw, y0 - off) else rect.set(x, y0 + off, x + bw, y0 + off + cell)
                c.drawRoundRect(rect, 1.5f * d, 1.5f * d, p)
            }
        } else {
            if (up) rect.set(x, y0 - len, x + bw, y0) else rect.set(x, y0, x + bw, y0 + len)
            c.drawRoundRect(rect, bw / 2f, bw / 2f, p)
        }
    }

    private fun drawBars(c: Canvas, a: Float) {
        var n = prefs.vizBars.coerceIn(8, 64)
        if (lowMode() >= 2) n = (n / 2) * 2
        val r = stripRect
        if (r.width() < 20f || r.height() < 10f) return
        val vert = vertMode()
        val reflect = prefs.vizReflect && vert == 0
        val base = when (vert) {
            0 -> if (reflect) r.top + r.height() * 0.72f else r.bottom
            1 -> r.top
            else -> r.centerY()
        }
        val hh = when (vert) {
            0 -> base - r.top
            1 -> r.bottom - r.top
            else -> r.height() / 2f
        }
        val pitch = r.width() / n
        val bw = max(pitch * 0.62f, 2f)
        eachSlot(n) { i, cnt, slot ->
            val v = levelAt(i, cnt).coerceIn(0f, 1.1f)
            val bh = max(bw, v * hh)
            val x = r.left + pitch * slot + (pitch - bw) / 2f
            val col = vizCol(i / (cnt - 1f).coerceAtLeast(1f))
            p.color = withAlpha(col, a)
            when (vert) {
                0 -> drawOneBar(c, x, bw, base, bh, true)
                1 -> drawOneBar(c, x, bw, base, bh, false)
                else -> {
                    drawOneBar(c, x, bw, base, bh, true)
                    drawOneBar(c, x, bw, base, bh, false)
                }
            }
            if (reflect) {
                val rh = min(bh * 0.45f, r.bottom - base)
                if (rh > 1f) {
                    p.color = withAlpha(col, a * 0.18f)
                    rect.set(x, base + 2f * d, x + bw, base + 2f * d + rh)
                    c.drawRoundRect(rect, bw / 2f, bw / 2f, p)
                }
            }
        }
    }

    private fun smoothPath(pts: Int, xAt: (Int) -> Float, yAt: (Int) -> Float) {
        path.reset()
        path.moveTo(xAt(0), yAt(0))
        for (j in 1 until pts) {
            val mx = (xAt(j - 1) + xAt(j)) / 2f
            val my = (yAt(j - 1) + yAt(j)) / 2f
            path.quadTo(xAt(j - 1), yAt(j - 1), mx, my)
        }
        path.lineTo(xAt(pts - 1), yAt(pts - 1))
    }

    private fun drawScope(c: Canvas, a: Float, sens: Float) {
        val r = stripRect
        if (r.width() < 20f || r.height() < 10f) return
        val yc = r.centerY()
        val half = r.height() / 2f * 0.92f
        val pts = Audio.W
        val gain = sens.coerceIn(0.3f, 2.5f)
        val vert = prefs.vizVert.coerceIn(0, 2)
        val flip = if (vert == 1) -1f else 1f
        smoothPath(pts,
            { r.left + r.width() * it / (pts - 1f) },
            {
                val v = if (frozen) 0.8f * sin(it * 0.33f) * sin(it * 0.07f + 0.6f) else Audio.wave[it] * gain
                yc - flip * v.coerceIn(-1f, 1f) * half
            })
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.shader = hGrad(r.left, r.right)
        if (prefs.vizGlow) {
            p.strokeWidth = 9f * d; p.alpha = al(a * 0.10f); c.drawPath(path, p)
            p.strokeWidth = 5f * d; p.alpha = al(a * 0.20f); c.drawPath(path, p)
        }
        p.strokeWidth = 2.2f * d
        p.alpha = al(a)
        c.drawPath(path, p)
        p.shader = null
        p.alpha = 255
        p.style = Paint.Style.FILL
    }

    private fun drawFilled(c: Canvas, a: Float) {
        val r = stripRect
        if (r.width() < 20f || r.height() < 10f) return
        val pts = 48
        val vert = prefs.vizVert.coerceIn(0, 2)
        val hh = (if (vert == 2) r.height() / 2f else r.height()) * 0.95f
        val yc = r.centerY()
        fun vAt(j: Int): Float {
            val x = spec(j / (pts - 1f)) * (Audio.N - 1f)
            val i = x.toInt().coerceIn(0, Audio.N - 2)
            val f = x - i
            val v = if (frozen) 0.5f * (frozenV(i, 64) + frozenV(i + 1, 64))
            else Audio.disp[i] * (1f - f) + Audio.disp[i + 1] * f
            return v.coerceIn(0f, 1.1f)
        }
        val xAt = { j: Int -> r.left + r.width() * j / (pts - 1f) }
        val line = Path()
        val line2 = Path()
        val fill = Path()
        when (vert) {
            0 -> {
                smoothPath(pts, xAt) { r.bottom - max(2f * d, vAt(it) * hh) }
                line.set(path)
                path.lineTo(r.right, r.bottom); path.lineTo(r.left, r.bottom); path.close()
                fill.set(path)
            }
            1 -> {
                smoothPath(pts, xAt) { r.top + max(2f * d, vAt(it) * hh) }
                line.set(path)
                path.lineTo(r.right, r.top); path.lineTo(r.left, r.top); path.close()
                fill.set(path)
            }
            else -> {
                smoothPath(pts, xAt) { yc - max(1.5f * d, vAt(it) * hh) }
                line.set(path)
                smoothPath(pts, xAt) { yc + max(1.5f * d, vAt(it) * hh) }
                line2.set(path)
                fill.set(line)
                for (j in pts - 1 downTo 0) fill.lineTo(xAt(j), yc + max(1.5f * d, vAt(j) * hh))
                fill.close()
            }
        }
        p.shader = hGrad(r.left, r.right)
        p.style = Paint.Style.FILL
        p.alpha = al(a * 0.32f)
        c.drawPath(fill, p)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        if (prefs.vizGlow) {
            p.strokeWidth = 7f * d; p.alpha = al(a * 0.14f); c.drawPath(line, p)
            if (vert == 2) c.drawPath(line2, p)
        }
        p.strokeWidth = 2.2f * d
        p.alpha = al(a)
        c.drawPath(line, p)
        if (vert == 2) c.drawPath(line2, p)
        p.shader = null
        p.alpha = 255
        p.style = Paint.Style.FILL
    }

    private fun drawRadial(c: Canvas) {
        val a = prefs.vizOpacity / 100f
        val sens = prefs.vizSens / 100f
        val depth = prefs.vizDepth * d
        val r0 = artR + 5f * d
        p.shader = null
        if (prefs.vizStyle == 4) {
            val n = (prefs.vizBars.coerceIn(8, 64) / 2) * 2
            val m = n / 2
            val bw = (6.2831855f * r0 / n * 0.55f).coerceIn(2f * d, 5f * d)
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = bw
            c.save()
            c.translate(artCx, artCy)
            c.rotate(if (prefs.vizSpin) rot else 0f)
            for (k in 0 until m) {
                val v = levelAt(m - 1 - k, m).coerceIn(0f, 1.15f)
                val len = 3f * d + depth * v
                val ang = Math.toRadians((-90f + 180f * (k + 0.5f) / m).toDouble())
                val ca = cos(ang).toFloat()
                val sa = sin(ang).toFloat()
                p.color = withAlpha(vizCol(k / (m - 1f)), a)
                c.drawLine(ca * r0, sa * r0, ca * (r0 + len), sa * (r0 + len), p)
                c.drawLine(-ca * r0, sa * r0, -ca * (r0 + len), sa * (r0 + len), p)
            }
            c.restore()
            p.style = Paint.Style.FILL
        } else {
            val be = if (frozen) 0.5f else Audio.beatEnv
            val lv = if (frozen) 0.4f else Audio.level * sens
            p.shader = RadialGradient(
                artCx, artCy, r0 + depth * (1.1f + 0.5f * be),
                intArrayOf(withAlpha(vizCol(0.3f), a * (0.30f + 0.35f * be)), 0x00000000),
                floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP
            )
            c.drawCircle(artCx, artCy, r0 + depth * 1.6f, p)
            p.shader = null
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f * d
            p.color = withAlpha(vizCol(0.1f), a * (0.55f + 0.4f * be))
            c.drawCircle(artCx, artCy, r0 + lv * 6f * d, p)
            p.strokeWidth = 1.2f * d
            p.color = withAlpha(vizCol(0.9f), a * 0.35f)
            c.drawCircle(artCx, artCy, r0 + 6f * d + lv * 10f * d, p)
            for (i in rAge.indices) {
                val age = rAge[i]
                if (age >= 1.2f) continue
                val t = age / 1.2f
                val e = 1f - (1f - t) * (1f - t)
                p.strokeWidth = 2.4f * d
                p.color = withAlpha(vizCol(0.5f + 0.5f * t), a * 0.6f * (1f - t))
                c.drawCircle(artCx, artCy, r0 + depth * 1.9f * e, p)
            }
            if (frozen) {
                p.strokeWidth = 2f * d
                p.color = withAlpha(vizCol(0.5f), a * 0.3f)
                c.drawCircle(artCx, artCy, r0 + depth * 0.9f, p)
            }
            p.style = Paint.Style.FILL
        }
    }

    private fun drawParticles(c: Canvas) {
        val a = prefs.vizOpacity / 100f
        p.shader = null
        p.style = Paint.Style.FILL
        if (frozen) {
            for (i in 0 until 30) {
                val fx = abs(sin(i * 12.9898f)) % 1f
                val fy = abs(sin(i * 78.233f)) % 1f
                p.color = withAlpha(vizCol(fx), a * (0.25f + 0.5f * fy))
                c.drawCircle(fx * (stripRect.right + 16f * d), fy * (progCy), (1.5f + 2.5f * fy) * d, p)
            }
            return
        }
        for (i in 0 until pn) {
            val life = plife[i]
            if (life <= 0f) continue
            val f = (life / pmax[i]).coerceIn(0f, 1f)
            p.color = withAlpha(vizCol(phue[i]), a * f)
            c.drawCircle(px[i], py[i], psize[i] * (0.5f + 0.5f * f), p)
        }
    }

    private fun drawGlow(c: Canvas, w: Float, h: Float) {
        val a = prefs.vizOpacity / 100f * (if (layerMode == 2) 0.55f else 1f)
        val sens = prefs.vizSens / 100f
        val be = if (frozen) 0.4f else Audio.beatEnv
        val lv = if (frozen) 0.4f else Audio.level * sens * 2f
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            artCx, artCy, artR * (2.4f + 0.7f * be + 0.7f * lv),
            intArrayOf(withAlpha(vizCol(0.2f), a * (0.40f + 0.45f * be)), 0x00000000),
            null, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = LinearGradient(
            0f, h * 0.55f, 0f, h,
            intArrayOf(0x00000000, withAlpha(vizCol(0.8f), a * (0.14f + 0.35f * lv.coerceAtMost(1f)))),
            null, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, h * 0.55f, w, h, p)
        p.shader = null
    }
}
