package app.nowplaying

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws the whole now-playing card (background, artwork, text, visualizer, controls, progress)
 * onto any Canvas. Used by the live view, the full-screen player, the floating card and the
 * home-screen widget (which renders it to a bitmap).
 */
class CardRenderer(private val ctx: Context, private val prefs: Prefs) {

    companion object {
        val FONTS = listOf("Clean", "Light", "Condensed", "Medium", "Serif", "Mono", "Casual", "Script")
        private val FAMILIES = listOf(
            "sans-serif", "sans-serif-light", "sans-serif-condensed", "sans-serif-medium",
            "serif", "monospace", "casual", "cursive"
        )
        val STYLES = listOf(
            "Bars", "Mirrored bars", "Oscilloscope", "Filled wave",
            "Circular spectrum", "Pulse ring", "Particles", "Blurred glow"
        )
    }

    /** Widget: no drawn controls (real buttons sit in the reserved band), static visualizer. */
    var widgetMode = false
    var frozen = false
    var fullScreen = false
    var reserveBottomDp = 0f

    /** 0..1 while the user is dragging the progress line, else -1. */
    var dragFrac = -1f

    val hitPrev = RectF()
    val hitPlay = RectF()
    val hitNext = RectF()
    val hitSeek = RectF()
    var hasControls = false

    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val rect2 = RectF()
    private val path = Path()
    private val clipPath = Path()
    private val src = Rect()
    private val rnd = java.util.Random(7)

    // layout results
    private var portrait = false
    private var radial = false
    private var strip = false
    private var artCx = 0f
    private var artCy = 0f
    private var artR = 0f
    private val stripRect = RectF()
    private var textX = 0f
    private var textRight = 0f
    private var titleY = 0f
    private var artistY = 0f
    private var ctlCy = 0f
    private var progCy = 0f
    private var centered = false

    // animation state
    private var hueShift = 0f
    private var rot = 0f
    private var time = 0f
    private var lastBeat = 0
    private val rAge = FloatArray(6) { 9f }
    private var rNext = 0
    private val pn = 90
    private val px = FloatArray(pn)
    private val py = FloatArray(pn)
    private val pvx = FloatArray(pn)
    private val pvy = FloatArray(pn)
    private val plife = FloatArray(pn)
    private val pmax = FloatArray(pn) { 1f }
    private val psize = FloatArray(pn)
    private val phue = FloatArray(pn)
    private var spawnAcc = 0f

    // caches
    private var blurSrc: Bitmap? = null
    private var blurKey = -1
    private var blurBmp: Bitmap? = null
    private var gradSig = 0
    private var gradX0 = 0f
    private var gradX1 = 0f
    private var grad: Shader? = null
    private var tfKey = -1
    private var tfBold: Typeface = Typeface.DEFAULT_BOLD
    private var tfReg: Typeface = Typeface.DEFAULT

    fun hasMotion(): Boolean {
        for (a in rAge) if (a < 1.3f) return true
        for (l in plife) if (l > 0f) return true
        return false
    }

    // ------------------------------------------------------------------ layout

    private fun progArea(): Float = if (prefs.showProgress) 26f * d else 12f * d

    private fun compactArt(rad: Boolean): Float =
        if (rad) prefs.artSize * 0.72f * d else prefs.artSize * d

    /** Natural height for a compact (wrap_content) card of width w. */
    fun heightFor(): Float {
        val style = prefs.vizStyle
        val rad = style == 4 || style == 5
        val st = style in 0..3
        val ring = if (rad) prefs.vizDepth * d + 6f * d else 0f
        val block = compactArt(rad) + 2f * ring
        return 16f * d + block + (if (st) 6f * d + prefs.vizHeight * d else 0f) +
            progArea() + reserveBottomDp * d
    }

    private fun layout(w: Float, h: Float) {
        val style = prefs.vizStyle
        radial = style == 4 || style == 5
        strip = style in 0..3
        val pad = 16f * d
        val reserve = reserveBottomDp * d
        val prog = progArea()
        val bottomLimit = h - reserve - prog
        progCy = h - reserve - (if (prefs.showProgress) 13f * d else 6f * d)
        portrait = fullScreen || h > w * 1.15f
        centered = portrait
        hasControls = prefs.showControls && !widgetMode
        val ring = if (radial) prefs.vizDepth * d + 6f * d else 0f
        val ts = prefs.titleSize * d
        val asz = prefs.artistSize * d

        if (!portrait) {
            var a = compactArt(radial)
            val stripH = if (strip) 6f * d + prefs.vizHeight * d else 0f
            val availTop = bottomLimit - pad - stripH
            var block = a + 2f * ring
            if (block > availTop) {
                block = max(availTop, 48f * d)
                a = max(block - 2f * ring, 32f * d)
                block = a + 2f * ring
            }
            artR = a / 2f
            val left = prefs.artPos == 0
            val blockLeft = if (left) pad else w - pad - block
            artCx = blockLeft + block / 2f
            artCy = pad + block / 2f
            textX = if (left) blockLeft + block + 12f * d else pad
            textRight = if (left) w - pad else blockLeft - 12f * d
            val top = pad + 2f * d
            if (hasControls) {
                ctlCy = pad + block - 22f * d
                titleY = top + ts * 0.95f
                artistY = titleY + asz * 1.5f
            } else {
                val groupH = ts * 1.0f + asz * 1.5f
                titleY = pad + (block - groupH) / 2f + ts * 0.95f
                artistY = titleY + asz * 1.5f
            }
            if (strip) {
                stripRect.set(pad, pad + block + 6f * d, w - pad, bottomLimit - 4f * d)
            }
        } else {
            val top = pad + (if (fullScreen) 36f * d else 0f)
            var a = if (strip) min(w * 0.56f, h * 0.30f) else min(w * 0.70f, h * 0.40f)
            if (radial) a = min(a, w - 2f * pad - 2f * ring)
            val block = a + 2f * ring
            artR = a / 2f
            artCx = w / 2f
            artCy = top + block / 2f
            textX = w / 2f
            textRight = w - pad
            titleY = artCy + block / 2f + 14f * d + ts
            artistY = titleY + asz * 1.6f
            ctlCy = bottomLimit - 50f * d
            if (strip) {
                val t = artistY + 22f * d
                var b = ctlCy - 46f * d
                if (b - t < 40f * d) b = t + 40f * d
                stripRect.set(pad, t, w - pad, b)
            }
        }

        // controls
        if (hasControls) {
            if (portrait) {
                val s = 52f * d
                val ps = 68f * d
                val gap = 10f * d
                val total = s + ps + s + 2f * gap
                var x = w / 2f - total / 2f
                hitPrev.set(x, ctlCy - s / 2f, x + s, ctlCy + s / 2f); x += s + gap
                hitPlay.set(x, ctlCy - ps / 2f, x + ps, ctlCy + ps / 2f); x += ps + gap
                hitNext.set(x, ctlCy - s / 2f, x + s, ctlCy + s / 2f)
            } else {
                val s = 40f * d
                val ps = 48f * d
                val gap = 6f * d
                var x = textX - 4f * d
                hitPrev.set(x, ctlCy - s / 2f, x + s, ctlCy + s / 2f); x += s + gap
                hitPlay.set(x, ctlCy - ps / 2f, x + ps, ctlCy + ps / 2f); x += ps + gap
                hitNext.set(x, ctlCy - s / 2f, x + s, ctlCy + s / 2f)
            }
        } else {
            hitPrev.setEmpty(); hitPlay.setEmpty(); hitNext.setEmpty()
        }
        if (prefs.showProgress && !widgetMode) {
            hitSeek.set(pad - 8f * d, progCy - 18f * d, w - pad + 8f * d, progCy + 18f * d)
        } else {
            hitSeek.setEmpty()
        }
    }

    // ------------------------------------------------------------------ colors

    private fun lerp(a: Int, b: Int, t: Float): Int = Color.argb(
        (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * t).toInt(),
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    private fun vizCol(t: Float): Int {
        val tt = t.coerceIn(0f, 1f)
        return when (prefs.vizColorMode) {
            0 -> prefs.vizColor
            1 -> lerp(prefs.vizColor, prefs.vizColor2, tt)
            2 -> lerp(MediaState.accent, MediaState.accent2, tt)
            else -> Color.HSVToColor(floatArrayOf((hueShift + tt * 300f) % 360f, 0.72f, 1f))
        }
    }

    private fun al(x: Float): Int = (255f * x).toInt().coerceIn(0, 255)

    private fun withAlpha(c: Int, a: Float): Int =
        Color.argb(al(a), Color.red(c), Color.green(c), Color.blue(c))

    fun textColorNow(): Int = textCol()

    private fun textCol(): Int = when (prefs.textMode) {
        0 -> Color.WHITE
        1 -> 0xFF101114.toInt()
        2 -> MediaState.light
        else -> prefs.textColor
    }

    private fun isLight(c: Int): Boolean =
        (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) > 150f

    /** Horizontal gradient across the strip for line/fill styles. */
    private fun hGrad(x0: Float, x1: Float): Shader {
        val sig = prefs.vizColorMode * 31 + vizCol(0f) * 7 + vizCol(1f) * 3 +
            (if (prefs.vizColorMode == 3) (hueShift / 4f).toInt() else 0)
        if (grad == null || sig != gradSig || x0 != gradX0 || x1 != gradX1) {
            grad = LinearGradient(
                x0, 0f, x1, 0f,
                IntArray(5) { vizCol(it / 4f) }, null, Shader.TileMode.CLAMP
            )
            gradSig = sig; gradX0 = x0; gradX1 = x1
        }
        return grad!!
    }

    private fun fonts() {
        val key = prefs.font
        if (key != tfKey) {
            tfKey = key
            val fam = FAMILIES[key.coerceIn(0, FAMILIES.size - 1)]
            tfBold = Typeface.create(fam, Typeface.BOLD)
            tfReg = Typeface.create(fam, Typeface.NORMAL)
        }
    }

    // ------------------------------------------------------------------ main draw

    fun draw(c: Canvas, w: Float, h: Float, dt: Float) {
        layout(w, h)
        time += dt
        hueShift = (hueShift + dt * 20f) % 360f
        if (prefs.vizSpin) rot = (rot + dt * 6f) % 360f
        val sens = prefs.vizSens / 100f
        updateEffects(dt, sens)

        val corner = if (fullScreen) 0f else prefs.corner * d
        c.save()
        rect.set(0f, 0f, w, h)
        clipPath.reset()
        clipPath.addRoundRect(rect, corner, corner, Path.Direction.CW)
        c.clipPath(clipPath)

        drawBackground(c, w, h)
        val style = prefs.vizStyle
        if (style == 7) drawGlow(c, w, h)
        if (style == 6) drawParticles(c)
        if (strip) drawStrip(c)
        if (radial) drawRadial(c)
        drawArt(c)
        drawTexts(c)
        if (hasControls) drawControls(c)
        if (prefs.showProgress) drawProgress(c, w)
        c.restore()
    }

    // ------------------------------------------------------------------ background

    private fun drawBackground(c: Canvas, w: Float, h: Float) {
        val op = if (fullScreen) 1f else prefs.bgOpacity / 100f
        p.shader = null
        p.style = Paint.Style.FILL
        if (fullScreen) {
            p.color = Color.BLACK
            c.drawRect(0f, 0f, w, h, p)
        }
        when (prefs.bgMode) {
            0 -> {
                p.color = withAlpha(prefs.bgColor, Color.alpha(prefs.bgColor) / 255f * op)
                c.drawRect(0f, 0f, w, h, p)
            }

            1 -> {
                p.color = withAlpha(MediaState.dark, op)
                c.drawRect(0f, 0f, w, h, p)
                p.shader = RadialGradient(
                    artCx, artCy, max(w, h) * 0.8f,
                    intArrayOf(withAlpha(MediaState.accent, 0.35f * op), 0x00000000),
                    null, Shader.TileMode.CLAMP
                )
                c.drawRect(0f, 0f, w, h, p)
                p.shader = null
            }

            else -> {
                p.color = withAlpha(MediaState.dark, op)
                c.drawRect(0f, 0f, w, h, p)
                val bb = blurred()
                if (bb != null) {
                    val s = min(bb.width, bb.height)
                    src.set((bb.width - s) / 2, (bb.height - s) / 2, (bb.width + s) / 2, (bb.height + s) / 2)
                    // cover: crop the source to the card's aspect ratio
                    val ar = w / h
                    if (ar >= 1f) {
                        val hh = (s / ar).toInt().coerceAtLeast(1)
                        src.set((bb.width - s) / 2, (bb.height - hh) / 2, (bb.width + s) / 2, (bb.height + hh) / 2)
                    } else {
                        val ww = (s * ar).toInt().coerceAtLeast(1)
                        src.set((bb.width - ww) / 2, (bb.height - s) / 2, (bb.width + ww) / 2, (bb.height + s) / 2)
                    }
                    rect2.set(0f, 0f, w, h)
                    p.isFilterBitmap = true
                    p.alpha = al(op)
                    c.drawBitmap(bb, src, rect2, p)
                    p.alpha = 255
                }
                p.color = withAlpha(Color.BLACK, 0.42f * op)
                c.drawRect(0f, 0f, w, h, p)
            }
        }
    }

    /** Cheap blur: shrink the artwork a lot, then scale it back up smoothly. */
    private fun blurred(): Bitmap? {
        val a = MediaState.art ?: return null
        val key = System.identityHashCode(a) * 31 + prefs.blurAmount
        if (blurBmp == null || key != blurKey) {
            val t = (40 - prefs.blurAmount * 0.32f).toInt().coerceIn(8, 40)
            val tiny = Bitmap.createScaledBitmap(a, t, t, true)
            blurBmp = Bitmap.createScaledBitmap(tiny, t * 5, t * 5, true)
            blurKey = key
            blurSrc = a
        }
        return blurBmp
    }

    // ------------------------------------------------------------------ art

    private fun drawArt(c: Canvas) {
        var r = artR
        if (prefs.vizStyle == 5 && !frozen) r *= 1f + 0.05f * Audio.beatEnv + 0.03f * Audio.level
        val shape = if (radial) 2 else prefs.artShape
        rect.set(artCx - r, artCy - r, artCx + r, artCy + r)
        val rr = when (shape) {
            0 -> 4f * d
            1 -> r * 0.22f
            else -> r
        }
        if (prefs.artShadow) {
            p.shader = null
            p.style = Paint.Style.FILL
            for (i in 0..3) {
                p.color = Color.argb(26, 0, 0, 0)
                val g = (i + 1) * 3f * d
                rect2.set(rect.left - g, rect.top - g + 6f * d, rect.right + g, rect.bottom + g + 6f * d)
                c.drawRoundRect(rect2, rr + g, rr + g, p)
            }
        }
        val art = MediaState.art
        c.save()
        path.reset()
        path.addRoundRect(rect, rr, rr, Path.Direction.CW)
        c.clipPath(path)
        if (art != null) {
            val s = min(art.width, art.height)
            src.set((art.width - s) / 2, (art.height - s) / 2, (art.width + s) / 2, (art.height + s) / 2)
            p.isFilterBitmap = true
            p.shader = null
            p.alpha = 255
            c.drawBitmap(art, src, rect, p)
        } else {
            p.shader = LinearGradient(
                rect.left, rect.top, rect.right, rect.bottom,
                MediaState.accent, MediaState.accent2, Shader.TileMode.CLAMP
            )
            c.drawRect(rect, p)
            p.shader = null
            tp.typeface = Typeface.DEFAULT
            tp.textAlign = Paint.Align.CENTER
            tp.textSize = r * 0.9f
            tp.color = withAlpha(Color.WHITE, 0.85f)
            c.drawText("♪", artCx, artCy + r * 0.3f, tp)
        }
        c.restore()
    }

    // ------------------------------------------------------------------ text

    private fun fit(t: String, paint: Paint, maxW: Float): String {
        if (maxW <= 0f) return ""
        if (paint.measureText(t) <= maxW) return t
        val ell = paint.measureText("…")
        val n = paint.breakText(t, true, max(maxW - ell, 0f), null)
        return t.substring(0, n).trimEnd() + "…"
    }

    private fun drawTexts(c: Canvas) {
        fonts()
        val col = textCol()
        var title = MediaState.title
        var artist = MediaState.artist
        if (prefs.showAlbum && MediaState.album.isNotEmpty() && artist.isNotEmpty()) {
            artist = artist + "  ·  " + MediaState.album
        }
        if (title.isEmpty()) {
            title = "Nothing playing"
            artist = if (MediaState.status.startsWith("Needs")) "Turn on notification access" else "Start music in any app"
        }
        val maxW = textRight - (if (centered) 16f * d else textX)
        val align = if (centered) Paint.Align.CENTER else Paint.Align.LEFT
        val x = if (centered) textX else textX
        tp.shader = null
        tp.textAlign = align
        tp.typeface = if (prefs.titleBold) tfBold else tfReg
        tp.textSize = prefs.titleSize * d * (if (portrait) 1.25f else 1f)
        tp.color = col
        val availW = if (centered) textRight - 16f * d - 16f * d else maxW
        c.drawText(fit(title, tp, availW), x, titleY, tp)
        tp.typeface = tfReg
        tp.textSize = prefs.artistSize * d * (if (portrait) 1.15f else 1f)
        tp.color = withAlpha(col, 0.68f)
        c.drawText(fit(artist, tp, availW), x, artistY, tp)
    }

    // ------------------------------------------------------------------ controls

    private fun drawControls(c: Canvas) {
        val col = textCol()
        val minimal = prefs.controlStyle == 1
        p.shader = null
        p.style = Paint.Style.FILL
        // play button
        val pcx = hitPlay.centerX()
        val pcy = hitPlay.centerY()
        val ps = hitPlay.width()
        if (!minimal) {
            p.color = col
            c.drawCircle(pcx, pcy, ps * 0.5f, p)
        }
        val playIconCol = if (minimal) col else (if (isLight(col)) 0xFF101114.toInt() else Color.WHITE)
        p.color = playIconCol
        p.pathEffect = CornerPathEffect(ps * 0.07f)
        if (MediaState.playing) {
            val s = ps * (if (minimal) 0.5f else 0.36f)
            rect.set(pcx - s * 0.5f, pcy - s * 0.6f, pcx - s * 0.12f, pcy + s * 0.6f)
            c.drawRoundRect(rect, s * 0.1f, s * 0.1f, p)
            rect.set(pcx + s * 0.12f, pcy - s * 0.6f, pcx + s * 0.5f, pcy + s * 0.6f)
            c.drawRoundRect(rect, s * 0.1f, s * 0.1f, p)
        } else {
            val s = ps * (if (minimal) 0.5f else 0.38f)
            path.reset()
            path.moveTo(pcx - s * 0.38f, pcy - s * 0.62f)
            path.lineTo(pcx - s * 0.38f, pcy + s * 0.62f)
            path.lineTo(pcx + s * 0.62f, pcy)
            path.close()
            c.drawPath(path, p)
        }
        // prev / next
        p.color = col
        val s2 = hitPrev.width() * 0.36f
        val nx = hitNext.centerX()
        val ny = hitNext.centerY()
        path.reset()
        path.moveTo(nx - s2 * 0.9f, ny - s2)
        path.lineTo(nx - s2 * 0.9f, ny + s2)
        path.lineTo(nx + s2 * 0.5f, ny)
        path.close()
        c.drawPath(path, p)
        rect.set(nx + s2 * 0.62f, ny - s2, nx + s2 * 0.98f, ny + s2)
        c.drawRoundRect(rect, s2 * 0.15f, s2 * 0.15f, p)
        val vx = hitPrev.centerX()
        val vy = hitPrev.centerY()
        path.reset()
        path.moveTo(vx + s2 * 0.9f, vy - s2)
        path.lineTo(vx + s2 * 0.9f, vy + s2)
        path.lineTo(vx - s2 * 0.5f, vy)
        path.close()
        c.drawPath(path, p)
        rect.set(vx - s2 * 0.98f, vy - s2, vx - s2 * 0.62f, vy + s2)
        c.drawRoundRect(rect, s2 * 0.15f, s2 * 0.15f, p)
        p.pathEffect = null
    }

    private fun drawProgress(c: Canvas, w: Float) {
        val pad = 16f * d
        val dur = MediaState.durationMs
        val frac = if (dragFrac >= 0f) dragFrac else if (dur > 0) (MediaState.positionMs().toFloat() / dur).coerceIn(0f, 1f) else 0f
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 3f * d
        p.color = withAlpha(textCol(), 0.18f)
        c.drawLine(pad, progCy, w - pad, progCy, p)
        if (frac > 0f) {
            p.shader = hGrad(pad, w - pad)
            c.drawLine(pad, progCy, pad + (w - 2f * pad) * frac, progCy, p)
            p.shader = null
        }
        if (dragFrac >= 0f) {
            p.style = Paint.Style.FILL
            p.color = textCol()
            c.drawCircle(pad + (w - 2f * pad) * frac, progCy, 6f * d, p)
        }
        p.style = Paint.Style.FILL
    }

    // ------------------------------------------------------------------ effects state

    private fun onBeat() {
        val style = prefs.vizStyle
        if (style == 5) {
            var idx = 0
            var oldest = -1f
            for (i in rAge.indices) if (rAge[i] > oldest) { oldest = rAge[i]; idx = i }
            rAge[idx] = 0f
        } else if (style == 6) {
            for (i in 0 until 10) spawn(2.4f)
        }
    }

    private fun spawn(speedMul: Float) {
        var idx = -1
        for (i in 0 until pn) if (plife[i] <= 0f) { idx = i; break }
        if (idx < 0) return
        val ang = rnd.nextFloat() * 6.2831855f
        val ca = cos(ang)
        val sa = sin(ang)
        val speed = (25f + rnd.nextFloat() * 60f) * d * speedMul
        px[idx] = artCx + ca * artR
        py[idx] = artCy + sa * artR
        pvx[idx] = ca * speed
        pvy[idx] = sa * speed
        pmax[idx] = 1.2f + rnd.nextFloat() * 1.4f
        plife[idx] = pmax[idx]
        psize[idx] = (1.5f + rnd.nextFloat() * 2.8f) * d
        phue[idx] = rnd.nextFloat()
    }

    private fun updateEffects(dt: Float, sens: Float) {
        if (frozen) return
        val bc = Audio.beatCount
        if (bc != lastBeat) {
            lastBeat = bc
            onBeat()
        }
        for (i in rAge.indices) if (rAge[i] < 9f) rAge[i] += dt
        if (prefs.vizStyle == 6) {
            if (MediaState.playing) {
                spawnAcc += dt * (6f + 70f * Audio.level * sens)
                while (spawnAcc >= 1f) {
                    spawnAcc -= 1f
                    spawn(1f)
                }
            }
        }
        for (i in 0 until pn) {
            if (plife[i] <= 0f) continue
            plife[i] -= dt
            px[i] += pvx[i] * dt
            py[i] += pvy[i] * dt
            pvy[i] -= 10f * d * dt
            val k = 1f - 0.5f * dt
            pvx[i] *= k
            pvy[i] *= k
        }
    }

    // ------------------------------------------------------------------ visualizers

    private fun frozenV(i: Int, n: Int): Float =
        (0.30f + 0.62f * abs(sin(i * 0.55f + 1.3f)) * (1f - 0.45f * i / n)).coerceIn(0f, 1f)

    private fun levelAt(i: Int, n: Int): Float =
        if (frozen) frozenV(i, n) else Audio.band(i, n)

    private fun drawStrip(c: Canvas) {
        val a = prefs.vizOpacity / 100f
        val sens = prefs.vizSens / 100f
        p.shader = null
        p.style = Paint.Style.FILL
        when (prefs.vizStyle) {
            0 -> drawBars(c, a)
            1 -> drawMirrored(c, a)
            2 -> drawScope(c, a, sens)
            else -> drawFilled(c, a)
        }
    }

    private fun drawBars(c: Canvas, a: Float) {
        val n = prefs.vizBars.coerceIn(8, 64)
        val r = stripRect
        if (r.width() < 20f || r.height() < 10f) return
        val reflect = prefs.vizReflect
        val base = if (reflect) r.top + r.height() * 0.72f else r.bottom
        val hh = base - r.top
        val pitch = r.width() / n
        val bw = max(pitch * 0.62f, 2f)
        val cell = 5f * d
        val gap = 2f * d
        for (i in 0 until n) {
            val v = levelAt(i, n).coerceIn(0f, 1.1f)
            val bh = max(bw, v * hh)
            val x = r.left + pitch * i + (pitch - bw) / 2f
            p.color = withAlpha(vizCol(i / (n - 1f)), a)
            if (prefs.vizSegments) {
                val cnt = max(1, (bh / (cell + gap)).toInt())
                for (k in 0 until cnt) {
                    val yb = base - k * (cell + gap)
                    rect.set(x, yb - cell, x + bw, yb)
                    c.drawRoundRect(rect, 1.5f * d, 1.5f * d, p)
                }
            } else {
                rect.set(x, base - bh, x + bw, base)
                c.drawRoundRect(rect, bw / 2f, bw / 2f, p)
            }
            if (reflect) {
                val rh = min(bh * 0.45f, r.bottom - base)
                if (rh > 1f) {
                    p.color = withAlpha(vizCol(i / (n - 1f)), a * 0.18f)
                    rect.set(x, base + 2f * d, x + bw, base + 2f * d + rh)
                    c.drawRoundRect(rect, bw / 2f, bw / 2f, p)
                }
            }
        }
    }

    private fun drawMirrored(c: Canvas, a: Float) {
        val n = (prefs.vizBars.coerceIn(8, 64) / 2) * 2
        val m = n / 2
        val r = stripRect
        if (r.width() < 20f || r.height() < 10f) return
        val yc = r.centerY()
        val half = r.height() / 2f
        val pitch = r.width() / n
        val bw = max(pitch * 0.62f, 2f)
        val cx = r.centerX()
        for (i in 0 until m) {
            val v = levelAt(i, m).coerceIn(0f, 1.1f)
            val bh = max(bw, v * half * 2f)
            p.color = withAlpha(vizCol(i / (m - 1f)), a)
            for (side in 0..1) {
                val x = if (side == 0) cx + i * pitch + (pitch - bw) / 2f else cx - (i + 1) * pitch + (pitch - bw) / 2f
                rect.set(x, yc - bh / 2f, x + bw, yc + bh / 2f)
                c.drawRoundRect(rect, bw / 2f, bw / 2f, p)
            }
        }
    }

    private fun smoothPath(pts: Int, xAt: (Int) -> Float, yAt: (Int) -> Float) {
        path.reset()
        path.moveTo(xAt(0), yAt(0))
        for (j in 1 until pts) {
            val mx = (xAt(j - 1) + xAt(j)) / 2f
            val my = (yAt(j - 1) + yAt(j)) / 2f
            path.quadTo(xAt(j - 1), yAt(j - 1), mx, my)
        }
        path.lineTo(xAt(pts - 1), yAt(pts - 1))
    }

    private fun drawScope(c: Canvas, a: Float, sens: Float) {
        val r = stripRect
        if (r.width() < 20f || r.height() < 10f) return
        val yc = r.centerY()
        val half = r.height() / 2f * 0.92f
        val pts = Audio.W
        val gain = sens.coerceIn(0.3f, 2.5f)
        smoothPath(pts,
            { r.left + r.width() * it / (pts - 1f) },
            {
                val v = if (frozen) 0.8f * sin(it * 0.33f) * sin(it * 0.07f + 0.6f) else Audio.wave[it] * gain
                yc - v.coerceIn(-1f, 1f) * half
            })
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.shader = hGrad(r.left, r.right)
        if (prefs.vizGlow) {
            p.strokeWidth = 9f * d; p.alpha = al(a * 0.10f); c.drawPath(path, p)
            p.strokeWidth = 5f * d; p.alpha = al(a * 0.20f); c.drawPath(path, p)
        }
        p.strokeWidth = 2.2f * d
        p.alpha = al(a)
        c.drawPath(path, p)
        p.shader = null
        p.alpha = 255
        p.style = Paint.Style.FILL
    }

    private fun drawFilled(c: Canvas, a: Float) {
        val r = stripRect
        if (r.width() < 20f || r.height() < 10f) return
        val pts = 48
        val hh = r.height() * 0.95f
        fun vAt(j: Int): Float {
            val x = j * (Audio.N - 1f) / (pts - 1f)
            val i = x.toInt().coerceIn(0, Audio.N - 2)
            val f = x - i
            val v = if (frozen) 0.5f * (frozenV(i, 64) + frozenV(i + 1, 64))
            else Audio.disp[i] * (1f - f) + Audio.disp[i + 1] * f
            return v.coerceIn(0f, 1.1f)
        }
        smoothPath(pts,
            { r.left + r.width() * it / (pts - 1f) },
            { r.bottom - max(2f * d, vAt(it) * hh) })
        val line = Path(path)
        path.lineTo(r.right, r.bottom)
        path.lineTo(r.left, r.bottom)
        path.close()
        p.shader = hGrad(r.left, r.right)
        p.style = Paint.Style.FILL
        p.alpha = al(a * 0.32f)
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        if (prefs.vizGlow) {
            p.strokeWidth = 7f * d; p.alpha = al(a * 0.14f); c.drawPath(line, p)
        }
        p.strokeWidth = 2.2f * d
        p.alpha = al(a)
        c.drawPath(line, p)
        p.shader = null
        p.alpha = 255
        p.style = Paint.Style.FILL
    }

    private fun drawRadial(c: Canvas) {
        val a = prefs.vizOpacity / 100f
        val sens = prefs.vizSens / 100f
        val depth = prefs.vizDepth * d
        val r0 = artR + 5f * d
        p.shader = null
        if (prefs.vizStyle == 4) {
            val n = (prefs.vizBars.coerceIn(8, 64) / 2) * 2
            val m = n / 2
            val bw = (6.2831855f * r0 / n * 0.55f).coerceIn(2f * d, 5f * d)
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = bw
            c.save()
            c.translate(artCx, artCy)
            c.rotate(if (prefs.vizSpin) rot else 0f)
            for (k in 0 until m) {
                val v = levelAt(m - 1 - k, m).coerceIn(0f, 1.15f)
                val len = 3f * d + depth * v
                val ang = Math.toRadians((-90f + 180f * (k + 0.5f) / m).toDouble())
                val ca = cos(ang).toFloat()
                val sa = sin(ang).toFloat()
                p.color = withAlpha(vizCol(k / (m - 1f)), a)
                c.drawLine(ca * r0, sa * r0, ca * (r0 + len), sa * (r0 + len), p)
                c.drawLine(-ca * r0, sa * r0, -ca * (r0 + len), sa * (r0 + len), p)
            }
            c.restore()
            p.style = Paint.Style.FILL
        } else {
            val be = if (frozen) 0.5f else Audio.beatEnv
            val lv = if (frozen) 0.4f else Audio.level * sens
            p.shader = RadialGradient(
                artCx, artCy, r0 + depth * (1.1f + 0.5f * be),
                intArrayOf(withAlpha(vizCol(0.3f), a * (0.30f + 0.35f * be)), 0x00000000),
                floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP
            )
            c.drawCircle(artCx, artCy, r0 + depth * 1.6f, p)
            p.shader = null
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f * d
            p.color = withAlpha(vizCol(0.1f), a * (0.55f + 0.4f * be))
            c.drawCircle(artCx, artCy, r0 + lv * 6f * d, p)
            p.strokeWidth = 1.2f * d
            p.color = withAlpha(vizCol(0.9f), a * 0.35f)
            c.drawCircle(artCx, artCy, r0 + 6f * d + lv * 10f * d, p)
            for (i in rAge.indices) {
                val age = rAge[i]
                if (age >= 1.2f) continue
                val t = age / 1.2f
                val e = 1f - (1f - t) * (1f - t)
                p.strokeWidth = 2.4f * d
                p.color = withAlpha(vizCol(0.5f + 0.5f * t), a * 0.6f * (1f - t))
                c.drawCircle(artCx, artCy, r0 + depth * 1.9f * e, p)
            }
            if (frozen) {
                p.strokeWidth = 2f * d
                p.color = withAlpha(vizCol(0.5f), a * 0.3f)
                c.drawCircle(artCx, artCy, r0 + depth * 0.9f, p)
            }
            p.style = Paint.Style.FILL
        }
    }

    private fun drawParticles(c: Canvas) {
        val a = prefs.vizOpacity / 100f
        p.shader = null
        p.style = Paint.Style.FILL
        if (frozen) {
            for (i in 0 until 30) {
                val fx = abs(sin(i * 12.9898f)) % 1f
                val fy = abs(sin(i * 78.233f)) % 1f
                p.color = withAlpha(vizCol(fx), a * (0.25f + 0.5f * fy))
                c.drawCircle(fx * (stripRect.right + 16f * d), fy * (progCy), (1.5f + 2.5f * fy) * d, p)
            }
            return
        }
        for (i in 0 until pn) {
            val life = plife[i]
            if (life <= 0f) continue
            val f = (life / pmax[i]).coerceIn(0f, 1f)
            p.color = withAlpha(vizCol(phue[i]), a * f)
            c.drawCircle(px[i], py[i], psize[i] * (0.5f + 0.5f * f), p)
        }
    }

    private fun drawGlow(c: Canvas, w: Float, h: Float) {
        val a = prefs.vizOpacity / 100f
        val sens = prefs.vizSens / 100f
        val be = if (frozen) 0.4f else Audio.beatEnv
        val lv = if (frozen) 0.4f else Audio.level * sens * 2f
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            artCx, artCy, artR * (2.4f + 0.7f * be + 0.7f * lv),
            intArrayOf(withAlpha(vizCol(0.2f), a * (0.40f + 0.45f * be)), 0x00000000),
            null, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = LinearGradient(
            0f, h * 0.55f, 0f, h,
            intArrayOf(0x00000000, withAlpha(vizCol(0.8f), a * (0.14f + 0.35f * lv.coerceAtMost(1f)))),
            null, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, h * 0.55f, w, h, p)
        p.shader = null
    }
}
