package app.nowplaying

import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService

/** Receives button presses and requests from the watch app. */
class WatchListener : WearableListenerService() {
    override fun onMessageReceived(event: MessageEvent) {
        if (!event.path.startsWith("/np/")) return
        WatchLink.onMessage(applicationContext, event.path, event.data)
    }
}
