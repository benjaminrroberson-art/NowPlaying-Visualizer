package app.nowplaying

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.widget.RemoteViews
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Home-screen widget. The card is drawn to a bitmap with the same look as the app (the visualizer
 * is a still frame, because widgets can't animate). The transport buttons are real widget buttons.
 */
class NowPlayingWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        MediaState.ensureStarted(context)
        watch(context)
        for (id in ids) update(context, mgr, id)
    }

    override fun onAppWidgetOptionsChanged(context: Context, mgr: AppWidgetManager, id: Int, newOptions: android.os.Bundle?) {
        update(context, mgr, id)
    }

    override fun onEnabled(context: Context) {
        MediaState.ensureStarted(context)
        watch(context)
    }

    companion object {
        private val handler = Handler(Looper.getMainLooper())
        private var watching = false
        private var pending = false

        fun watch(ctx: Context) {
            if (watching) return
            watching = true
            val app = ctx.applicationContext
            MediaState.addListener { schedule(app) }
        }

        /** Re-render soon (changes arrive in bursts). */
        fun schedule(ctx: Context) {
            if (pending) return
            pending = true
            val app = ctx.applicationContext
            handler.postDelayed({
                pending = false
                updateAll(app)
            }, 500)
        }

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, NowPlayingWidget::class.java))
            for (id in ids) update(ctx, mgr, id)
        }

        private fun pi(ctx: Context, action: String, code: Int): PendingIntent {
            val i = Intent(ctx, ControlReceiver::class.java).setAction(action)
            return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }

        fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
            try {
                val d = ctx.resources.displayMetrics.density
                val o = mgr.getAppWidgetOptions(id)
                val wDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250).coerceAtLeast(120)
                val hDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 130).coerceAtLeast(90)
                val prefs = Prefs(ctx)
                val r = CardRenderer(ctx, prefs)
                r.widgetMode = true
                r.frozen = true
                r.reserveBottomDp = 50f
                val lw = wDp * d
                val lh = hDp * d
                val k = min(1f, sqrt(1_100_000f / (lw * lh)))
                val bmp = Bitmap.createBitmap((lw * k).toInt().coerceAtLeast(1), (lh * k).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                val c = Canvas(bmp)
                c.scale(k, k)
                r.draw(c, lw, lh, 0.016f)

                val rv = RemoteViews(ctx.packageName, R.layout.widget)
                rv.setImageViewBitmap(R.id.card, bmp)
                val col = r.textColorNow()
                rv.setInt(R.id.btn_prev, "setColorFilter", col)
                rv.setInt(R.id.btn_play, "setColorFilter", col)
                rv.setInt(R.id.btn_next, "setColorFilter", col)
                rv.setImageViewResource(R.id.btn_play, if (MediaState.playing) R.drawable.ic_pause else R.drawable.ic_play)
                rv.setOnClickPendingIntent(R.id.btn_prev, pi(ctx, "np.PREV", 1))
                rv.setOnClickPendingIntent(R.id.btn_play, pi(ctx, "np.PLAY", 2))
                rv.setOnClickPendingIntent(R.id.btn_next, pi(ctx, "np.NEXT", 3))
                val open = PendingIntent.getActivity(
                    ctx, 4, Intent(ctx, PlayerActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                rv.setOnClickPendingIntent(R.id.card, open)
                mgr.updateAppWidget(id, rv)
            } catch (e: Exception) {
            }
        }
    }
}
