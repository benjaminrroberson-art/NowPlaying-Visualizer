package app.nowplaying

import android.app.KeyguardManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.widget.RemoteViews
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Home-screen widget made of two bitmap layers: the card (background, art, text) is redrawn when the
 * track or play state changes, and a smaller transparent layer with the visualizer and progress line
 * is redrawn several times a second while music plays and the screen is on.
 */
class NowPlayingWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        setup(context)
        for (id in ids) fullUpdate(context, mgr, id)
        evaluate()
    }

    override fun onAppWidgetOptionsChanged(context: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle?) {
        setup(context)
        live.remove(id)
        fullUpdate(context, mgr, id)
    }

    override fun onEnabled(context: Context) {
        setup(context)
    }

    override fun onDisabled(context: Context) {
        setup(context)
        evaluate()
    }

    override fun onDeleted(context: Context, ids: IntArray) {
        for (id in ids) live.remove(id)
    }

    companion object {
        @Volatile
        var lastError = ""

        private val handler = Handler(Looper.getMainLooper())
        private var appCtx: Context? = null
        private var inited = false
        private var pending = false
        private var running = false
        private var audioHeld = false
        private var lastTick = 0L

        private class Live(val r: CardRenderer, val bmp: Bitmap, val k: Float, val lw: Float, val lh: Float) {
            fun render(dt: Float) {
                bmp.eraseColor(0)
                val c = Canvas(bmp)
                c.scale(k, k)
                r.draw(c, lw, lh, dt)
            }
        }

        private val live = HashMap<Int, Live>()

        private val screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                evaluate()
                if (intent.action == Intent.ACTION_USER_PRESENT || intent.action == Intent.ACTION_SCREEN_ON) schedule()
            }
        }

        private fun setup(ctx: Context) {
            if (inited) return
            inited = true
            val app = ctx.applicationContext
            appCtx = app
            MediaState.ensureStarted(app)
            MediaState.addListener {
                schedule()
                evaluate()
            }
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
            else app.registerReceiver(screenReceiver, f)
        }

        private fun ids(ctx: Context): IntArray =
            AppWidgetManager.getInstance(ctx).getAppWidgetIds(ComponentName(ctx, NowPlayingWidget::class.java))

        /** Re-render the card layer soon (changes arrive in bursts). */
        fun schedule() {
            if (pending) return
            val ctx = appCtx ?: return
            pending = true
            handler.postDelayed({
                pending = false
                val mgr = AppWidgetManager.getInstance(ctx)
                for (id in ids(ctx)) fullUpdate(ctx, mgr, id)
            }, 500)
        }

        /** Called when settings change. */
        fun refresh(ctx: Context) {
            setup(ctx)
            evaluate()
            schedule()
        }

        /** Starts or stops the animation loop depending on widgets, play state, screen and lock. */
        private fun evaluate() {
            val ctx = appCtx ?: return
            val prefs = Prefs(ctx)
            val pm = ctx.getSystemService(PowerManager::class.java)
            val kg = ctx.getSystemService(KeyguardManager::class.java)
            val want = ids(ctx).isNotEmpty() && prefs.widgetLive && MediaState.playing &&
                pm.isInteractive && !kg.isKeyguardLocked
            if (want && !running) {
                running = true
                if (!audioHeld) {
                    audioHeld = true
                    Audio.start(ctx)
                }
                lastTick = SystemClock.uptimeMillis()
                handler.post(tick)
            } else if (!want && running) {
                running = false
                handler.removeCallbacks(tick)
                if (audioHeld) {
                    audioHeld = false
                    Audio.stop()
                }
                if (!MediaState.playing) Audio.reset()
                schedule()
            }
        }

        private val tick = object : Runnable {
            override fun run() {
                if (!running) return
                val ctx = appCtx ?: return
                val prefs = Prefs(ctx)
                try {
                    val mgr = AppWidgetManager.getInstance(ctx)
                    val now = SystemClock.uptimeMillis()
                    val dt = ((now - lastTick) / 1000f).coerceIn(0.001f, 0.1f)
                    lastTick = now
                    Audio.gain = prefs.vizSens / 100f
                    Audio.update(false)
                    for (id in ids(ctx)) {
                        val l = liveFor(ctx, mgr, id, prefs)
                        l.r.frozen = false
                        l.render(dt)
                        val rv = RemoteViews(ctx.packageName, R.layout.widget)
                        rv.setImageViewBitmap(R.id.viz, l.bmp)
                        mgr.partiallyUpdateAppWidget(id, rv)
                    }
                } catch (e: Throwable) {
                    lastError = e.javaClass.simpleName + ": " + (e.message ?: "")
                }
                handler.postDelayed(this, (1000 / prefs.widgetFps.coerceIn(2, 30)).toLong())
            }
        }

        private fun sizeFor(ctx: Context, mgr: AppWidgetManager, id: Int): Pair<Float, Float> {
            val d = ctx.resources.displayMetrics.density
            val o = mgr.getAppWidgetOptions(id)
            val wDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250).coerceAtLeast(120)
            val hDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 130).coerceAtLeast(90)
            return Pair(wDp * d, hDp * d)
        }

        private fun liveFor(ctx: Context, mgr: AppWidgetManager, id: Int, prefs: Prefs): Live {
            val (lw, lh) = sizeFor(ctx, mgr, id)
            val old = live[id]
            if (old != null && old.lw == lw && old.lh == lh) return old
            val r = CardRenderer(ctx, prefs)
            r.widgetMode = true
            r.layerMode = 2
            r.reserveBottomDp = 50f
            val k = min(1f, sqrt(300_000f / (lw * lh)))
            val bmp = Bitmap.createBitmap((lw * k).toInt().coerceAtLeast(1), (lh * k).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            val l = Live(r, bmp, k, lw, lh)
            live[id] = l
            return l
        }

        private fun pi(ctx: Context, action: String, code: Int): PendingIntent {
            val i = Intent(ctx, ControlReceiver::class.java).setAction(action)
            return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }

        private fun fullUpdate(ctx: Context, mgr: AppWidgetManager, id: Int) {
            try {
                val prefs = Prefs(ctx)
                val (lw, lh) = sizeFor(ctx, mgr, id)

                // card layer
                val r = CardRenderer(ctx, prefs)
                r.widgetMode = true
                r.frozen = true
                r.layerMode = 1
                r.reserveBottomDp = 50f
                val kb = min(1f, sqrt(1_000_000f / (lw * lh)))
                val bmp = Bitmap.createBitmap((lw * kb).toInt().coerceAtLeast(1), (lh * kb).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                val c = Canvas(bmp)
                c.scale(kb, kb)
                r.draw(c, lw, lh, 0.016f)

                // visualizer layer: resting pose when paused, decorative still when not animating
                val l = liveFor(ctx, mgr, id, prefs)
                l.r.frozen = MediaState.playing && !running
                l.render(0.016f)

                val rv = RemoteViews(ctx.packageName, R.layout.widget)
                rv.setImageViewBitmap(R.id.card, bmp)
                rv.setImageViewBitmap(R.id.viz, l.bmp)
                val col = r.textColorNow()
                rv.setInt(R.id.btn_prev, "setColorFilter", col)
                rv.setInt(R.id.btn_play, "setColorFilter", col)
                rv.setInt(R.id.btn_next, "setColorFilter", col)
                rv.setImageViewResource(R.id.btn_play, if (MediaState.playing) R.drawable.ic_pause else R.drawable.ic_play)
                rv.setOnClickPendingIntent(R.id.btn_prev, pi(ctx, "np.PREV", 1))
                rv.setOnClickPendingIntent(R.id.btn_play, pi(ctx, "np.PLAY", 2))
                rv.setOnClickPendingIntent(R.id.btn_next, pi(ctx, "np.NEXT", 3))
                val open = PendingIntent.getActivity(
                    ctx, 4, Intent(ctx, PlayerActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                rv.setOnClickPendingIntent(R.id.root, open)
                mgr.updateAppWidget(id, rv)
                lastError = ""
            } catch (e: Throwable) {
                lastError = e.javaClass.simpleName + ": " + (e.message ?: "")
            }
        }
    }
}
