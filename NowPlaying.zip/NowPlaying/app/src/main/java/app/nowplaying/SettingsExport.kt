package app.nowplaying

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * One JSON file with every setting this app keeps: look and visualizer settings, saved looks,
 * saved EQ presets and the per-device EQ choices. Kvaesitso X can import it.
 */
object SettingsExport {
    private val STORES = listOf("np", "np_presets", "np_eqpresets", "np_eqdev")

    fun build(ctx: Context): String {
        val root = JSONObject()
        root.put("format", "nowplaying-settings")
        root.put("version", 1)
        val stores = JSONObject()
        for (name in STORES) {
            val sp = ctx.applicationContext.getSharedPreferences(name, Context.MODE_PRIVATE)
            val o = JSONObject()
            for ((k, v) in sp.all) {
                val e = JSONObject()
                when (v) {
                    is Int -> { e.put("t", "i"); e.put("v", v) }
                    is Long -> { e.put("t", "l"); e.put("v", v) }
                    is Float -> { e.put("t", "f"); e.put("v", v.toDouble()) }
                    is Boolean -> { e.put("t", "b"); e.put("v", v) }
                    is String -> { e.put("t", "s"); e.put("v", v) }
                    is Set<*> -> { e.put("t", "ss"); e.put("v", JSONArray(v.map { it.toString() })) }
                    else -> continue
                }
                o.put(k, e)
            }
            stores.put(name, o)
        }
        root.put("stores", stores)
        return root.toString(1)
    }
}
