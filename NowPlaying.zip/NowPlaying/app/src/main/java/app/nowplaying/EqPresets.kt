package app.nowplaying

import android.content.Context

/** Saved EQ presets shared by the settings screen and the card's EQ dropdown. */
object EqPresets {
    fun store(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("np_eqpresets", Context.MODE_PRIVATE)

    fun names(ctx: Context): List<String> = store(ctx).all.keys.sorted()

    /** name == null turns the EQ off. */
    fun select(ctx: Context, name: String?) {
        val p = Prefs(ctx)
        if (name == null) {
            p.eqOn = false
            EqService.sync(ctx)
            return
        }
        val s = store(ctx).getString(name, null) ?: return
        val parts = s.split("#")
        p.eqBands = parts.getOrElse(0) { "" }
        parts.getOrNull(1)?.toIntOrNull()?.let { p.eqPost = it }
        p.eqCurrent = name
        p.eqOn = true
        EqService.sync(ctx)
        EqEngine.apply(p)
    }

    fun label(p: Prefs): String = when {
        !p.eqOn -> "EQ off"
        p.eqCurrent.isNotEmpty() -> p.eqCurrent
        else -> "EQ custom"
    }
}
