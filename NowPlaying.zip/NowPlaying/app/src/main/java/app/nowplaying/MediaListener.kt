package app.nowplaying

import android.service.notification.NotificationListenerService

/**
 * Does nothing itself. Having notification access enabled is what lets the app see the
 * active media session (title, artwork, play state, transport controls).
 * No notification content is read or stored.
 */
class MediaListener : NotificationListenerService()
