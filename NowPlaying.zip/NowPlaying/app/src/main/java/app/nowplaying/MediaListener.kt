package app.nowplaying

import android.service.notification.NotificationListenerService

/**
 * Does nothing itself. Having notification access enabled is what lets the app see the
 * active media session (title, artwork, play state, transport controls).
 * No notification content is read or stored.
 */
class MediaListener : NotificationListenerService() {
    // The system starts this service by itself after a reboot or an app update, so use it to bring
    // the bubble (and the EQ) back without having to open the app.
    override fun onListenerConnected() {
        super.onListenerConnected()
        OverlayService.ensure(this)
        if (Prefs(this).eqOn) EqService.sync(this)
        EqDevices.watch(this)
    }

    override fun onListenerDisconnected() {
        EqDevices.unwatch(this)
        super.onListenerDisconnected()
    }
}
