package app.nowplaying

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Handles the transport buttons of the home-screen widget. */
class ControlReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        MediaState.ensureStarted(context)
        MediaState.retry()
        when (intent.action) {
            "np.PREV" -> MediaState.prev()
            "np.NEXT" -> MediaState.next()
            "np.PLAY" -> MediaState.playPause()
        }
    }
}
