package app.nowplaying

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** The EQ dropdown: a dialog inside activities, a small floating list over other apps. */
object EqMenu {
    private var overlay: View? = null
    private var overlayWm: WindowManager? = null

    fun dismiss() {
        val v = overlay ?: return
        overlay = null
        try { overlayWm?.removeView(v) } catch (e: Exception) {}
    }

    fun show(anchor: View, onPicked: (() -> Unit)? = null) {
        val ctx = anchor.context
        val p = Prefs(ctx)
        val names = EqPresets.names(ctx)
        val labels = ArrayList<String>()
        val picks = ArrayList<String?>()
        labels.add((if (!p.eqOn) "✓  " else "     ") + "EQ off"); picks.add(null)
        for (n in names) {
            labels.add((if (p.eqOn && p.eqCurrent == n) "✓  " else "     ") + n)
            picks.add(n)
        }
        if (ctx is Activity) {
            AlertDialog.Builder(ctx)
                .setTitle("Equalizer")
                .setItems(labels.toTypedArray()) { _, i ->
                    EqPresets.select(ctx, picks[i])
                    onPicked?.invoke()
                }
                .show()
            return
        }
        showOverlay(anchor, labels, names.isEmpty()) { i ->
            EqPresets.select(ctx, picks[i])
            onPicked?.invoke()
        }
    }

    private fun showOverlay(anchor: View, labels: List<String>, noneSaved: Boolean, pick: (Int) -> Unit) {
        dismiss()
        val ctx: Context = anchor.context
        val wm = ctx.getSystemService(WindowManager::class.java)
        val d = ctx.resources.displayMetrics.density
        val sw = ctx.resources.displayMetrics.widthPixels
        val sh = ctx.resources.displayMetrics.heightPixels

        val list = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
            background = GradientDrawable().apply {
                setColor(Color.argb(245, 28, 28, 32))
                cornerRadius = 14 * d
            }
        }
        labels.forEachIndexed { i, t ->
            list.addView(TextView(ctx).apply {
                text = t
                setTextColor(Color.WHITE)
                textSize = 15f
                setPadding((14 * d).toInt(), (11 * d).toInt(), (18 * d).toInt(), (11 * d).toInt())
                isClickable = true
                setOnClickListener {
                    dismiss()
                    pick(i)
                }
            })
        }
        if (noneSaved) {
            list.addView(TextView(ctx).apply {
                text = "Save an EQ preset in the app to see it here"
                setTextColor(Color.argb(160, 255, 255, 255))
                textSize = 12f
                setPadding((14 * d).toInt(), (6 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
            })
        }

        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        val menuW = (210 * d).toInt()
        val root = FrameLayout(ctx)
        root.setOnClickListener { dismiss() }
        val sv = ScrollView(ctx).apply { addView(list) }
        val maxH = (sh * 0.55f).toInt()
        val lp = FrameLayout.LayoutParams(menuW, FrameLayout.LayoutParams.WRAP_CONTENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.leftMargin = (loc[0] + anchor.width - menuW - (8 * d).toInt()).coerceIn((8 * d).toInt(), sw - menuW - (8 * d).toInt())
        lp.topMargin = (loc[1] + (40 * d).toInt()).coerceIn((8 * d).toInt(), sh - maxH)
        root.addView(sv, lp)
        sv.measure(
            View.MeasureSpec.makeMeasureSpec(menuW, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST)
        )

        val wlp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(root, wlp)
            overlay = root
            overlayWm = wm
        } catch (e: Exception) {
            return
        }
        // if the card behind goes away (popup auto-closes), take the menu with it
        anchor.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {}
            override fun onViewDetachedFromWindow(v: View) {
                dismiss()
                anchor.removeOnAttachStateChangeListener(this)
            }
        })
    }
}
