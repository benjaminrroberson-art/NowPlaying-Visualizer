package app.nowplaying

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioAttributes
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Optional audio source that captures what other apps are playing (Android's playback capture),
 * so the visualizer works with any output including Bluetooth. Audio is analysed only, never saved.
 */
class CaptureService : Service() {

    companion object {
        @Volatile
        var running = false

        fun start(ctx: Context, code: Int, data: Intent) {
            val i = Intent(ctx, CaptureService::class.java)
                .putExtra("code", code)
                .putExtra("data", data)
            ctx.startForegroundService(i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, CaptureService::class.java).setAction("np.CAPSTOP"))
        }

        private const val FFT = 1024
    }

    private var proj: MediaProjection? = null
    private var rec: AudioRecord? = null
    private var thread: Thread? = null

    @Volatile
    private var go = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "np.CAPSTOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("np_capture", "Audio capture", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 2, Intent(this, CaptureService::class.java).setAction("np.CAPSTOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "np_capture")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Visualizer audio capture is on")
            .setContentText("Analysing playback only. Nothing is recorded.")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "Stop", stop
                ).build()
            )
            .build()
        startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val p = mpm.getMediaProjection(code, data)
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSelf()
                }
            }, Handler(Looper.getMainLooper()))
            proj = p

            val cfg = AudioPlaybackCaptureConfiguration.Builder(p)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(44100)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val minBuf = AudioRecord.getMinBufferSize(
                44100, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT
            )
            val r = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(cfg)
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(maxOf(minBuf, 16384))
                .build()
            if (r.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("not initialised")
            r.startRecording()
            rec = r
            running = true
            Audio.setExternal(this, true)
            go = true
            thread = Thread { loop(r) }.also { it.name = "np-capture"; it.start() }
        } catch (e: Throwable) {
            Audio.status = "Audio: playback capture failed (" + e.javaClass.simpleName + ")"
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        go = false
        running = false
        try { thread?.join(300) } catch (e: Exception) {}
        try { rec?.stop() } catch (e: Exception) {}
        try { rec?.release() } catch (e: Exception) {}
        try { proj?.stop() } catch (e: Exception) {}
        rec = null
        proj = null
        Audio.setExternal(this, false)
        super.onDestroy()
    }

    // ------------------------------------------------------------------ analysis

    private val window = FloatArray(FFT) { (0.5 - 0.5 * cos(2.0 * PI * it / (FFT - 1))).toFloat() }
    private val re = FloatArray(FFT)
    private val im = FloatArray(FFT)
    private val mono = FloatArray(FFT)
    private val cosT = FloatArray(FFT / 2) { cos(-2.0 * PI * it / FFT).toFloat() }
    private val sinT = FloatArray(FFT / 2) { sin(-2.0 * PI * it / FFT).toFloat() }

    private fun loop(r: AudioRecord) {
        val buf = ShortArray(FFT * 2)
        while (go) {
            val got = r.read(buf, 0, buf.size)
            if (got <= 0) {
                try { Thread.sleep(20) } catch (e: Exception) {}
                continue
            }
            val frames = got / 2
            // shift in the newest frames
            if (frames >= FFT) {
                for (i in 0 until FFT) mono[i] = (buf[(frames - FFT + i) * 2] + buf[(frames - FFT + i) * 2 + 1]) / 65536f
            } else {
                System.arraycopy(mono, frames, mono, 0, FFT - frames)
                for (i in 0 until frames) mono[FFT - frames + i] = (buf[i * 2] + buf[i * 2 + 1]) / 65536f
            }
            analyse()
        }
    }

    private fun analyse() {
        for (i in 0 until FFT) { re[i] = mono[i] * window[i]; im[i] = 0f }
        fft()
        val out = ByteArray(FFT)
        for (k in 1 until FFT / 2) {
            out[2 * k] = re[k].coerceIn(-127f, 127f).toInt().toByte()
            out[2 * k + 1] = im[k].coerceIn(-127f, 127f).toInt().toByte()
        }
        val wv = ByteArray(192)
        for (i in 0 until 192) wv[i] = (mono[i * 5] * 2f * 127f + 128f).coerceIn(0f, 255f).toInt().toByte()
        Audio.feedWave(wv)
        Audio.feedFft(out)
    }

    private fun fft() {
        val n = FFT
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val half = len / 2
            val step = n / len
            var i = 0
            while (i < n) {
                for (k in 0 until half) {
                    val wr = cosT[k * step]
                    val wi = sinT[k * step]
                    val a = i + k
                    val b = a + half
                    val xr = re[b] * wr - im[b] * wi
                    val xi = re[b] * wi + im[b] * wr
                    re[b] = re[a] - xr
                    im[b] = im[a] - xi
                    re[a] += xr
                    im[a] += xi
                }
                i += len
            }
            len = len shl 1
        }
    }
}
