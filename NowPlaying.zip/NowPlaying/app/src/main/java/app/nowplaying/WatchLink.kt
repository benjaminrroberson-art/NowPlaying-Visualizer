package app.nowplaying

import android.content.Context
import android.database.ContentObserver
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import com.google.android.gms.wearable.Asset
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import java.io.ByteArrayOutputStream

/**
 * The phone's side of the watch link. Pushes what is playing (text, artwork, the current look and
 * volume) to the watch as data items, streams visualizer frames only while the watch asks for them,
 * and carries out button presses sent back from the watch.
 */
object WatchLink {
    const val P_STATE = "/np/state"
    const val P_ART = "/np/art"
    const val P_VIZ = "/np/viz"
    const val P_CMD = "/np/cmd"
    const val P_HELLO = "/np/hello"
    const val P_SUB = "/np/sub"

    @Volatile
    var status = "Watch link: off"

    private val main = Handler(Looper.getMainLooper())
    private var app: Context? = null
    private var prefs: Prefs? = null
    private var active = false
    private var nodes: List<String> = emptyList()
    private var nodesAt = 0L
    private var ver = 0L
    private var lastArt: Bitmap? = null
    private var artSig = 0
    private var vizUntil = 0L
    private var vizLoop = false
    private var audioOn = false
    private var inFlight = 0
    private var lastVol = -1

    private val changed: () -> Unit = { schedulePush(150) }

    private val pushRun = Runnable { pushNow() }

    private val volObs = object : ContentObserver(main) {
        override fun onChange(selfChange: Boolean) {
            val a = app ?: return
            val v = curVol(a)
            if (v != lastVol) {
                lastVol = v
                schedulePush(60)
            }
        }
    }

    fun start(ctx: Context) {
        if (active) return
        val a = ctx.applicationContext
        app = a
        prefs = Prefs(a)
        active = true
        MediaState.ensureStarted(a)
        MediaState.addListener(changed)
        try {
            a.contentResolver.registerContentObserver(Settings.System.CONTENT_URI, true, volObs)
        } catch (e: Exception) {
        }
        status = "Watch link: looking for the watch"
        refreshNodes(true)
        schedulePush(0)
    }

    fun stop() {
        if (!active) return
        active = false
        MediaState.removeListener(changed)
        try { app?.contentResolver?.unregisterContentObserver(volObs) } catch (e: Exception) {}
        stopViz()
        main.removeCallbacksAndMessages(null)
        status = "Watch link: off"
    }

    /** Called after a setting that the watch shows has changed. */
    fun pushSoon() {
        if (active) schedulePush(100)
    }

    private fun schedulePush(delay: Long) {
        main.removeCallbacks(pushRun)
        main.postDelayed(pushRun, delay)
    }

    private fun curVol(a: Context): Int =
        try { a.getSystemService(AudioManager::class.java).getStreamVolume(AudioManager.STREAM_MUSIC) } catch (e: Exception) { 0 }

    private fun maxVol(a: Context): Int =
        try { a.getSystemService(AudioManager::class.java).getStreamMaxVolume(AudioManager.STREAM_MUSIC) } catch (e: Exception) { 15 }

    private fun setVolume(v: Int) {
        val a = app ?: return
        try {
            val am = a.getSystemService(AudioManager::class.java)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, v.coerceIn(0, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)), 0)
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------ state

    private fun pushNow() {
        val a = app ?: return
        val p = prefs ?: return
        if (!active) return
        val st = if (p.watchStyle in intArrayOf(0, 2, 3, 4)) p.watchStyle else 4
        val m = PutDataMapRequest.create(P_STATE)
        val d = m.dataMap
        d.putLong("ver", ++ver)
        d.putString("t", MediaState.title)
        d.putString("a", MediaState.artist)
        d.putString("al", MediaState.album)
        d.putBoolean("has", MediaState.hasSession)
        d.putBoolean("pl", MediaState.playing)
        d.putLong("dur", MediaState.durationMs)
        d.putLong("pos", MediaState.positionMs())
        lastVol = curVol(a)
        d.putInt("vol", lastVol)
        d.putInt("vmax", maxVol(a))
        d.putInt("like", if (p.watchLike) MediaState.likeState else 0)
        // look
        d.putInt("style", st)
        d.putInt("cm", p.sGet(st, "colorMode"))
        d.putInt("c1", p.sGet(st, "color"))
        d.putInt("c2", p.sGet(st, "color2"))
        d.putInt("bars", p.sGet(st, "bars"))
        d.putInt("sens", p.sGet(st, "sens"))
        d.putInt("reach", p.sGet(st, "reach"))
        d.putInt("fall", p.sGet(st, "fall"))
        d.putInt("vert", p.sGet(st, "vert"))
        d.putInt("low", p.sGet(st, "low"))
        d.putInt("depth", p.sGet(st, "depth"))
        d.putBoolean("glow", p.sGet(st, "glow") != 0)
        d.putBoolean("spin", p.sGet(st, "spin") != 0)
        d.putInt("vop", p.vizOpacity)
        d.putInt("acc", MediaState.accent)
        d.putInt("acc2", MediaState.accent2)
        d.putInt("dark", MediaState.dark)
        d.putIntegerArrayList("pal", ArrayList<Int>(MediaState.palette.toList()))
        val tc = when (p.textMode) {
            0 -> Color.WHITE
            1 -> 0xFF101114.toInt()
            2 -> MediaState.light
            else -> p.textColor
        }
        d.putInt("tc", tc)
        d.putBoolean("tb", p.titleBold)
        d.putInt("cs", p.controlStyle)
        d.putBoolean("prog", p.showProgress)
        d.putInt("bgop", p.bgOpacity)
        d.putInt("blur", p.blurAmount)
        d.putBoolean("viz", p.watchViz)
        d.putInt("delay", p.watchDelay)
        d.putInt("fps", p.watchFps)
        try {
            Wearable.getDataClient(a).putDataItem(m.asPutDataRequest().setUrgent())
        } catch (e: Exception) {
            status = "Watch link: Play services not available"
        }
        pushArt(a, p)
    }

    private fun pushArt(a: Context, p: Prefs) {
        val art = if (p.watchArt) MediaState.art else null
        if (art === lastArt) return
        lastArt = art
        artSig++
        try {
            val r = PutDataMapRequest.create(P_ART)
            r.dataMap.putInt("sig", artSig)
            if (art != null) r.dataMap.putAsset("img", Asset.createFromBytes(jpeg(art)))
            Wearable.getDataClient(a).putDataItem(r.asPutDataRequest().setUrgent())
        } catch (e: Exception) {
        }
    }

    /** Square-crops the artwork and shrinks it for the watch. */
    private fun jpeg(src: Bitmap): ByteArray {
        val s = minOf(src.width, src.height)
        val x = (src.width - s) / 2
        val y = (src.height - s) / 2
        val out = Bitmap.createBitmap(320, 320, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(src, Rect(x, y, x + s, y + s), Rect(0, 0, 320, 320), Paint(Paint.FILTER_BITMAP_FLAG))
        val bo = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 82, bo)
        out.recycle()
        return bo.toByteArray()
    }

    // ------------------------------------------------------------------ messages

    private fun refreshNodes(force: Boolean) {
        val a = app ?: return
        val now = SystemClock.uptimeMillis()
        if (!force && now - nodesAt < 20000) return
        nodesAt = now
        try {
            Wearable.getNodeClient(a).connectedNodes
                .addOnSuccessListener { list ->
                    nodes = list.map { it.id }
                    if (nodes.isEmpty()) nodesAt = SystemClock.uptimeMillis() - 15000
                    status = if (nodes.isEmpty()) "Watch link: watch not connected" else "Watch link: connected"
                }
                .addOnFailureListener {
                    nodes = emptyList()
                    nodesAt = SystemClock.uptimeMillis() - 15000
                    status = "Watch link: Play services not available"
                }
        } catch (e: Exception) {
            status = "Watch link: Play services not available"
        }
    }

    private fun send(path: String, data: ByteArray) {
        val a = app ?: return
        val ns = nodes
        if (ns.isEmpty()) {
            refreshNodes(false)
            return
        }
        for (n in ns) {
            inFlight++
            try {
                Wearable.getMessageClient(a).sendMessage(n, path, data)
                    .addOnCompleteListener { inFlight = (inFlight - 1).coerceAtLeast(0) }
                    .addOnFailureListener { nodesAt = 0L }
            } catch (e: Exception) {
                inFlight = (inFlight - 1).coerceAtLeast(0)
            }
        }
    }

    /** A message from the watch (arrives on a background thread). */
    fun onMessage(ctx: Context, path: String, data: ByteArray) {
        val a = ctx.applicationContext
        main.post {
            if (!Prefs(a).watchOn) return@post
            if (!active) start(a)
            val p = prefs ?: return@post
            when (path) {
                P_HELLO -> {
                    nodesAt = 0L
                    refreshNodes(true)
                    lastArt = null
                    schedulePush(0)
                }
                P_SUB -> {
                    val on = data.isNotEmpty() && data[0].toInt() == 1
                    if (on && p.watchViz) startViz() else if (!on) stopViz()
                }
                P_CMD -> command(String(data, Charsets.UTF_8), p)
            }
        }
    }

    private fun command(s: String, p: Prefs) {
        when {
            s == "pp" -> MediaState.playPause()
            s == "next" -> MediaState.next()
            s == "prev" -> MediaState.prev()
            s == "like" -> MediaState.like()
            s.startsWith("seek:") -> s.substring(5).toLongOrNull()?.let { MediaState.seekTo(it) }
            s.startsWith("vol:") -> s.substring(4).toIntOrNull()?.let { setVolume(it) }
            s == "viz:1" -> { p.watchViz = true; schedulePush(0) }
            s == "viz:0" -> { p.watchViz = false; stopViz(); schedulePush(0) }
        }
    }

    // ------------------------------------------------------------------ visualizer stream

    private val vizRun = object : Runnable {
        override fun run() {
            val p = prefs
            if (!active || !vizLoop || p == null) return
            val now = SystemClock.uptimeMillis()
            if (now > vizUntil || !p.watchViz) {
                stopViz()
                return
            }
            if (now - nodesAt > 20000) refreshNodes(false)
            Audio.update(false)
            if (inFlight < 8) send(P_VIZ, frame())
            main.postDelayed(this, (1000 / p.watchFps.coerceIn(10, 30)).toLong())
        }
    }

    private fun startViz() {
        vizUntil = SystemClock.uptimeMillis() + 20000
        if (vizLoop) return
        val a = app ?: return
        vizLoop = true
        Audio.start(a)
        audioOn = true
        main.post(vizRun)
    }

    private fun stopViz() {
        vizLoop = false
        main.removeCallbacks(vizRun)
        if (audioOn) {
            Audio.stop()
            audioOn = false
        }
    }

    /** 83 bytes: flags, level, beat, 32 band levels, 48 waveform samples. */
    private fun frame(): ByteArray {
        val f = ByteArray(83)
        f[0] = (if (Audio.beatEnv > 0.5f) 1 else 0).toByte()
        f[1] = (Audio.level.coerceIn(0f, 1f) * 255f).toInt().toByte()
        f[2] = (Audio.beatEnv.coerceIn(0f, 1f) * 255f).toInt().toByte()
        for (i in 0 until 32) f[3 + i] = (Audio.band(i, 32) / 1.2f * 255f).toInt().coerceIn(0, 255).toByte()
        for (j in 0 until 48) {
            val v = (Audio.wave[2 * j] + Audio.wave[2 * j + 1]) / 2f
            f[35 + j] = ((v.coerceIn(-1f, 1f) + 1f) / 2f * 255f).toInt().coerceIn(0, 255).toByte()
        }
        return f
    }
}
