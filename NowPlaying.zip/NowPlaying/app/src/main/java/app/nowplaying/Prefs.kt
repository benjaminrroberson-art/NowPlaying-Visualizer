package app.nowplaying

import android.content.Context
import org.json.JSONObject
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("np", Context.MODE_PRIVATE)
    private val ps = ctx.applicationContext.getSharedPreferences("np_presets", Context.MODE_PRIVATE)

    private inner class I(private val k: String, private val d: Int) : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Int = sp.getInt(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            sp.edit().putInt(k, value).apply()
        }
    }

    private inner class B(private val k: String, private val d: Boolean) : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = sp.getBoolean(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            sp.edit().putBoolean(k, value).apply()
        }
    }

    // ---- visualizer ----
    /** 0 bars, 1 mirrored bars, 2 oscilloscope, 3 filled wave, 4 circular spectrum, 5 pulse ring, 6 particles, 7 blurred glow */
    var vizStyle by I("vizStyle", 0)
    var vizColorMode by I("vizColorMode", 2)      // 0 solid, 1 gradient, 2 from album art, 3 rainbow
    var vizColor by I("vizColor", 0xFF00E5FF.toInt())
    var vizColor2 by I("vizColor2", 0xFFFF4081.toInt())
    var vizBars by I("vizBars", 32)
    var vizSens by I("vizSens", 100)
    var vizOpacity by I("vizOpacity", 95)
    var vizHeight by I("vizHeight", 56)           // dp, strip height for linear styles
    var vizDepth by I("vizDepth", 26)             // dp, how far radial bars stick out
    var vizSegments by B("vizSegments", false)    // LED look for bars
    var vizReflect by B("vizReflect", false)      // faint reflection under bars
    var vizGlow by B("vizGlow", true)
    var vizSpin by B("vizSpin", true)             // slow rotation for circular
    var idleBreath by B("idleBreath", false)      // gentle motion while paused

    // ---- album art ----
    var artShape by I("artShape", 1)              // 0 square, 1 rounded, 2 circle
    var artSize by I("artSize", 100)              // dp (compact layout)
    var artPos by I("artPos", 0)                  // 0 left, 1 right (compact layout)
    var artShadow by B("artShadow", true)

    // ---- background ----
    var bgMode by I("bgMode", 2)                  // 0 solid, 1 tinted from art, 2 blurred art
    var bgColor by I("bgColor", 0xFF14161A.toInt())
    var bgOpacity by I("bgOpacity", 88)
    var corner by I("corner", 26)                 // dp
    var blurAmount by I("blurAmount", 60)         // percent

    // ---- text ----
    var font by I("font", 0)
    var titleBold by B("titleBold", true)
    var titleSize by I("titleSize", 18)           // sp
    var artistSize by I("artistSize", 14)         // sp
    var textMode by I("textMode", 0)              // 0 white, 1 black, 2 from art, 3 custom
    var textColor by I("textColor", 0xFFFFFFFF.toInt())
    var showAlbum by B("showAlbum", false)

    // ---- controls ----
    var showControls by B("showControls", true)
    var controlStyle by I("controlStyle", 0)      // 0 filled play button, 1 minimal
    var showProgress by B("showProgress", true)

    // ---- floating card ----
    var overlayOn by B("overlayOn", false)
    var overlayX by I("overlayX", 24)
    var overlayY by I("overlayY", 120)
    var overlayWidth by I("overlayWidth", 340)    // dp
    var overlayHideIdle by B("overlayHideIdle", true)

    // ---- saved looks ----
    private val lookKeys = listOf(
        "vizStyle", "vizColorMode", "vizColor", "vizColor2", "vizBars", "vizSens", "vizOpacity",
        "vizHeight", "vizDepth", "vizSegments", "vizReflect", "vizGlow", "vizSpin", "idleBreath",
        "artShape", "artSize", "artPos", "artShadow", "bgMode", "bgColor", "bgOpacity", "corner",
        "blurAmount", "font", "titleBold", "titleSize", "artistSize", "textMode", "textColor",
        "showAlbum", "showControls", "controlStyle", "showProgress"
    )

    fun savedPresetNames(): List<String> = ps.all.keys.sorted()

    fun savePreset(name: String) {
        val all = sp.all
        val o = JSONObject()
        for (k in lookKeys) {
            val v = all[k] ?: continue
            o.put(k, v)
        }
        ps.edit().putString(name, o.toString()).apply()
    }

    fun loadPreset(name: String) {
        val json = ps.getString(name, null) ?: return
        val o = JSONObject(json)
        val m = HashMap<String, Any>()
        for (k in lookKeys) if (o.has(k)) m[k] = o.get(k)
        apply(m)
    }

    fun deletePreset(name: String) {
        ps.edit().remove(name).apply()
    }

    /** Resets every "look" key to its default, then sets the ones given. */
    fun apply(values: Map<String, Any>) {
        val e = sp.edit()
        for (k in lookKeys) e.remove(k)
        for ((k, v) in values) {
            when (v) {
                is Int -> e.putInt(k, v)
                is Boolean -> e.putBoolean(k, v)
            }
        }
        e.apply()
    }
}
