package app.nowplaying

import android.content.Context
import org.json.JSONObject
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("np", Context.MODE_PRIVATE)
    private val ps = ctx.applicationContext.getSharedPreferences("np_presets", Context.MODE_PRIVATE)

    /** Temporary overrides (used by the screen saver to reuse the card renderer with its own look). */
    val ov = HashMap<String, Any>()

    private inner class I(private val k: String, private val d: Int) : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Int = (ov[k] as? Int) ?: sp.getInt(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            sp.edit().putInt(k, value).apply()
        }
    }

    private inner class B(private val k: String, private val d: Boolean) : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = (ov[k] as? Boolean) ?: sp.getBoolean(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            sp.edit().putBoolean(k, value).apply()
        }
    }

    private inner class S(private val k: String, private val d: String) : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): String = sp.getString(k, d) ?: d
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
            sp.edit().putString(k, value).apply()
        }
    }

    // ---- visualizer ----
    /** 0 bars, 1 mirrored bars, 2 oscilloscope, 3 filled wave, 4 circular spectrum, 5 pulse ring, 6 particles, 7 blurred glow */
    var vizStyle by I("vizStyle", 0)
    var vizColorMode by I("vizColorMode", 2)      // 0 solid, 1 gradient, 2 from album art, 3 rainbow
    var vizColor by I("vizColor", 0xFF00E5FF.toInt())
    var vizColor2 by I("vizColor2", 0xFFFF4081.toInt())
    var vizBars by I("vizBars", 32)
    var vizSens by I("vizSens", 100)
    var vizOpacity by I("vizOpacity", 95)
    var vizHeight by I("vizHeight", 56)           // dp, strip height for linear styles
    var vizDepth by I("vizDepth", 26)             // dp, how far radial bars stick out
    var vizSegments by B("vizSegments", false)    // LED look for bars
    var vizReflect by B("vizReflect", false)      // faint reflection under bars
    var vizGlow by B("vizGlow", true)
    var vizSpin by B("vizSpin", true)             // slow rotation for circular
    var idleBreath by B("idleBreath", false)      // gentle motion while paused

    // ---- album art ----
    var artShape by I("artShape", 1)              // 0 square, 1 rounded, 2 circle
    var artSize by I("artSize", 100)              // dp (compact layout)
    var artPos by I("artPos", 0)                  // 0 left, 1 right (compact layout)
    var artShadow by B("artShadow", true)

    // ---- background ----
    var bgMode by I("bgMode", 2)                  // 0 solid, 1 tinted from art, 2 blurred art
    var bgColor by I("bgColor", 0xFF14161A.toInt())
    var bgOpacity by I("bgOpacity", 88)
    var corner by I("corner", 26)                 // dp
    var blurAmount by I("blurAmount", 60)         // percent

    // ---- text ----
    var font by I("font", 0)
    var titleBold by B("titleBold", true)
    var titleSize by I("titleSize", 18)           // sp
    var scrollSpeed by I("scrollSpeed", 38)         // dp per second
    var artistSize by I("artistSize", 14)         // sp
    var textMode by I("textMode", 0)              // 0 white, 1 black, 2 from art, 3 custom
    var textColor by I("textColor", 0xFFFFFFFF.toInt())
    var showAlbum by B("showAlbum", false)

    // ---- controls ----
    var showControls by B("showControls", true)
    var controlStyle by I("controlStyle", 0)      // 0 filled play button, 1 minimal
    var showProgress by B("showProgress", true)

    // ---- equalizer ----
    var eqOn by B("eqOn", false)
    var eqBands by S("eqBandsP", "")                      // "type:freq:gain:q|..." (empty = flat)
    var eqCurrent by S("eqCurrent", "")                    // name of the loaded saved preset, empty = custom
    var showEqChip by B("showEqChip", true)
    var showCapChip by B("showCapChip", false)
    var eqMode by I("eqMode", 0)                          // 0 automatic, 1 system-wide, 2 per-app streams
    var eqPost by I("eqPost", 0)                          // post gain, tenths of dB

    // ---- floating bubble ----
    var bubbleOn by B("bubbleOn", false)
    var bubbleStyle by I("bubbleStyle", 4)        // same list as vizStyle
    var bubbleShape by I("bubbleShape", 0)        // 0 circle, 1 rounded square, 2 square
    var bubbleSize by I("bubbleSize", 56)         // dp, the artwork
    var bubbleBars by I("bubbleBars", 28)
    var bubbleOpacity by I("bubbleOpacity", 100)
    var bubbleSnap by B("bubbleSnap", true)
    var bubbleKeepPaused by B("bubbleKeepPaused", false)
    var bubbleHideInApp by B("bubbleHideInApp", true)
    var bubbleTuck by B("bubbleTuck", true)
    var seenVer by I("seenVer", 0)
    // ---- screen saver ----
    var saverLayout by I("saverLayout", 0)         // 0 art + visualizer, 1 big visualizer, 2 clock + track, 3 visualizer only
    var saverArt by B("saverArt", true)
    var saverStyle by I("saverStyle", -1)          // -1 same as card
    var saverColors by I("saverColors", -1)        // -1 same as card, else vizColorMode
    var saverText by B("saverText", true)
    var saverClock by B("saverClock", true)
    var saverClock24 by B("saverClock24", false)
    var saverBright by I("saverBright", 30)
    var saverShift by I("saverShift", 45)
    var saverFps by I("saverFps", 30)
    var saverPaused by I("saverPaused", 0)         // 0 clock only, 1 blank
    var saverControls by B("saverControls", true)
    var saverBurn by I("saverBurn", 2)             // 0 off, 1 drift, 2 blurred art background, 3 both
    var saverBackdropOn: Boolean
        get() = if (sp.contains("saverBackdropOn")) sp.getBoolean("saverBackdropOn", true)
        else (!sp.contains("saverBurn") || saverBurn == 2 || saverBurn == 3)
        set(v) { sp.edit().putBoolean("saverBackdropOn", v).apply() }
    var saverDrift: Boolean
        get() = if (sp.contains("saverDrift")) sp.getBoolean("saverDrift", false)
        else (saverBurn == 1 || saverBurn == 3)
        set(v) { sp.edit().putBoolean("saverDrift", v).apply() }
    var saverBackdrop by I("saverBackdrop", 35)    // % brightness of the blurred art background
    var saverClockPos by I("saverClockPos", 0)     // 0 top left, 1 top center, 2 top right, 3 middle, 4 bottom
    var saverClockSize by I("saverClockSize", 26)  // dp
    var saverClockY by I("saverClockY", 76)        // dp from the top (top positions)
    var saverBigClock by I("saverBigClock", 100)   // % size of the large clock in the clock layout
    var saverArtSize by I("saverArtSize", 100)     // % of normal art size
    var saverSched by B("saverSched", false)       // quiet hours: no automatic screen saver
    var saverSchedFrom by I("saverSchedFrom", 22 * 60)   // minutes after midnight
    var saverSchedTo by I("saverSchedTo", 7 * 60)
    var saverCustom by B("saverCustom", false)     // own visualizer settings instead of the card's
    var saverBars by I("saverBars", 32)
    var saverSens by I("saverSens", 100)
    var saverOpacity by I("saverOpacity", 95)
    var saverHeight by I("saverHeight", 56)
    var saverDepth by I("saverDepth", 26)
    var saverSpin by B("saverSpin", true)
    var saverColor by I("saverColor", 0xFF00E5FF.toInt())
    var saverColor2 by I("saverColor2", 0xFFFF4081.toInt())
    var bubbleDot by B("bubbleDot", true)

    /** tap = play/pause, press and hold = open the panel (off by default) */
    var bubbleTapPlay by B("bubbleTapPlay", false)
    var bubbleHaptic by B("bubbleHaptic", true)
    var bubbleHideMin by I("bubbleHideMin", 0)    // minutes paused before hiding; 0 = never
    var bubbleX by I("bubbleX", -99999)
    var bubbleY by I("bubbleY", -99999)
    var popupWidth by I("popupWidth", 320)        // dp
    var popupClose by I("popupClose", 8)          // seconds; 0 = stay open

    // ---- saved looks ----
    private val lookKeys = listOf(
        "vizStyle", "vizColorMode", "vizColor", "vizColor2", "vizBars", "vizSens", "vizOpacity",
        "vizHeight", "vizDepth", "vizSegments", "vizReflect", "vizGlow", "vizSpin", "idleBreath",
        "artShape", "artSize", "artPos", "artShadow", "bgMode", "bgColor", "bgOpacity", "corner",
        "blurAmount", "font", "titleBold", "titleSize", "artistSize", "scrollSpeed", "textMode", "textColor",
        "showAlbum", "showControls", "controlStyle", "showProgress",
        "bubbleStyle", "bubbleShape", "bubbleSize", "bubbleBars", "bubbleOpacity"
    )

    fun savedPresetNames(): List<String> = ps.all.keys.sorted()

    fun savePreset(name: String) {
        val all = sp.all
        val o = JSONObject()
        for (k in lookKeys) {
            val v = all[k] ?: continue
            o.put(k, v)
        }
        ps.edit().putString(name, o.toString()).apply()
    }

    fun loadPreset(name: String) {
        val json = ps.getString(name, null) ?: return
        val o = JSONObject(json)
        val m = HashMap<String, Any>()
        for (k in lookKeys) if (o.has(k)) m[k] = o.get(k)
        apply(m)
    }

    fun deletePreset(name: String) {
        ps.edit().remove(name).apply()
    }

    /** Resets every "look" key to its default, then sets the ones given. */
    fun apply(values: Map<String, Any>) {
        val e = sp.edit()
        for (k in lookKeys) e.remove(k)
        for ((k, v) in values) {
            when (v) {
                is Int -> e.putInt(k, v)
                is Boolean -> e.putBoolean(k, v)
            }
        }
        e.apply()
    }

    /** True during the quiet hours chosen for the screen saver. */
    fun saverQuietNow(): Boolean {
        if (!saverSched) return false
        val c = java.util.Calendar.getInstance()
        val now = c.get(java.util.Calendar.HOUR_OF_DAY) * 60 + c.get(java.util.Calendar.MINUTE)
        val a = saverSchedFrom
        val b = saverSchedTo
        return if (a == b) false else if (a < b) now in a until b else (now >= a || now < b)
    }
}
