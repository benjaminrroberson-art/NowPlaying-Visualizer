package app.nowplaying

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/**
 * Owns the floating bubble and its pop-up card. Every window here has a fixed size, so nothing
 * is ever resized (the system animates window resizes, which looks like things flying around).
 */
class OverlayService : Service() {

    companion object {
        fun hasUsageAccess(ctx: Context): Boolean {
            return try {
                val ops = ctx.getSystemService(AppOpsManager::class.java)
                ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), ctx.packageName) ==
                    AppOpsManager.MODE_ALLOWED
            } catch (e: Exception) { false }
        }

        @Volatile
        var status = "Bubble: off"

        @Volatile
        var running = false

        /** Starts the bubble service if the bubble is switched on. Safe to call repeatedly. */
        fun ensure(ctx: android.content.Context) {
            if (running) return
            if (!Prefs(ctx).bubbleOn || !Settings.canDrawOverlays(ctx)) return
            try {
                ctx.startForegroundService(Intent(ctx, OverlayService::class.java))
            } catch (e: Exception) {
            }
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())
    private val d get() = resources.displayMetrics.density

    private var bubble: BubbleView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var scrim: View? = null
    private var popup: CardView? = null
    private var screenOn = true
    private var pausedExpired = false
    private var pausedArmed = false

    private val listener: () -> Unit = { sync() }
    private val savePos = Runnable {
        if (miniState == 1) return@Runnable
        bubbleLp?.let {
            prefs.bubbleX = it.x
            prefs.bubbleY = it.y
        }
    }
    private val pausedHide = Runnable {
        pausedArmed = false
        pausedExpired = true
        sync()
    }
    private val popupClose = Runnable { closePopup(false) }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            screenOn = intent.action != Intent.ACTION_SCREEN_OFF
            bubble?.setScreenOn(screenOn)
            if (!screenOn) closePopup(true)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        wm = getSystemService(WindowManager::class.java)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("np_overlay", "Floating bubble", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction("np.STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "np_overlay")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Now Playing bubble is on")
            .setContentText("Tap to open settings")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "Turn off", stop
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(screenReceiver, f)
        MediaState.ensureStarted(this)
        MediaState.addListener(listener)
        running = true
        handler.postDelayed(fgPoll, 1000)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "np.STOP") {
            prefs.bubbleOn = false
            status = "Bubble: off"
            stopSelf()
            return START_NOT_STICKY
        }
        // settings may have changed: rebuild everything
        closePopup(true)
        removeBubble(true)
        pausedExpired = false
        sync()
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        MediaState.removeListener(listener)
        try { unregisterReceiver(screenReceiver) } catch (e: Exception) {}
        handler.removeCallbacksAndMessages(null)
        closePopup(true)
        removeBubble(true)
        super.onDestroy()
    }

    // ------------------------------------------------------------------ visibility

    // ---- hide the bubble while the music app itself is on screen (needs Usage access)
    private var fgPkg = ""
    private var fgLast = 0L
    private var inMusicApp = false

    private val fgPoll = object : Runnable {
        override fun run() {
            val was = inMusicApp
            inMusicApp = false
            if (prefs.bubbleHideInApp && hasUsageAccess(this@OverlayService)) {
                try {
                    val usm = getSystemService(UsageStatsManager::class.java)
                    val now = System.currentTimeMillis()
                    val from = if (fgLast == 0L) now - 600_000L else fgLast
                    val ev = usm.queryEvents(from, now)
                    val e = UsageEvents.Event()
                    while (ev.hasNextEvent()) {
                        ev.getNextEvent(e)
                        if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) fgPkg = e.packageName ?: ""
                        else if (e.eventType == UsageEvents.Event.ACTIVITY_PAUSED && e.packageName == fgPkg) fgPkg = ""
                    }
                    fgLast = now - 1500L
                } catch (x: Exception) {}
                inMusicApp = fgPkg.isNotEmpty() && fgPkg == MediaState.pkg
            }
            if (was != inMusicApp) sync()
            handler.postDelayed(this, 1000)
        }
    }

    private fun sync() {
        if (!Settings.canDrawOverlays(this)) {
            status = "Bubble: needs \"Display over other apps\""
            closePopup(true)
            removeBubble(true)
            return
        }
        val playing = MediaState.playing
        val keep = prefs.bubbleKeepPaused && MediaState.hasSession
        if (playing) {
            pausedExpired = false
            pausedArmed = false
            handler.removeCallbacks(pausedHide)
        } else if (keep && prefs.bubbleHideMin > 0 && !pausedArmed && !pausedExpired) {
            pausedArmed = true
            handler.postDelayed(pausedHide, prefs.bubbleHideMin * 60_000L)
        } else if (!keep) {
            pausedArmed = false
            handler.removeCallbacks(pausedHide)
        }
        val want = (playing || (keep && !pausedExpired)) && !inMusicApp
        if (want && bubble == null) addBubble()
        else if (!want && bubble != null) {
            closePopup(false)
            removeBubble(false)
        }
        status = when {
            inMusicApp -> "Bubble: hidden (you are in the music app)"
            bubble != null -> if (playing) "Bubble: showing (playing)" else "Bubble: showing (paused)"
            !MediaState.hasSession -> "Bubble: waiting for music"
            else -> "Bubble: hidden (paused)"
        }
    }

    // ------------------------------------------------------------------ geometry

    private fun screenW(): Int = wm.currentWindowMetrics.bounds.width()
    private fun screenH(): Int = wm.currentWindowMetrics.bounds.height()

    private fun addBubble() {
        miniState = 0
        val v = BubbleView(this, prefs)
        val total = v.totalPx
        val inset = v.inset.toInt()
        val m = (4 * d).toInt()
        val lp = WindowManager.LayoutParams(
            total, total,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = if (prefs.bubbleX == -99999) screenW() - total + inset - m else prefs.bubbleX
        lp.y = if (prefs.bubbleY == -99999) (screenH() * 0.35f).toInt() else prefs.bubbleY
        lp.x = lp.x.coerceIn(-inset, screenW() - total + inset)
        lp.y = lp.y.coerceIn(-inset, screenH() - total + inset)

        v.setScreenOn(screenOn)
        v.onFling = fl@{ vx, vy ->
            val t = 900f * d
            if (miniState != 0 || inZone) return@fl false
            if (prefs.bubbleTuck && Math.abs(vx) > t && Math.abs(vx) > Math.abs(vy) * 1.2f) {
                hideZone()
                tuck(vx > 0)
                true
            } else false
        }
        v.onTap = tap@{
            if (miniState != 0) { restoreBubble(); return@tap }
            if (prefs.bubbleTapPlay) {
                if (MediaState.hasSession) {
                val willPlay = !MediaState.playing
                MediaState.playPause()
                v.flashAction(willPlay)
                }
            } else {
                togglePopup()
            }
        }
        v.onLong = lg@{
            if (miniState != 0) { restoreBubble(); return@lg }
            if (prefs.bubbleTapPlay) {
                togglePopup()
            } else {
                val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { startActivity(i) } catch (e: Exception) {}
            }
        }
        v.onDrag = { dx, dy ->
            if (popup != null) closePopup(true)
            if (miniState == 1) miniState = 0
            lp.x = (lp.x + dx).toInt().coerceIn(-inset, screenW() - total + inset)
            lp.y = (lp.y + dy).toInt().coerceIn(-inset, screenH() - total + inset)
            try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
            if (miniState == 0) { showZone(); updateZone() }
        }
        v.onRelease = {
            if (inZone) dropInZone() else snap()
            hideZone()
        }
        v.alpha = 0f
        try {
            wm.addView(v, lp)
        } catch (e: Exception) {
            status = "Bubble: couldn't be shown"
            return
        }
        bubble = v
        bubbleLp = lp
        v.animate().alpha(prefs.bubbleOpacity / 100f).setDuration(220).start()
    }

    private fun removeBubble(immediate: Boolean) {
        hideZone()
        val v = bubble ?: return
        handler.removeCallbacks(savePos)
        savePos.run()
        bubble = null
        bubbleLp = null
        if (immediate) {
            try { wm.removeView(v) } catch (e: Exception) {}
            return
        }
        v.animate().alpha(0f).setDuration(220).withEndAction {
            try { wm.removeView(v) } catch (e: Exception) {}
        }.start()
    }

    // ---- minimise: 0 normal, 1 tucked into the edge, 2 shrunk to a dot
    private var miniState = 0
    private var preTuckX = 0

    private fun slideTo(tx: Int) {
        val v = bubble ?: return
        val lp = bubbleLp ?: return
        ValueAnimator.ofInt(lp.x, tx).apply {
            duration = 200
            addUpdateListener {
                lp.x = it.animatedValue as Int
                try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
            }
            start()
        }
    }

    private fun tuck(right: Boolean) {
        val v = bubble ?: return
        val lp = bubbleLp ?: return
        closePopup(true)
        preTuckX = lp.x
        val vis = (14 * d).toInt()
        val tx = if (right) screenW() - v.inset.toInt() - vis else vis + v.inset.toInt() - v.totalPx
        miniState = 1
        slideTo(tx)
    }

    // ---- drop zone shown while dragging the bubble: drop on it to shrink to a dot
    private var zoneView: View? = null
    private var zoneCx = 0
    private var zoneCy = 0
    private var inZone = false

    private fun showZone() {
        if (!prefs.bubbleDot || zoneView != null) return
        val size = (64 * d).toInt()
        val z = object : View(this) {
            override fun onDraw(c: android.graphics.Canvas) {
                val pt = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                pt.color = android.graphics.Color.argb(if (inZone) 200 else 110, 20, 20, 24)
                c.drawCircle(width / 2f, height / 2f, width / 2f * (if (inZone) 1f else 0.82f), pt)
                pt.style = android.graphics.Paint.Style.STROKE
                pt.strokeWidth = 2.2f * d
                pt.strokeCap = android.graphics.Paint.Cap.ROUND
                pt.color = android.graphics.Color.WHITE
                c.drawLine(width / 2f - 9f * d, height / 2f, width / 2f + 9f * d, height / 2f, pt)
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (screenW() - size) / 2
        lp.y = screenH() - size - (110 * d).toInt()
        zoneCx = lp.x + size / 2
        zoneCy = lp.y + size / 2
        z.alpha = 0f
        try { wm.addView(z, lp) } catch (e: Exception) { return }
        zoneView = z
        z.animate().alpha(1f).setDuration(150).start()
    }

    private fun updateZone() {
        val v = bubble ?: return
        val lp = bubbleLp ?: return
        val dx = lp.x + v.totalPx / 2 - zoneCx
        val dy = lp.y + v.totalPx / 2 - zoneCy
        val now = Math.hypot(dx.toDouble(), dy.toDouble()) < 60 * d
        if (now != inZone) {
            inZone = now
            zoneView?.invalidate()
        }
    }

    private fun hideZone() {
        val z = zoneView ?: return
        zoneView = null
        inZone = false
        try { wm.removeView(z) } catch (e: Exception) {}
    }

    private fun dropInZone() {
        val v = bubble ?: return
        val lp = bubbleLp ?: return
        lp.x = zoneCx - v.totalPx / 2
        lp.y = zoneCy - v.totalPx / 2
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
        shrink()
        handler.removeCallbacks(savePos)
        handler.postDelayed(savePos, 400)
    }

    private fun shrink() {
        val v = bubble ?: return
        closePopup(true)
        miniState = 2
        v.animate().scaleX(0.4f).scaleY(0.4f).alpha(prefs.bubbleOpacity / 100f * 0.8f).setDuration(200).start()
    }

    private fun restoreBubble() {
        val v = bubble ?: return
        if (miniState == 1) slideTo(preTuckX)
        if (miniState == 2) v.animate().scaleX(1f).scaleY(1f).alpha(prefs.bubbleOpacity / 100f).setDuration(200).start()
        miniState = 0
        handler.removeCallbacks(savePos)
        handler.postDelayed(savePos, 500)
    }

    private fun snap() {
        val v = bubble ?: return
        val lp = bubbleLp ?: return
        if (!prefs.bubbleSnap) {
            handler.removeCallbacks(savePos)
            handler.postDelayed(savePos, 300)
            return
        }
        val sw = screenW()
        val total = v.totalPx
        val inset = v.inset.toInt()
        val m = (4 * d).toInt()
        val center = lp.x + total / 2
        val tx = if (center < sw / 2) m - inset else sw - total + inset - m
        ValueAnimator.ofInt(lp.x, tx).apply {
            duration = 180
            addUpdateListener {
                lp.x = it.animatedValue as Int
                try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
            }
            start()
        }
        handler.removeCallbacks(savePos)
        handler.postDelayed(savePos, 400)
    }

    // ------------------------------------------------------------------ pop-up card

    private fun togglePopup() {
        if (popup != null) closePopup(false) else openPopup()
    }

    private fun armClose() {
        handler.removeCallbacks(popupClose)
        if (prefs.popupClose > 0) handler.postDelayed(popupClose, prefs.popupClose * 1000L)
    }

    private fun openPopup() {
        val b = bubble ?: return
        val lp = bubbleLp ?: return
        val sw = screenW()
        val sh = screenH()
        val margin = (8 * d).toInt()
        val pw = minOf((prefs.popupWidth * d).toInt(), sw - 2 * margin)

        val card = CardView(this, prefs)
        card.renderer.showMinChip = prefs.bubbleDot
        card.onMinimize = { shrink() }
        card.measure(
            View.MeasureSpec.makeMeasureSpec(pw, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(sh, View.MeasureSpec.AT_MOST)
        )
        val ph = card.measuredHeight

        val total = b.totalPx
        val inset = b.inset.toInt()
        val bx = lp.x + total / 2
        val x = (bx - pw / 2).coerceIn(margin, sw - pw - margin)
        val below = lp.y + total - inset + margin
        val fitsBelow = below + ph <= sh - margin
        val y = if (fitsBelow) below else (lp.y + inset - margin - ph).coerceAtLeast(margin)

        val sc = View(this)
        sc.setOnClickListener { closePopup(false) }
        val scLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        val cLp = WindowManager.LayoutParams(
            pw, ph,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        cLp.gravity = Gravity.TOP or Gravity.START
        cLp.x = x
        cLp.y = y

        card.onInteract = { armClose() }
        card.onTap = {
            val i = MediaState.launchIntent(this)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { startActivity(i) } catch (e: Exception) {}
            }
            closePopup(false)
        }
        card.alpha = 0f
        card.pivotX = (bx - x).toFloat().coerceIn(0f, pw.toFloat())
        card.pivotY = if (fitsBelow) 0f else ph.toFloat()
        card.scaleX = 0.88f
        card.scaleY = 0.88f
        try {
            wm.addView(sc, scLp)
            wm.addView(card, cLp)
        } catch (e: Exception) {
            try { wm.removeView(sc) } catch (e2: Exception) {}
            return
        }
        scrim = sc
        popup = card
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
        armClose()
    }

    private fun closePopup(immediate: Boolean) {
        handler.removeCallbacks(popupClose)
        val card = popup
        val sc = scrim
        popup = null
        scrim = null
        if (sc != null) {
            try { wm.removeView(sc) } catch (e: Exception) {}
        }
        if (card == null) return
        if (immediate) {
            try { wm.removeView(card) } catch (e: Exception) {}
            return
        }
        card.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(150).withEndAction {
            try { wm.removeView(card) } catch (e: Exception) {}
        }.start()
    }
}
