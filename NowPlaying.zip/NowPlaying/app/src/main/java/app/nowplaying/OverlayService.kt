package app.nowplaying

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/**
 * Owns the floating bubble and its pop-up card. Every window here has a fixed size, so nothing
 * is ever resized (the system animates window resizes, which looks like things flying around).
 */
class OverlayService : Service() {

    companion object {
        @Volatile
        var status = "Bubble: off"
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())
    private val d get() = resources.displayMetrics.density

    private var bubble: BubbleView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var scrim: View? = null
    private var popup: CardView? = null
    private var screenOn = true
    private var pausedExpired = false
    private var pausedArmed = false

    private val listener: () -> Unit = { sync() }
    private val savePos = Runnable {
        bubbleLp?.let {
            prefs.bubbleX = it.x
            prefs.bubbleY = it.y
        }
    }
    private val pausedHide = Runnable {
        pausedArmed = false
        pausedExpired = true
        sync()
    }
    private val popupClose = Runnable { closePopup(false) }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            screenOn = intent.action != Intent.ACTION_SCREEN_OFF
            bubble?.setScreenOn(screenOn)
            if (!screenOn) closePopup(true)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        wm = getSystemService(WindowManager::class.java)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("np_overlay", "Floating bubble", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction("np.STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "np_overlay")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Now Playing bubble is on")
            .setContentText("Tap to open settings")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "Turn off", stop
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(screenReceiver, f)
        MediaState.ensureStarted(this)
        MediaState.addListener(listener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "np.STOP") {
            prefs.bubbleOn = false
            status = "Bubble: off"
            stopSelf()
            return START_NOT_STICKY
        }
        // settings may have changed: rebuild everything
        closePopup(true)
        removeBubble(true)
        pausedExpired = false
        sync()
        return START_STICKY
    }

    override fun onDestroy() {
        MediaState.removeListener(listener)
        try { unregisterReceiver(screenReceiver) } catch (e: Exception) {}
        handler.removeCallbacksAndMessages(null)
        closePopup(true)
        removeBubble(true)
        super.onDestroy()
    }

    // ------------------------------------------------------------------ visibility

    private fun sync() {
        if (!Settings.canDrawOverlays(this)) {
            status = "Bubble: needs \"Display over other apps\""
            closePopup(true)
            removeBubble(true)
            return
        }
        val playing = MediaState.playing
        val keep = prefs.bubbleKeepPaused && MediaState.hasSession
        if (playing) {
            pausedExpired = false
            pausedArmed = false
            handler.removeCallbacks(pausedHide)
        } else if (keep && prefs.bubbleHideMin > 0 && !pausedArmed && !pausedExpired) {
            pausedArmed = true
            handler.postDelayed(pausedHide, prefs.bubbleHideMin * 60_000L)
        } else if (!keep) {
            pausedArmed = false
            handler.removeCallbacks(pausedHide)
        }
        val want = playing || (keep && !pausedExpired)
        if (want && bubble == null) addBubble()
        else if (!want && bubble != null) {
            closePopup(false)
            removeBubble(false)
        }
        status = when {
            bubble != null -> if (playing) "Bubble: showing (playing)" else "Bubble: showing (paused)"
            !MediaState.hasSession -> "Bubble: waiting for music"
            else -> "Bubble: hidden (paused)"
        }
    }

    // ------------------------------------------------------------------ geometry

    private fun screenW(): Int = wm.currentWindowMetrics.bounds.width()
    private fun screenH(): Int = wm.currentWindowMetrics.bounds.height()

    private fun addBubble() {
        val v = BubbleView(this, prefs)
        val total = v.totalPx
        val inset = v.inset.toInt()
        val m = (4 * d).toInt()
        val lp = WindowManager.LayoutParams(
            total, total,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = if (prefs.bubbleX == -99999) screenW() - total + inset - m else prefs.bubbleX
        lp.y = if (prefs.bubbleY == -99999) (screenH() * 0.35f).toInt() else prefs.bubbleY
        lp.x = lp.x.coerceIn(-inset, screenW() - total + inset)
        lp.y = lp.y.coerceIn(-inset, screenH() - total + inset)

        v.setScreenOn(screenOn)
        v.onTap = {
            if (prefs.bubbleTapPlay) {
                if (MediaState.hasSession) {
                val willPlay = !MediaState.playing
                MediaState.playPause()
                v.flashAction(willPlay)
                }
            } else {
                togglePopup()
            }
        }
        v.onLong = {
            if (prefs.bubbleTapPlay) {
                togglePopup()
            } else {
                val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { startActivity(i) } catch (e: Exception) {}
            }
        }
        v.onDrag = { dx, dy ->
            if (popup != null) closePopup(true)
            lp.x = (lp.x + dx).toInt().coerceIn(-inset, screenW() - total + inset)
            lp.y = (lp.y + dy).toInt().coerceIn(-inset, screenH() - total + inset)
            try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
        }
        v.onRelease = { snap() }
        v.alpha = 0f
        try {
            wm.addView(v, lp)
        } catch (e: Exception) {
            status = "Bubble: couldn't be shown"
            return
        }
        bubble = v
        bubbleLp = lp
        v.animate().alpha(prefs.bubbleOpacity / 100f).setDuration(220).start()
    }

    private fun removeBubble(immediate: Boolean) {
        val v = bubble ?: return
        handler.removeCallbacks(savePos)
        savePos.run()
        bubble = null
        bubbleLp = null
        if (immediate) {
            try { wm.removeView(v) } catch (e: Exception) {}
            return
        }
        v.animate().alpha(0f).setDuration(220).withEndAction {
            try { wm.removeView(v) } catch (e: Exception) {}
        }.start()
    }

    private fun snap() {
        val v = bubble ?: return
        val lp = bubbleLp ?: return
        if (!prefs.bubbleSnap) {
            handler.removeCallbacks(savePos)
            handler.postDelayed(savePos, 300)
            return
        }
        val sw = screenW()
        val total = v.totalPx
        val inset = v.inset.toInt()
        val m = (4 * d).toInt()
        val center = lp.x + total / 2
        val tx = if (center < sw / 2) m - inset else sw - total + inset - m
        ValueAnimator.ofInt(lp.x, tx).apply {
            duration = 180
            addUpdateListener {
                lp.x = it.animatedValue as Int
                try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
            }
            start()
        }
        handler.removeCallbacks(savePos)
        handler.postDelayed(savePos, 400)
    }

    // ------------------------------------------------------------------ pop-up card

    private fun togglePopup() {
        if (popup != null) closePopup(false) else openPopup()
    }

    private fun armClose() {
        handler.removeCallbacks(popupClose)
        if (prefs.popupClose > 0) handler.postDelayed(popupClose, prefs.popupClose * 1000L)
    }

    private fun openPopup() {
        val b = bubble ?: return
        val lp = bubbleLp ?: return
        val sw = screenW()
        val sh = screenH()
        val margin = (8 * d).toInt()
        val pw = minOf((prefs.popupWidth * d).toInt(), sw - 2 * margin)

        val card = CardView(this, prefs)
        card.measure(
            View.MeasureSpec.makeMeasureSpec(pw, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(sh, View.MeasureSpec.AT_MOST)
        )
        val ph = card.measuredHeight

        val total = b.totalPx
        val inset = b.inset.toInt()
        val bx = lp.x + total / 2
        val x = (bx - pw / 2).coerceIn(margin, sw - pw - margin)
        val below = lp.y + total - inset + margin
        val fitsBelow = below + ph <= sh - margin
        val y = if (fitsBelow) below else (lp.y + inset - margin - ph).coerceAtLeast(margin)

        val sc = View(this)
        sc.setOnClickListener { closePopup(false) }
        val scLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        val cLp = WindowManager.LayoutParams(
            pw, ph,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        cLp.gravity = Gravity.TOP or Gravity.START
        cLp.x = x
        cLp.y = y

        card.onInteract = { armClose() }
        card.onTap = {
            val i = MediaState.launchIntent(this)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { startActivity(i) } catch (e: Exception) {}
            }
            closePopup(false)
        }
        card.alpha = 0f
        card.pivotX = (bx - x).toFloat().coerceIn(0f, pw.toFloat())
        card.pivotY = if (fitsBelow) 0f else ph.toFloat()
        card.scaleX = 0.88f
        card.scaleY = 0.88f
        try {
            wm.addView(sc, scLp)
            wm.addView(card, cLp)
        } catch (e: Exception) {
            try { wm.removeView(sc) } catch (e2: Exception) {}
            return
        }
        scrim = sc
        popup = card
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
        armClose()
    }

    private fun closePopup(immediate: Boolean) {
        handler.removeCallbacks(popupClose)
        val card = popup
        val sc = scrim
        popup = null
        scrim = null
        if (sc != null) {
            try { wm.removeView(sc) } catch (e: Exception) {}
        }
        if (card == null) return
        if (immediate) {
            try { wm.removeView(card) } catch (e: Exception) {}
            return
        }
        card.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(150).withEndAction {
            try { wm.removeView(card) } catch (e: Exception) {}
        }.start()
    }
}
