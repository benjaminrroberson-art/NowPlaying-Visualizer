package app.nowplaying

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager

/** Shows the card as a draggable floating window above other apps. */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())
    private var card: CardView? = null
    private var lp: WindowManager.LayoutParams? = null
    private val listener: () -> Unit = { sync() }
    private val savePos = Runnable {
        lp?.let {
            prefs.overlayX = it.x
            prefs.overlayY = it.y
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        wm = getSystemService(WindowManager::class.java)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("np_overlay", "Floating card", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction("np.STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "np_overlay")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Now Playing Card is on")
            .setContentText("Tap to open settings")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "Turn off", stop
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        MediaState.ensureStarted(this)
        MediaState.addListener(listener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "np.STOP") {
            prefs.overlayOn = false
            stopSelf()
            return START_NOT_STICKY
        }
        removeCard()   // settings may have changed; rebuild
        sync()
        return START_STICKY
    }

    private fun sync() {
        val want = Settings.canDrawOverlays(this) &&
            (!prefs.overlayHideIdle || MediaState.playing)
        if (want && card == null) addCard()
        else if (!want && card != null) removeCard()
    }

    private fun addCard() {
        val d = resources.displayMetrics.density
        val screenW = resources.displayMetrics.widthPixels
        val wpx = minOf((prefs.overlayWidth * d).toInt(), screenW - (16 * d).toInt())
        val v = CardView(this, prefs)
        val params = WindowManager.LayoutParams(
            wpx,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = prefs.overlayX
        params.y = prefs.overlayY
        v.onDrag = { dx, dy ->
            params.x = (params.x + dx).toInt().coerceAtLeast(0)
            params.y = (params.y + dy).toInt().coerceAtLeast(0)
            try { wm.updateViewLayout(v, params) } catch (e: Exception) {}
            handler.removeCallbacks(savePos)
            handler.postDelayed(savePos, 400)
        }
        v.onTap = {
            val i = MediaState.launchIntent(this) ?: Intent(this, PlayerActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { startActivity(i) } catch (e: Exception) {}
        }
        try {
            wm.addView(v, params)
            card = v
            lp = params
        } catch (e: Exception) {
        }
    }

    private fun removeCard() {
        handler.removeCallbacks(savePos)
        savePos.run()
        card?.let {
            try { wm.removeView(it) } catch (e: Exception) {}
        }
        card = null
        lp = null
    }

    override fun onDestroy() {
        MediaState.removeListener(listener)
        removeCard()
        super.onDestroy()
    }
}
