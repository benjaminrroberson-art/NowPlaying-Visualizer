package app.nowplaying

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var p: Prefs
    private lateinit var col: LinearLayout
    private lateinit var card: CardView
    private var density = 1f
    private val handler = Handler(Looper.getMainLooper())
    private val refreshers = ArrayList<() -> Unit>()
    private var active = false

    private fun dp(i: Int) = (i * density).toInt()

    private object Nav { var page = "home"; var homeY = 0; var vizEdit = -1 }
    private var skipSection = false
    /** Own reader for the preview card, so the Visualizer page can preview the style being edited. */
    private val pv by lazy { Prefs(this) }


    private fun go(pg: String) {
        if (Nav.page == "home") Nav.homeY = vScroll?.scrollY ?: 0
        Nav.page = pg
        if (pg == "home") {
            Keep.y = Nav.homeY
            Keep.xs = ArrayList()
            Keep.on = true
        } else {
            Keep.on = false
        }
        recreate()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (Nav.page != "home") go("home") else super.onBackPressed()
    }

    // keep scroll positions across recreateKeep() so lists don't snap back
    private var vScroll: ScrollView? = null
    private val hScrolls = ArrayList<HorizontalScrollView>()
    private object Keep { var y = 0; var xs = ArrayList<Int>(); var on = false }

    private fun hscroll(inner: View): HorizontalScrollView {
        val h = HorizontalScrollView(this).apply { addView(inner) }
        hScrolls.add(h)
        return h
    }

    private fun recreateKeep() {
        Keep.y = vScroll?.scrollY ?: 0
        Keep.xs = ArrayList(hScrolls.map { it.scrollX })
        Keep.on = true
        recreate()
    }

    private fun restoreScroll() {
        if (!Keep.on) return
        Keep.on = false
        val y = Keep.y
        val xs = Keep.xs
        vScroll?.post {
            vScroll?.scrollTo(0, y)
            hScrolls.forEachIndexed { i, h -> if (i < xs.size) h.scrollTo(xs[i], 0) }
        }
    }

    // Built-in looks. Keys match Prefs.lookKeys; anything not listed is reset to its default.
    private val builtIn: List<Pair<String, Map<String, Any>>> = listOf(
        "Minimal" to mapOf("vizStyle" to 0, "bgMode" to 0, "bgColor" to 0xFF111214.toInt(), "bgOpacity" to 94, "vizBars" to 28),
        "Glass" to mapOf("vizStyle" to 7, "bgMode" to 2, "bgOpacity" to 82, "corner" to 32),
        "Neon ring" to mapOf("vizStyle" to 4, "vizColorMode" to 3, "bgMode" to 0, "bgColor" to 0xFF0B0B10.toInt(), "vizBars" to 48, "bgOpacity" to 95),
        "Pulse" to mapOf("vizStyle" to 5, "bgMode" to 2),
        "Scope" to mapOf(
            "vizStyle" to 2, "vizColorMode" to 1, "bgMode" to 0, "bgColor" to 0xFF08090C.toInt(),
            "font" to 5, "titleBold" to false, "bgOpacity" to 95
        ),
        "Skyline" to mapOf(
            "vizStyle" to 3, "vizColorMode" to 1, "vizColor" to 0xFFFF9100.toInt(), "vizColor2" to 0xFFFF4081.toInt(), "bgMode" to 1
        ),
        "Particles" to mapOf("vizStyle" to 6, "bgMode" to 2),
        "LED" to mapOf(
            "vizStyle" to 0, "vizSegments" to true, "vizColorMode" to 1, "vizColor" to 0xFF76FF03.toInt(),
            "vizColor2" to 0xFFFF1744.toInt(), "bgMode" to 0, "bgColor" to 0xFF000000.toInt(), "font" to 2,
            "vizHeight" to 64, "vizBars" to 24, "bgOpacity" to 96
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs(this)
        density = resources.displayMetrics.density
        EqEngine.ctx = applicationContext
        MediaState.ensureStarted(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setOnApplyWindowInsetsListener { v, ins ->
                val i = ins.getInsets(WindowInsets.Type.systemBars())
                v.setPadding(i.left, i.top, i.right, i.bottom)
                ins
            }
        }
        card = CardView(this, pv)
        card.onTap = { startActivity(Intent(this, PlayerActivity::class.java)) }
        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), dp(32))
        }
        root.addView(
            ScrollView(this).apply { addView(col) }.also { vScroll = it },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT) {
                if (Nav.page != "home") go("home") else finish()
            }
        }
        if (Nav.page != "viz") pv.ov.remove("vizStyle")
        if (Nav.page == "home") {
            addCardPreview()
            buildHome()
        } else {
            val title = PAGES.firstOrNull { it.first == Nav.page }?.second ?: "Settings"
            subHeader(title)
            if (Nav.page in setOf("viz", "panel", "textctl")) addCardPreview()
            if (Nav.page == "bubble") addBubblePreview()
            skipSection = true
            when (Nav.page) {
                "viz" -> buildVisualizer()
                "panel" -> buildPanel()
                "textctl" -> { buildText(); buildControls() }
                "eq" -> buildEq()
                "bubble" -> buildBubble()
                "saver" -> buildSaver()
                "capture" -> buildCapture()
                else -> buildPanel()
            }
        }
        restoreScroll()
        WhatsNew.maybeShow(this, p)
        OverlayService.ensure(this)
        if (p.eqOn) EqService.sync(this)
    }

    override fun onResume() {
        super.onResume()
        active = true
        MediaState.retry()
        Audio.retry(this)
        card.reload()
        refreshers.forEach { it() }
        handler.post(ticker)
    }

    override fun onPause() {
        active = false
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!active) return
            refreshers.forEach { it() }
            handler.postDelayed(this, 1000)
        }
    }

    private val handler0 = android.os.Handler(android.os.Looper.getMainLooper())

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 78 && resultCode == RESULT_OK && data?.data != null) {
            try {
                val txt = contentResolver.openInputStream(data.data!!)?.use { ins ->
                    String(ins.readBytes().take(400_000).toByteArray())
                } ?: ""
                importBox?.setText(txt)
                doImport(txt)
            } catch (e: Exception) {
                toast("Couldn't read that file")
            }
        }
        if (requestCode == 77) {
            if (resultCode == RESULT_OK && data != null) {
                CaptureService.start(this, resultCode, data)
                handler0.postDelayed({ refreshers.forEach { it() } }, 1000)
            } else {
                toast("Capture permission was declined")
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Audio.retry(this)
        refreshers.forEach { it() }
    }

    // -------------------------------------------------------------------- sections

    private val PAGES = listOf(
        Triple("viz", "Visualizer", ""),
        Triple("bubble", "Floating Bubble", ""),
        Triple("panel", "Panel", ""),
        Triple("saver", "Screen Saver", ""),
        Triple("textctl", "Text & Controls", ""),
        Triple("eq", "Equalizer", ""),
        Triple("capture", "Audio Capture", "")
    ).map { Pair(it.first, it.second) }
    private val PAGE_SUB = mapOf(
        "viz" to "Colors, bars, sensitivity and more, set separately for each style",
        "bubble" to "Style, graphic, behavior, size, shape, pop-up",
        "panel" to "Style, looks and presets, graphic, album art, background",
        "saver" to "Style, layouts, clock, brightness, controls",
        "textctl" to "Global style: fonts, text, buttons and progress bar",
        "eq" to "Bands, presets, import, method",
        "capture" to "Only needed if the visualizer stays flat"
    )

    private fun addCardPreview() {
        col.addView(
            card,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(0, dp(10), 0, dp(10)) }
        )
    }

    private var bubblePrevBox: android.widget.FrameLayout? = null

    private fun addBubblePreview() {
        val box = android.widget.FrameLayout(this).apply { setBackgroundColor(0xFF15171B.toInt()) }
        bubblePrevBox = box
        col.addView(
            box,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(0, dp(10), 0, dp(10)) }
        )
        rebuildBubblePreview()
    }

    private fun rebuildBubblePreview() {
        val box = bubblePrevBox ?: return
        box.removeAllViews()
        val b = BubbleView(this, p)
        b.setScreenOn(true)
        box.addView(b, android.widget.FrameLayout.LayoutParams(b.totalPx, b.totalPx, Gravity.CENTER))
    }

    private fun subHeader(title: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, 0)
        }
        row.addView(Button(this).apply {
            text = "‹ Back"
            isAllCaps = false
            setOnClickListener { go("home") }
        })
        row.addView(TextView(this).apply {
            text = title
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(12), 0, 0, 0)
        })
        col.addView(row)
    }

    private fun menuRow(pg: String, title: String) {
        col.addView(Button(this).apply {
            text = title + "  ›\n" + (PAGE_SUB[pg] ?: "")
            isAllCaps = false
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            setOnClickListener { go(pg) }
        })
    }

    private fun buildHome() {
        section("Setup")
        label("Do these once. Notification access is the only one you must have. The rest unlock extra features.")
        permRow(
            "Notification access (required)",
            "Lets the app see what is playing and control it. No notifications are read.",
            { listenerEnabled() }
        ) { Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }
        val audioRow = TextView(this).apply { setPadding(0, dp(8), 0, 0) }
        val audioBtn = Button(this).apply {
            text = "Grant audio permission"
            isAllCaps = false
            setOnClickListener { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2) }
        }
        refreshers.add {
            val ok = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            audioRow.text = (if (ok) "✅ " else "❌ ") + "Audio permission (for the visualizer)\n" +
                "Android calls this the microphone permission. The music is only analysed live, never recorded."
            audioBtn.visibility = if (ok) View.GONE else View.VISIBLE
        }
        col.addView(audioRow)
        col.addView(audioBtn)
        permRow(
            "Display over other apps (for the bubble)",
            "Lets the floating bubble appear on top of other apps.",
            { Settings.canDrawOverlays(this) }
        ) { Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")) }

        val eqPerm = TextView(this).apply { setPadding(0, dp(8), 0, 0) }
        val eqPermBtn = Button(this).apply {
            text = "How to enable"
            isAllCaps = false
            setOnClickListener { dumpHelpDialog() }
        }
        refreshers.add {
            val ok = EqEngine.hasDump()
            eqPerm.text = (if (ok) "✅ " else "⚪ ") + "Equalizer permission (only for the EQ)\n" +
                "Lets the EQ find which apps are playing so it can work on Bluetooth. A one-time step done from a computer."
            eqPermBtn.visibility = if (ok) View.GONE else View.VISIBLE
        }
        col.addView(eqPerm)
        col.addView(eqPermBtn)

        col.addView(Switch(this).apply {
            text = "Demo mode (fake music, to try looks)"
            isChecked = MediaState.demo
            setPadding(0, dp(12), 0, dp(4))
            setOnCheckedChangeListener { _, on -> MediaState.setDemo(on) }
        })
        val status = TextView(this).apply { textSize = 12f; setPadding(0, dp(6), 0, 0) }
        refreshers.add {
            status.text = MediaState.status + "\n" + Audio.status + "\n" + OverlayService.status
        }
        col.addView(status)

        col.addView(Button(this).apply {
            text = "What's new"
            isAllCaps = false
            setOnClickListener { WhatsNew.show(this@MainActivity, true, p) }
        })
        col.addView(Button(this).apply {
            text = "Open full-screen player"
            isAllCaps = false
            setOnClickListener { startActivity(Intent(this@MainActivity, PlayerActivity::class.java)) }
        })

        section("Main switches")
        bubbleSwitch()
        switchRowPlain("Equalizer on", { p.eqOn }) {
            p.eqOn = it
            EqService.sync(this)
            EqEngine.apply(p)
        }
        val eqStatus = TextView(this).apply { textSize = 12f }
        refreshers.add { eqStatus.text = if (p.eqOn) EqEngine.status else "" }
        col.addView(eqStatus)
        menuRow("eq", "Equalizer")

        section("Visualizer styles")
        switchRowPlain("Same style for panel, bubble and screen saver", { p.vizSameAll }) { on ->
            if (on) p.vizAllStyle = p.vizStyle
            p.vizSameAll = on
            changed()
            recreateKeep()
        }
        if (p.vizSameAll) {
            choice("Style", CardRenderer.PICK_NAMES, { CardRenderer.PICK.indexOf(p.vizAllStyle).coerceAtLeast(0) }) {
                p.vizAllStyle = CardRenderer.PICK[it]
            }
        } else {
            choice("Panel", CardRenderer.PICK_NAMES, { CardRenderer.PICK.indexOf(p.vizStyle).coerceAtLeast(0) }) {
                p.vizStyle = CardRenderer.PICK[it]
            }
            choice("Bubble", CardRenderer.PICK_NAMES, { CardRenderer.PICK.indexOf(p.bubbleStyle).coerceAtLeast(0) }) {
                p.bubbleStyle = CardRenderer.PICK[it]
            }
            choice(
                "Screen saver",
                listOf("Same as the panel") + CardRenderer.PICK_NAMES,
                { if (p.saverStyle < 0) 0 else CardRenderer.PICK.indexOf(p.saverStyle).coerceAtLeast(0) + 1 }
            ) { p.saverStyle = if (it == 0) -1 else CardRenderer.PICK[it - 1] }
        }
        label("Colors, sensitivity and the rest of each style are in the Visualizer menu below. Each menu also has its own style picker.")

        section("Customize")
        PAGES.filter { it.first != "eq" }.forEach { menuRow(it.first, it.second) }
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }
        col.addView(TextView(this).apply {
            text = "Version $ver"
            textSize = 12f
            setPadding(0, dp(24), 0, 0)
        })
    }

    private fun dumpHelpDialog() {
        val cmd = "pm grant app.nowplaying android.permission.DUMP"
        AlertDialog.Builder(this)
            .setTitle("Equalizer permission")
            .setMessage(
                "Why: the EQ attaches to each app that is playing sound. Android only lets an app see which apps are playing " +
                    "if it holds the DUMP permission, and that can't be granted from a normal settings screen. You do it once.\n\n" +
                    "1. Turn on Developer options (Settings > About phone, tap Build number 7 times), then turn on USB debugging.\n" +
                    "2. On a computer, open app.webadb.com in Chrome, plug in the phone, tap Connect and allow it on the phone.\n" +
                    "3. Open its shell and run:\n$cmd\n\n" +
                    "Without it the EQ falls back to the system-wide method, which doesn't work on some Bluetooth devices."
            )
            .setPositiveButton("Copy command") { _, _ ->
                val cm = getSystemService(android.content.ClipboardManager::class.java)
                cm.setPrimaryClip(android.content.ClipData.newPlainText("cmd", cmd))
                toast("Copied")
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun fmtMin(mins: Int): String {
        val c = java.util.Calendar.getInstance()
        c.set(java.util.Calendar.HOUR_OF_DAY, mins / 60)
        c.set(java.util.Calendar.MINUTE, mins % 60)
        return android.text.format.DateFormat.getTimeFormat(this).format(c.time)
    }

    private fun pickTime(cur: Int, done: (Int) -> Unit) {
        android.app.TimePickerDialog(
            this,
            { _, h, mi -> done(h * 60 + mi) },
            cur / 60, cur % 60,
            android.text.format.DateFormat.is24HourFormat(this)
        ).show()
    }

    private var saverPreview: SaverView? = null

    private fun buildSaver() {
        label(
            "A screen saver for when the phone is charging: album art, a big visualizer or a clock on a black screen. " +
                "Tap it for playback controls. To use it, open Android's screen saver settings below, pick \"Now Playing Card\" " +
                "and set it to start while charging. To start it any time (on battery too), add the \"Screen saver\" tile to your Quick Settings."
        )
        surfaceStyle(2)
        // live preview: render at full screen size, then scale down
        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels
        val scale = (dp(210).toFloat() / sw)
        val pv = SaverView(this, true)
        saverPreview = pv
        val frame = android.widget.FrameLayout(this).apply {
            clipChildren = true
            setBackgroundColor(Color.BLACK)
        }
        pv.pivotX = 0f
        pv.pivotY = 0f
        pv.scaleX = scale
        pv.scaleY = scale
        frame.addView(pv, android.widget.FrameLayout.LayoutParams(sw, sh))
        col.addView(
            frame,
            LinearLayout.LayoutParams((sw * scale).toInt(), (sh * scale).toInt()).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = dp(10)
                bottomMargin = dp(6)
            }
        )
        refreshers.add { pv.invalidate() }
        col.addView(Button(this).apply {
            text = "Try demo music in the preview"
            isAllCaps = false
            setOnClickListener { MediaState.setDemo(true); pv.invalidate() }
        })
        col.addView(Button(this).apply {
            text = "Preview full screen"
            isAllCaps = false
            setOnClickListener { startActivity(Intent(this@MainActivity, SaverActivity::class.java)) }
        })
        col.addView(Button(this).apply {
            text = "Open Android screen saver settings"
            isAllCaps = false
            setOnClickListener {
                try { startActivity(Intent(Settings.ACTION_DREAM_SETTINGS)) }
                catch (e: Exception) { toast("Open Settings > Display > Screen saver") }
            }
        })

        choice(
            "Layout",
            listOf("Art + visualizer", "Big visualizer", "Clock + track", "Visualizer only"),
            { p.saverLayout }
        ) { p.saverLayout = it }
        switchRow("Show album art (layouts with art)", { p.saverArt }) { p.saverArt = it }
        switchRow("Art + visualizer: put the visualizer on top and the art below", { p.saverSwap }) { p.saverSwap = it }
        switchRow("Show track title and artist", { p.saverText }) { p.saverText = it }
        switchRow("Show the clock", { p.saverClock }) { p.saverClock = it }
        switchRow("24-hour clock", { p.saverClock24 }) { p.saverClock24 = it }
        choice(
            "Clock position preset",
            listOf("Top left", "Top center", "Top right", "Middle", "Bottom left", "Bottom center", "Bottom right"),
            { if (p.saverClockFree) p.saverClockPos else -1 }
        ) {
            val xy = arrayOf(intArrayOf(18, 11), intArrayOf(50, 11), intArrayOf(82, 11), intArrayOf(50, 50),
                intArrayOf(18, 92), intArrayOf(50, 92), intArrayOf(82, 92))[it]
            p.saverClockPos = it
            p.saverClockX = xy[0]
            p.saverClockYp = xy[1]
            p.saverClockFree = true
            recreateKeep()
        }
        slider("Clock position: across", "%", 0, 100, if (p.saverClockFree) p.saverClockX else 50) { p.saverClockX = it; p.saverClockFree = true }
        slider("Clock position: down", "%", 0, 100, if (p.saverClockFree) p.saverClockYp else 8) { p.saverClockYp = it; p.saverClockFree = true }
        label("Move the clock out from behind the front camera with the sliders, or pick a preset.")
        slider("Clock size", "dp", 12, 90, p.saverClockSize) { p.saverClockSize = it }
        slider("Large clock size (Clock + track layout)", "%", 40, 160, p.saverBigClock) { p.saverBigClock = it }
        slider("Album art size", "%", 50, 115, p.saverArtSize) { p.saverArtSize = it }
        slider("Visualizer opacity", "%", 20, 100, if (p.has("saverOpacity")) p.saverOpacity else p.vizOpacity) { p.saverOpacity = it }
        slider("Visualizer height", "%", 20, 100, p.saverVizHeight) { p.saverVizHeight = it }
        choice("When music is paused", listOf("Show the clock only", "Blank screen"), { p.saverPaused }) { p.saverPaused = it }
        slider("Brightness", "%", 5, 100, p.saverBright) { p.saverBright = it }
        label("Burn-in protection: it happens when the same pixels stay lit the same way for hours. Neither option is needed if you rarely leave it on.")
        switchRow("Blurred album-art background (slowly turning)", { p.saverBackdropOn }) { p.saverBackdropOn = it }
        label("Keeps the whole screen gently changing, but lights more of it, so it uses more battery.")
        slider("Blurred background brightness", "%", 5, 80, p.saverBackdrop) { p.saverBackdrop = it }
        switchRow("Drift the picture slightly", { p.saverDrift }) { p.saverDrift = it }
        slider("Drift: move every", "sec", 10, 180, p.saverShift) { p.saverShift = it }
        slider("Frame rate", "fps", 10, 60, p.saverFps) { p.saverFps = it }
        switchRow("Quiet hours: no screen saver during these times", { p.saverSched }) {
            p.saverSched = it
            recreateKeep()
        }
        if (p.saverSched) {
            col.addView(Button(this).apply {
                text = "Off from  " + fmtMin(p.saverSchedFrom)
                isAllCaps = false
                setOnClickListener { pickTime(p.saverSchedFrom) { p.saverSchedFrom = it; recreateKeep() } }
            })
            col.addView(Button(this).apply {
                text = "Back on at  " + fmtMin(p.saverSchedTo)
                isAllCaps = false
                setOnClickListener { pickTime(p.saverSchedTo) { p.saverSchedTo = it; recreateKeep() } }
            })
            label("Applies to the automatic screen saver only. The Quick Settings tile and Preview still work. When it's quiet, the phone goes back to its normal screen timeout instead.")
        }
        switchRow("Tap shows playback controls", { p.saverControls }) { p.saverControls = it }
        label("With this off, a tap closes the screen saver instead. The power button always closes it.")
    }

    private fun buildCapture() {
        label(
            "What it does: normally the visualizer listens to the phone's audio output. On some setups, mostly Bluetooth " +
                "headphones, that gives it silence and the visualizer stays flat. Playback capture reads what the music app " +
                "plays instead."
        )
        label(
            "When to use it: only if the visualizer doesn't move while music plays. It is not needed for the equalizer, " +
                "and not needed for the bubble to appear."
        )
        label(
            "Good to know: Android shows a screen-sharing prompt each time you start it (pick \"entire screen\"; " +
                "nothing is recorded). Some apps block capture. Only one app on the phone can capture at a time, so it " +
                "won't work while another audio-effects app holds that slot."
        )
        val capBtn = Button(this).apply {
            isAllCaps = false
            setOnClickListener {
                if (CaptureService.running) {
                    CaptureService.stop(this@MainActivity)
                } else {
                    startActivity(Intent(this@MainActivity, CaptureActivity::class.java))
                }
                handler0.postDelayed({ refreshers.forEach { it() } }, 800)
            }
        }
        refreshers.add {
            capBtn.text = if (CaptureService.running) "Stop playback capture" else "Start playback capture"
        }
        col.addView(capBtn)
        val status = TextView(this).apply { textSize = 12f; setPadding(0, dp(6), 0, 0) }
        refreshers.add { status.text = Audio.status }
        col.addView(status)
    }

    private fun bubbleSwitch() {
        col.addView(Switch(this).apply {
            text = "Show the floating bubble"
            isChecked = p.bubbleOn
            setPadding(0, dp(8), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                p.bubbleOn = on
                if (on && Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
                }
                if (on && !Settings.canDrawOverlays(this@MainActivity)) {
                    toast("Allow \"Display over other apps\" first")
                }
                applyOverlay()
            }
        })
    }

    private fun switchRowPlain(name: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        col.addView(Switch(this).apply {
            text = name
            isChecked = get()
            setPadding(0, dp(8), 0, dp(4))
            setOnCheckedChangeListener { _, on -> set(on) }
        })
    }

    private fun buildLooks() {
        section("Looks and presets")
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        builtIn.forEach { (name, map) ->
            row.addView(Button(this).apply {
                text = name
                isAllCaps = false
                setOnClickListener {
                    p.apply(map)
                    Looks.loaded = ""
                    changed()
                    recreateKeep()
                }
            })
        }
        col.addView(hscroll(row))
        col.addView(Button(this).apply {
            text = "Save current look as preset…"
            isAllCaps = false
            setOnClickListener { savePresetDialog() }
        })
        val mine = p.savedPresetNames()
        if (Looks.loaded.isNotEmpty() && p.hasPreset(Looks.loaded) && p.presetDiffers(Looks.loaded)) {
            val nm = Looks.loaded
            col.addView(Button(this).apply {
                text = "Update \"$nm\" with these changes"
                isAllCaps = false
                setOnClickListener {
                    p.savePreset(nm)
                    toast("Updated \"$nm\"")
                    recreateKeep()
                }
            })
        } else if (Looks.loaded.isNotEmpty() && !p.hasPreset(Looks.loaded)) Looks.loaded = ""
        if (mine.isNotEmpty()) {
            label("Your presets (tap to load, long-press to delete)")
            val urow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            mine.forEach { nm ->
                urow.addView(Button(this).apply {
                    text = "★ $nm"
                    isAllCaps = false
                    setOnClickListener {
                        p.loadPreset(nm)
                        Looks.loaded = nm
                        changed()
                        recreateKeep()
                    }
                    setOnLongClickListener {
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("Delete preset \"$nm\"?")
                            .setPositiveButton("Delete") { _, _ ->
                                p.deletePreset(nm)
                                if (Looks.loaded == nm) Looks.loaded = ""
                                recreateKeep()
                            }
                            .setNegativeButton("Cancel", null)
                            .show()
                        true
                    }
                })
            }
            col.addView(hscroll(urow))
        }
    }

    private fun buildVisualizer() {
        section("Visualizer")
        val es0 = (if (Nav.vizEdit < 0) p.vizStyle else Nav.vizEdit).coerceIn(0, 7)
        val es = if (es0 == 1) 0 else es0
        pv.ov["vizStyle"] = es
        choice("Style to customize", CardRenderer.PICK_NAMES, { CardRenderer.PICK.indexOf(es).coerceAtLeast(0) }) {
            Nav.vizEdit = CardRenderer.PICK[it]
            recreateKeep()
        }
        label("Each style remembers its own settings and uses them wherever it appears (panel, bubble, screen saver). Which style each one uses is chosen on the front page. The preview above shows the style you are editing.")

        section("Settings for " + CardRenderer.STYLES[es])
        choice(
            "Colors",
            listOf("Solid color", "Two-color gradient", "Album art (2 colors)", "Rainbow", "Album art (multi-color)"),
            { p.sGet(es, "colorMode") }
        ) { p.sSet(es, "colorMode", it) }
        colorRow("Color 1 (solid / gradient start)", { p.sGet(es, "color") }) { p.sSet(es, "color", it) }
        colorRow("Color 2 (gradient end)", { p.sGet(es, "color2") }) { p.sSet(es, "color2", it) }
        slider("Sensitivity", "%", 0, 100, p.sGet(es, "sens")) { p.sSet(es, "sens", it) }
        label("Higher reacts to quieter sound. Lower ignores quiet sound and only moves on louder parts.")
        if (es != 4) {
            slider("Reach", "%", 10, 100, p.sGet(es, "reach")) { p.sSet(es, "reach", it) }
            label("How much of the graphic's height the bars or wave can use.")
        }
        if (es == 0 || es == 4) slider("Bars", "", 8, 64, p.sGet(es, "bars")) { p.sSet(es, "bars", it) }
        if (es in 0..3 || es == 4) {
            slider("Fall speed", "%", 20, 300, p.sGet(es, "fall")) { p.sSet(es, "fall", it) }
            label("How quickly it drops back after a peak. Lower is smoother and slower.")
        }
        if (es in 0..3) {
            choice("Direction", listOf("Up", "Down", "Mirrored"), { p.sGet(es, "vert") }) { p.sSet(es, "vert", it) }
        }
        if (es == 0 || es == 3) {
            choice("Low end", listOf("Left", "Right", "Center", "Edges"), { p.sGet(es, "low") }) { p.sSet(es, "low", it) }
            label("Center and Edges mirror left to right.")
        }
        if (es == 4 || es == 5) slider("Depth", "dp", 10, 50, p.sGet(es, "depth")) { p.sSet(es, "depth", it) }
        if (es == 0) {
            switchRow("LED segments", { p.sGet(es, "segments") != 0 }) { p.sSet(es, "segments", if (it) 1 else 0) }
        }
        if (es == 0) switchRow("Reflection", { p.sGet(es, "reflect") != 0 }) { p.sSet(es, "reflect", if (it) 1 else 0) }
        if (es == 2 || es == 3) switchRow("Glow", { p.sGet(es, "glow") != 0 }) { p.sSet(es, "glow", if (it) 1 else 0) }
        if (es == 4 || es == 5) switchRow("Slow spin", { p.sGet(es, "spin") != 0 }) { p.sSet(es, "spin", if (it) 1 else 0) }
    }

    /** Style dropdown for one surface (0 panel, 1 bubble, 2 screen saver); stays in step with the front page. */
    private fun surfaceStyle(which: Int) {
        if (p.vizSameAll) {
            choice("Visualizer style (same for panel, bubble and screen saver)", CardRenderer.PICK_NAMES,
                { CardRenderer.PICK.indexOf(p.vizAllStyle).coerceAtLeast(0) }) { p.vizAllStyle = CardRenderer.PICK[it] }
            label("\"Same style\" is on (front page), so this changes all three.")
            return
        }
        when (which) {
            0 -> choice("Visualizer style", CardRenderer.PICK_NAMES, { CardRenderer.PICK.indexOf(p.vizStyle).coerceAtLeast(0) }) {
                p.vizStyle = CardRenderer.PICK[it]
            }
            1 -> choice("Visualizer style", CardRenderer.PICK_NAMES, { CardRenderer.PICK.indexOf(p.bubbleStyle).coerceAtLeast(0) }) {
                p.bubbleStyle = CardRenderer.PICK[it]
            }
            else -> choice(
                "Visualizer style",
                listOf("Same as the panel") + CardRenderer.PICK_NAMES,
                { if (p.saverStyle < 0) 0 else CardRenderer.PICK.indexOf(p.saverStyle).coerceAtLeast(0) + 1 }
            ) { p.saverStyle = if (it == 0) -1 else CardRenderer.PICK[it - 1] }
        }
        label("Colors, bars, sensitivity and the rest of each style are in the Visualizer menu.")
    }

    private fun buildPanel() {
        section("Panel")
        label("The panel is the card in this app, the pop-up card from the bubble, and the full-screen player.")
        surfaceStyle(0)
        buildLooks()
        buildPanelViz()
        buildArt()
        buildBackground()
    }

    private fun buildPanelViz() {
        section("Visualizer graphic")
        slider("Opacity", "%", 20, 100, p.vizOpacity) { p.vizOpacity = it }
        slider("Height (total size of the graphic)", "dp", 24, 140, p.vizHeight) { p.vizHeight = it }
        switchRow("Gentle motion while paused", { p.idleBreath }) { p.idleBreath = it }
    }

    private fun buildArt() {
        section("Album art")
        label("Global style setting: also used by the pop-up card and the full-screen player.")
        choice("Shape", listOf("Square", "Rounded", "Circle"), { p.artShape }) { p.artShape = it }
        slider("Size (compact card)", "dp", 56, 160, p.artSize) { p.artSize = it }
        choice("Position (compact card)", listOf("Left", "Right"), { p.artPos }) { p.artPos = it }
        switchRow("Soft shadow", { p.artShadow }) { p.artShadow = it }
        label("Circular spectrum and Pulse ring always use a circle.")
    }

    private fun buildBackground() {
        section("Background")
        label("Global style setting: also used by the pop-up card and the full-screen player.")
        choice(
            "Style",
            listOf("Solid color", "Tinted from album art", "Blurred album art"),
            { p.bgMode }
        ) { p.bgMode = it }
        colorRow("Solid color", { p.bgColor }) { p.bgColor = it }
        slider("Opacity", "%", 0, 100, p.bgOpacity) { p.bgOpacity = it }
        slider("Corner radius", "dp", 0, 48, p.corner) { p.corner = it }
        slider("Blur (blurred style)", "%", 0, 100, p.blurAmount) { p.blurAmount = it }
    }

    private fun buildText() {
        section("Text")
        choice("Font", CardRenderer.FONTS, { p.font }) { p.font = it }
        switchRow("Bold title", { p.titleBold }) { p.titleBold = it }
        slider("Title size", "sp", 12, 30, p.titleSize) { p.titleSize = it }
        slider("Artist size", "sp", 10, 24, p.artistSize) { p.artistSize = it }
        slider("Scroll speed for long text", "dp/s", 10, 120, p.scrollSpeed) { p.scrollSpeed = it }
        choice("Text color", listOf("White", "Black", "From album art", "Custom"), { p.textMode }) { p.textMode = it }
        colorRow("Custom text color", { p.textColor }) { p.textColor = it }
        switchRow("Show album name", { p.showAlbum }) { p.showAlbum = it }
    }

    private fun buildControls() {
        section("Controls")
        switchRow("Show play / previous / next", { p.showControls }) { p.showControls = it }
        choice("Button style", listOf("Filled play button", "Minimal"), { p.controlStyle }) { p.controlStyle = it }
        switchRow("Progress line (drag to seek)", { p.showProgress }) { p.showProgress = it }
        switchRow("EQ dropdown chip on the card", { p.showEqChip }) { p.showEqChip = it }
        switchRow("Audio capture button on the card", { p.showCapChip }) { p.showCapChip = it }
    }

    private val eqPresets = listOf(
        "Flat" to "",
        "Bass boost" to "1:90:5:0.7|0:200:1.5:1",
        "Warm" to "1:120:3:0.7|2:8000:-3:0.7",
        "Vocal" to "0:300:-2:1|0:2500:3:1|0:9000:-1:1",
        "V-shape" to "1:100:5:0.7|0:700:-3:0.8|2:8000:5:0.7",
        "Treble boost" to "2:6000:5:0.7"
    )

    private object Eq { var loaded = "" }
    private object Looks { var loaded = "" }
    private var eqUpdateBtn: Button? = null

    private fun normBands(l: List<EqEngine.Band>): String = EqEngine.encode(l.sortedBy { it.f })

    private fun eqDirty(): Boolean {
        val n = Eq.loaded
        if (n.isEmpty()) return false
        val s = eqStore.getString(n, null) ?: return false
        val parts = s.split("#")
        val storedBands = normBands(EqEngine.parse(parts.getOrElse(0) { "" }))
        val storedPost = parts.getOrNull(1)?.toIntOrNull() ?: 0
        return storedBands != normBands(eqBandsList) || storedPost != p.eqPost
    }

    private fun refreshEqUpdate() {
        val b = eqUpdateBtn ?: return
        if (eqDirty()) {
            b.text = "Update \"" + Eq.loaded + "\" with these changes"
            b.visibility = View.VISIBLE
        } else {
            b.visibility = View.GONE
        }
    }

    private val eqBandsList = ArrayList<EqEngine.Band>()
    private lateinit var eqBox: LinearLayout
    private lateinit var eqSaved: LinearLayout
    private var eqPostBar: SeekBar? = null
    private var eqPostText: TextView? = null
    private val eqStore by lazy { getSharedPreferences("np_eqpresets", MODE_PRIVATE) }

    private fun eqPush() {
        p.eqCurrent = ""
        p.eqBands = EqEngine.encode(eqBandsList)
        EqEngine.apply(p)
        refreshEqUpdate()
    }

    private fun num(s: CharSequence?): Float? = s?.toString()?.trim()?.replace(',', '.')?.toFloatOrNull()

    private fun buildEq() {
        section("Equalizer")
        label("A parametric EQ for all audio, including Bluetooth. Turn it on from the front page. It doesn't use playback capture, so the visualizer keeps working.")
        if (p.eqCurrent.isNotEmpty()) Eq.loaded = p.eqCurrent
        val status = TextView(this).apply { textSize = 12f; setPadding(0, dp(4), 0, 0) }
        refreshers.add { status.text = EqEngine.status }
        col.addView(status)
        val dbg = TextView(this).apply {
            textSize = 10f
            setTextIsSelectable(true)
            setPadding(0, dp(2), 0, 0)
        }
        refreshers.add { dbg.text = EqEngine.debug }
        col.addView(dbg)

        choice(
            "EQ method",
            listOf("Automatic", "System-wide (output mix)", "Per-app streams (most reliable)"),
            { p.eqMode }
        ) {
            p.eqMode = it
            EqService.sync(this)
            EqEngine.apply(p)
        }
        col.addView(Button(this).apply {
            text = "Per-app permission help"
            isAllCaps = false
            setOnClickListener { dumpHelpDialog() }
        })
        label("Method guide: Per-app streams works on Bluetooth but needs the one-time permission. System-wide needs nothing but doesn't work on every device.")

        eqBandsList.clear()
        eqBandsList.addAll(EqEngine.parse(p.eqBands))
        eqBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(eqBox)
        rebuildEqList()

        col.addView(Button(this).apply {
            text = "+ Add band"
            isAllCaps = false
            setOnClickListener {
                eqBandsList.add(EqEngine.Band(0, 1000f, 0f, 1.41f))
                rebuildEqList()
                eqPush()
            }
        })

        val postT = TextView(this).apply { setPadding(0, dp(12), 0, 0) }
        eqPostText = postT
        fun postLabel() {
            postT.text = "Post gain: " + String.format(java.util.Locale.US, "%+.1f dB", p.eqPost / 10f)
        }
        postLabel()
        col.addView(postT)
        val postBar = SeekBar(this).apply {
            max = 240
            progress = (p.eqPost + 120).coerceIn(0, 240)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, v: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    p.eqPost = v - 120
                    postLabel()
                    p.eqCurrent = ""
                    EqEngine.apply(p)
                    refreshEqUpdate()
                }

                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        eqPostBar = postBar
        col.addView(postBar)
        label("A limiter sits after the EQ, so boosting won't clip. Lower the post gain if boosted bands sound harsh.")

        label("Quick starts")
        val prow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        eqPresets.forEach { (name, values) ->
            prow.addView(Button(this).apply {
                text = name
                isAllCaps = false
                setOnClickListener {
                    Eq.loaded = ""
                    p.eqPost = 0
                    syncPostBar()
                    eqBandsList.clear()
                    eqBandsList.addAll(EqEngine.parse(values))
                    rebuildEqList()
                    eqPush()
                }
            })
        }
        col.addView(hscroll(prow))

        buildEqDevices()

        label("Import / save")
        col.addView(Button(this).apply {
            text = "Import EQ preset…"
            isAllCaps = false
            setOnClickListener { importDialog() }
        })
        col.addView(Button(this).apply {
            text = "Save current EQ as preset…"
            isAllCaps = false
            setOnClickListener { saveEqDialog() }
        })
        eqUpdateBtn = Button(this).apply {
            isAllCaps = false
            visibility = View.GONE
            setOnClickListener {
                val n = Eq.loaded
                if (n.isNotEmpty()) {
                    eqStore.edit().putString(n, EqEngine.encode(eqBandsList) + "#" + p.eqPost).apply()
                    p.eqCurrent = n
                    toast("Updated \"$n\"")
                    refreshEqUpdate()
                }
            }
        }
        col.addView(eqUpdateBtn)
        refreshEqUpdate()
        eqSaved = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(eqSaved)
        rebuildEqSaved()
    }

    private lateinit var devBox: LinearLayout

    private fun buildEqDevices() {
        label("Per-device presets")
        label("Load a preset automatically when you switch outputs, for example one for Bluetooth headphones and another for wired. Needs the equalizer to be on.")
        val cur = TextView(this).apply { textSize = 12f }
        refreshers.add { cur.text = "Current output: " + (EqDevices.current(this) ?: "unknown") }
        col.addView(cur)
        col.addView(Button(this).apply {
            text = "Set a preset for the current output…"
            isAllCaps = false
            setOnClickListener {
                val dev = EqDevices.current(this@MainActivity)
                if (dev == null) { toast("No output found"); return@setOnClickListener }
                val names = eqStore.all.keys.sorted()
                val items = (listOf("Flat (no EQ)") + names).toTypedArray()
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Preset for $dev")
                    .setItems(items) { _, i ->
                        EqDevices.assign(this@MainActivity, dev, if (i == 0) EqDevices.FLAT else names[i - 1])
                        if (p.eqCurrent.isNotEmpty()) Eq.loaded = p.eqCurrent
                        eqBandsList.clear()
                        eqBandsList.addAll(EqEngine.parse(p.eqBands))
                        rebuildEqList()
                        syncPostBar()
                        refreshEqUpdate()
                        rebuildDevList()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        })
        devBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(devBox)
        rebuildDevList()
    }

    private fun rebuildDevList() {
        devBox.removeAllViews()
        val m = EqDevices.assignments(this)
        if (m.isEmpty()) return
        devBox.addView(TextView(this).apply {
            text = "Assigned (tap to remove)"
            textSize = 13f
            setPadding(0, dp(6), 0, 0)
        })
        m.toSortedMap().forEach { (dev, pr) ->
            devBox.addView(Button(this).apply {
                text = dev + "  →  " + (if (pr == EqDevices.FLAT) "Flat (no EQ)" else pr)
                isAllCaps = false
                setOnClickListener {
                    EqDevices.assign(this@MainActivity, dev, null)
                    rebuildDevList()
                }
            })
        }
    }

    private fun rebuildEqSaved() {
        eqSaved.removeAllViews()
        val names = eqStore.all.keys.sorted()
        if (names.isEmpty()) return
        eqSaved.addView(TextView(this).apply {
            text = "Your EQ presets (tap to load, long-press to delete)"
            textSize = 13f
            setPadding(0, dp(10), 0, dp(2))
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        names.forEach { nm ->
            row.addView(Button(this).apply {
                text = "★ $nm"
                isAllCaps = false
                setOnClickListener {
                    val s = eqStore.getString(nm, "") ?: ""
                    val parts = s.split("#")
                    eqBandsList.clear()
                    eqBandsList.addAll(EqEngine.parse(parts.getOrElse(0) { "" }))
                    p.eqPost = parts.getOrNull(1)?.toIntOrNull() ?: 0
                    Eq.loaded = nm
                    rebuildEqList()
                    syncPostBar()
                    eqPush()
                    p.eqCurrent = nm
                    refreshEqUpdate()
                }
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Delete EQ preset \"$nm\"?")
                        .setPositiveButton("Delete") { _, _ ->
                            eqStore.edit().remove(nm).apply()
                            rebuildEqSaved()
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                    true
                }
            })
        }
        eqSaved.addView(hscroll(row))
    }

    private fun syncPostBar() {
        eqPostBar?.progress = (p.eqPost + 120).coerceIn(0, 240)
        eqPostText?.text = "Post gain: " + String.format(java.util.Locale.US, "%+.1f dB", p.eqPost / 10f)
    }

    private fun saveEqDialog() {
        val et = EditText(this).apply { hint = "Preset name"; setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("Save EQ preset")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isEmpty()) {
                    toast("Give it a name")
                } else {
                    eqStore.edit().putString(n, EqEngine.encode(eqBandsList) + "#" + p.eqPost).apply()
                    p.eqCurrent = n
                    Eq.loaded = n
                    refreshEqUpdate()
                    toast("Saved \"$n\"")
                    rebuildEqSaved()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private var importBox: EditText? = null

    private fun importDialog() {
        val et = EditText(this).apply {
            hint = "Paste preset text here (Equalizer APO lines, \"freq gain Q\" lines, or Ozone XML)"
            minLines = 6
            gravity = Gravity.TOP
            textSize = 12f
        }
        importBox = et
        AlertDialog.Builder(this)
            .setTitle("Import EQ preset")
            .setView(et)
            .setPositiveButton("Import") { _, _ -> doImport(et.text.toString()) }
            .setNeutralButton("Choose file…") { _, _ ->
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                @Suppress("DEPRECATION")
                startActivityForResult(i, 78)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun doImport(text: String) {
        val r = EqImport.parse(text)
        if (r == null || r.bands.isEmpty()) {
            toast("Couldn't find any EQ bands in that. Send me the file and I'll add its format.")
            return
        }
        Eq.loaded = ""
        eqBandsList.clear()
        eqBandsList.addAll(r.bands.take(32))
        p.eqPost = ((r.preampDb ?: 0f) * 10f).toInt().coerceIn(-120, 120)
        rebuildEqList()
        syncPostBar()
        eqPush()
        toast("Imported ${eqBandsList.size} band(s)")
    }

    private fun rebuildEqList() {
        eqBox.removeAllViews()
        eqBandsList.sortBy { it.f }
        eqBandsList.forEachIndexed { idx, b ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(10), 0, dp(4))
            }
            val top = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val typeSp = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, EqEngine.TYPES)
                setSelection(b.type, false)
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                        if (pos != b.type) {
                            b.type = pos
                            eqPush()
                        }
                    }

                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }
            top.addView(TextView(this).apply { text = "Band ${idx + 1}  " })
            top.addView(typeSp, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            top.addView(Button(this).apply {
                text = "✕"
                setOnClickListener {
                    eqBandsList.remove(b)
                    rebuildEqList()
                    eqPush()
                }
            })
            card.addView(top)

            val fields = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun field(hint: String, init: String, onNum: (Float) -> Unit): EditText {
                val e = EditText(this).apply {
                    this.hint = hint
                    setText(init)
                    setSingleLine()
                    inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                        android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or
                        android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
                    textSize = 14f
                }
                e.addTextChangedListener(object : android.text.TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b2: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b2: Int, c: Int) {}
                    override fun afterTextChanged(s: android.text.Editable?) {
                        val x = num(s) ?: return
                        onNum(x)
                    }
                })
                fields.addView(e, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                return e
            }
            var gainBar: SeekBar? = null
            var gainEdit: EditText? = null
            var guard = false
            field("Hz", fmtNum(b.f)) { b.f = it.coerceIn(10f, 22000f); eqPush() }
            gainEdit = field("dB", fmtNum(b.g)) {
                b.g = it.coerceIn(-15f, 15f)
                if (!guard) {
                    guard = true
                    gainBar?.progress = ((b.g + 15f) * 10f).toInt().coerceIn(0, 300)
                    guard = false
                }
                eqPush()
            }
            field("Q", fmtNum(b.q)) { b.q = it.coerceIn(0.1f, 20f); eqPush() }
            card.addView(fields)
            card.addView(TextView(this).apply { text = "Frequency (Hz)      Gain (dB)      Q"; textSize = 11f })

            gainBar = SeekBar(this).apply {
                max = 300
                progress = ((b.g + 15f) * 10f).toInt().coerceIn(0, 300)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, v: Int, fromUser: Boolean) {
                        if (!fromUser || guard) return
                        guard = true
                        b.g = v / 10f - 15f
                        gainEdit?.setText(fmtNum(b.g))
                        guard = false
                        eqPush()
                    }

                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) {}
                })
            }
            card.addView(gainBar)
            eqBox.addView(card)
        }
        if (eqBandsList.isEmpty()) {
            eqBox.addView(TextView(this).apply {
                text = "No bands: the EQ is flat. Add a band, pick a quick start, or import a preset."
                textSize = 12f
                setPadding(0, dp(8), 0, dp(4))
            })
        }
    }

    private fun fmtNum(x: Float): String =
        if (x == Math.rint(x.toDouble()).toFloat()) x.toInt().toString() else String.format(java.util.Locale.US, "%.2f", x)

    private fun buildBubble() {
        section("Floating Bubble")
        label(
            "A small bubble with mini album art and the visualizer, floating over other apps while music plays. " +
                "Tap it for the card, drag it to move it, long-press to open this app."
        )
        label("Turn the bubble on or off from the front page.")
        switchRow("Hide it while the music app is open", { p.bubbleHideInApp }) { p.bubbleHideInApp = it }
        permRow(
            "Usage access (for hiding in the music app)",
            "Lets the bubble know which app is on screen. Find Now Playing Card in the list and allow it.",
            { OverlayService.hasUsageAccess(this) }
        ) { Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS) }
        switchRow("Keep it visible while paused", { p.bubbleKeepPaused }) { p.bubbleKeepPaused = it }
        switchRow("Tap = play / pause, hold = open panel", { p.bubbleTapPlay }) { p.bubbleTapPlay = it }
        label("Off: tap opens the panel and hold opens this app.")
        switchRow("Haptic feedback on tap and hold", { p.bubbleHaptic }) { p.bubbleHaptic = it }
        slider("Hide after being paused for (0 = never)", "min", 0, 60, p.bubbleHideMin) { p.bubbleHideMin = it }
        label("It always disappears once the music app is fully closed (if the app ends its media session).")
        surfaceStyle(1)
        choice("Bubble shape", listOf("Circle", "Rounded square", "Square"), { p.bubbleShape }) { p.bubbleShape = it }
        slider("Bubble size", "dp", 36, 100, p.bubbleSize) { p.bubbleSize = it }
        slider("Visualizer bars", "", 8, 48, p.bubbleBars) { p.bubbleBars = it }
        slider("Visualizer height", "%", 30, 100, p.bubbleVizHeight) { p.bubbleVizHeight = it }
        slider("Bubble opacity (all parts)", "%", 30, 100, p.bubbleOpacity) { p.bubbleOpacity = it }
        slider("Visualizer opacity", "%", 0, 100, p.bubbleVizOp) { p.bubbleVizOp = it }
        slider("Album art opacity", "%", 0, 100, p.bubbleArtOp) { p.bubbleArtOp = it }
        slider("Border opacity", "%", 0, 100, p.bubbleBorderOp) { p.bubbleBorderOp = it }
        switchRow("Fling sideways to tuck it into the screen edge", { p.bubbleTuck }) { p.bubbleTuck = it }
        switchRow("Allow minimizing to a small dot", { p.bubbleDot }) { p.bubbleDot = it }
        label("To minimize: drag the bubble onto the round target that appears at the bottom of the screen, or tap the – button on the pop-up card. Tap a tucked or minimized bubble to bring it back.")
        switchRow("Snap to the screen edge", { p.bubbleSnap }) { p.bubbleSnap = it }
        slider("Pop-up card width", "dp", 260, 400, p.popupWidth) { p.popupWidth = it }
        slider("Close the card after (0 = stay open)", "sec", 0, 30, p.popupClose) { p.popupClose = it }
        label("Colors, sensitivity and the rest come from the Visualizer menu, for the style chosen above. The pop-up card uses your full panel look.")
    }

    // -------------------------------------------------------------------- helpers

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private val overlayRestart = Runnable { applyOverlay() }

    /** Called after any setting changes. */
    private fun changed() {
        card.reload()
        saverPreview?.invalidate()
        if (Nav.page == "bubble") rebuildBubblePreview()
        if (p.bubbleOn) {
            handler.removeCallbacks(overlayRestart)
            handler.postDelayed(overlayRestart, 700)
        }
    }

    private fun applyOverlay() {
        if (p.bubbleOn && Settings.canDrawOverlays(this)) {
            try {
                startForegroundService(Intent(this, OverlayService::class.java))
            } catch (e: Exception) {
                toast("Couldn't start the bubble")
            }
        } else {
            stopService(Intent(this, OverlayService::class.java))
        }
    }

    private fun listenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(packageName)
    }

    private fun savePresetDialog() {
        val et = EditText(this).apply { hint = "Preset name"; setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("Save current look")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isEmpty()) {
                    toast("Give it a name")
                } else {
                    p.savePreset(n)
                    Looks.loaded = n
                    toast("Saved \"$n\"")
                    recreateKeep()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun section(t: String) {
        if (skipSection) { skipSection = false; return }
        col.addView(TextView(this).apply {
            text = t
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(28), 0, dp(6))
        })
    }

    private fun label(t: String) {
        col.addView(TextView(this).apply {
            text = t
            textSize = 13f
            setPadding(0, dp(10), 0, dp(2))
        })
    }

    private fun permRow(title: String, desc: String, ok: () -> Boolean, intent: () -> Intent) {
        val t = TextView(this).apply { setPadding(0, dp(8), 0, 0) }
        val b = Button(this).apply {
            text = "Open settings"
            isAllCaps = false
            setOnClickListener {
                try {
                    startActivity(intent())
                } catch (e: Exception) {
                    toast("Could not open that settings page")
                }
            }
        }
        refreshers.add {
            val g = ok()
            t.text = (if (g) "✅ " else "❌ ") + title + "\n" + desc
            b.visibility = if (g) View.GONE else View.VISIBLE
        }
        col.addView(t)
        col.addView(b)
        t.text = title + "\n" + desc
    }

    private fun switchRow(name: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        col.addView(Switch(this).apply {
            text = name
            isChecked = get()
            setPadding(0, dp(8), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                set(on)
                changed()
            }
        })
    }

    private fun choice(name: String, opts: List<String>, get: () -> Int, set: (Int) -> Unit) {
        label(name)
        col.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, opts)
            setSelection(get())
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    if (pos != get()) {
                        set(pos)
                        changed()
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        })
    }

    private fun slider(name: String, unit: String, min: Int, max: Int, init: Int, onSet: (Int) -> Unit) {
        val t = TextView(this).apply {
            text = "$name: $init $unit"
            setPadding(0, dp(12), 0, 0)
        }
        val s = SeekBar(this).apply {
            this.max = max - min
            progress = (init - min).coerceIn(0, max - min)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, v: Int, fromUser: Boolean) {
                    val x = v + min
                    t.text = "$name: $x $unit"
                    if (fromUser) {
                        onSet(x)
                        changed()
                    }
                }

                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        col.addView(t)
        col.addView(s)
    }

    private fun colorRow(name: String, get: () -> Int, set: (Int) -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        val sw = View(this)
        fun paintSwatch() {
            sw.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(get())
                setStroke(dp(2), 0xFF888888.toInt())
            }
        }
        paintSwatch()
        val openPicker = View.OnClickListener {
            pickColor(get()) { picked ->
                set(picked)
                paintSwatch()
                changed()
            }
        }
        sw.setOnClickListener(openPicker)
        row.setOnClickListener(openPicker)
        row.addView(
            TextView(this).apply { text = name },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        row.addView(sw, LinearLayout.LayoutParams(dp(40), dp(40)))
        col.addView(row)
    }

    private fun pickColor(initial: Int, onPick: (Int) -> Unit) {
        val hsv = FloatArray(3)
        Color.colorToHSV(initial, hsv)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
        }
        val preview = View(this).apply { setBackgroundColor(Color.HSVToColor(hsv)) }
        box.addView(preview, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)))

        fun bar(name: String, maxV: Int, initV: Int, setter: (Int) -> Unit) {
            box.addView(TextView(this).apply {
                text = name
                setPadding(0, dp(8), 0, 0)
            })
            box.addView(SeekBar(this).apply {
                this.max = maxV
                progress = initV
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, v: Int, fromUser: Boolean) {
                        setter(v)
                        preview.setBackgroundColor(Color.HSVToColor(hsv))
                    }

                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) {}
                })
            })
        }
        bar("Hue", 360, hsv[0].toInt()) { hsv[0] = it.toFloat() }
        bar("Saturation", 100, (hsv[1] * 100).toInt()) { hsv[1] = it / 100f }
        bar("Brightness", 100, (hsv[2] * 100).toInt()) { hsv[2] = it / 100f }

        AlertDialog.Builder(this)
            .setTitle("Pick a color")
            .setView(box)
            .setPositiveButton("OK") { _, _ -> onPick(Color.HSVToColor(hsv)) }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
