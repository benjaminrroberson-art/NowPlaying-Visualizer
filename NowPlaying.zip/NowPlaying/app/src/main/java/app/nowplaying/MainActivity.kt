package app.nowplaying

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var p: Prefs
    private lateinit var col: LinearLayout
    private lateinit var card: CardView
    private var density = 1f
    private val handler = Handler(Looper.getMainLooper())
    private val refreshers = ArrayList<() -> Unit>()
    private var active = false

    private fun dp(i: Int) = (i * density).toInt()

    private object Nav { var page = "home"; var homeY = 0 }
    private var skipSection = false


    private fun go(pg: String) {
        if (Nav.page == "home") Nav.homeY = vScroll?.scrollY ?: 0
        Nav.page = pg
        if (pg == "home") {
            Keep.y = Nav.homeY
            Keep.xs = ArrayList()
            Keep.on = true
        } else {
            Keep.on = false
        }
        recreate()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (Nav.page != "home") go("home") else super.onBackPressed()
    }

    // keep scroll positions across recreateKeep() so lists don't snap back
    private var vScroll: ScrollView? = null
    private val hScrolls = ArrayList<HorizontalScrollView>()
    private object Keep { var y = 0; var xs = ArrayList<Int>(); var on = false }

    private fun hscroll(inner: View): HorizontalScrollView {
        val h = HorizontalScrollView(this).apply { addView(inner) }
        hScrolls.add(h)
        return h
    }

    private fun recreateKeep() {
        Keep.y = vScroll?.scrollY ?: 0
        Keep.xs = ArrayList(hScrolls.map { it.scrollX })
        Keep.on = true
        recreate()
    }

    private fun restoreScroll() {
        if (!Keep.on) return
        Keep.on = false
        val y = Keep.y
        val xs = Keep.xs
        vScroll?.post {
            vScroll?.scrollTo(0, y)
            hScrolls.forEachIndexed { i, h -> if (i < xs.size) h.scrollTo(xs[i], 0) }
        }
    }

    // Built-in looks. Keys match Prefs.lookKeys; anything not listed is reset to its default.
    private val builtIn: List<Pair<String, Map<String, Any>>> = listOf(
        "Minimal" to mapOf("vizStyle" to 0, "bgMode" to 0, "bgColor" to 0xFF111214.toInt(), "bgOpacity" to 94, "vizBars" to 28),
        "Glass" to mapOf("vizStyle" to 7, "bgMode" to 2, "bgOpacity" to 82, "corner" to 32),
        "Neon ring" to mapOf("vizStyle" to 4, "vizColorMode" to 3, "bgMode" to 0, "bgColor" to 0xFF0B0B10.toInt(), "vizBars" to 48, "bgOpacity" to 95),
        "Pulse" to mapOf("vizStyle" to 5, "bgMode" to 2),
        "Scope" to mapOf(
            "vizStyle" to 2, "vizColorMode" to 1, "bgMode" to 0, "bgColor" to 0xFF08090C.toInt(),
            "font" to 5, "titleBold" to false, "bgOpacity" to 95
        ),
        "Skyline" to mapOf(
            "vizStyle" to 3, "vizColorMode" to 1, "vizColor" to 0xFFFF9100.toInt(), "vizColor2" to 0xFFFF4081.toInt(), "bgMode" to 1
        ),
        "Particles" to mapOf("vizStyle" to 6, "bgMode" to 2),
        "LED" to mapOf(
            "vizStyle" to 0, "vizSegments" to true, "vizColorMode" to 1, "vizColor" to 0xFF76FF03.toInt(),
            "vizColor2" to 0xFFFF1744.toInt(), "bgMode" to 0, "bgColor" to 0xFF000000.toInt(), "font" to 2,
            "vizHeight" to 64, "vizBars" to 24, "bgOpacity" to 96
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs(this)
        density = resources.displayMetrics.density
        EqEngine.ctx = applicationContext
        MediaState.ensureStarted(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setOnApplyWindowInsetsListener { v, ins ->
                val i = ins.getInsets(WindowInsets.Type.systemBars())
                v.setPadding(i.left, i.top, i.right, i.bottom)
                ins
            }
        }
        card = CardView(this, p)
        card.onTap = { startActivity(Intent(this, PlayerActivity::class.java)) }
        root.addView(
            card,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(dp(14), dp(10), dp(14), dp(6)) }
        )

        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), dp(32))
        }
        root.addView(
            ScrollView(this).apply { addView(col) }.also { vScroll = it },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT) {
                if (Nav.page != "home") go("home") else finish()
            }
        }
        if (Nav.page == "home") {
            buildHome()
        } else {
            val title = PAGES.firstOrNull { it.first == Nav.page }?.second ?: "Settings"
            subHeader(title)
            skipSection = true
            when (Nav.page) {
                "looks" -> buildLooks()
                "viz" -> buildVisualizer()
                "art" -> buildArt()
                "bg" -> buildBackground()
                "text" -> buildText()
                "controls" -> buildControls()
                "eq" -> buildEq()
                "bubble" -> buildBubble()
                "capture" -> buildCapture()
                else -> buildLooks()
            }
        }
        restoreScroll()
        OverlayService.ensure(this)
        if (p.eqOn) EqService.sync(this)
    }

    override fun onResume() {
        super.onResume()
        active = true
        MediaState.retry()
        Audio.retry(this)
        card.reload()
        refreshers.forEach { it() }
        handler.post(ticker)
    }

    override fun onPause() {
        active = false
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!active) return
            refreshers.forEach { it() }
            handler.postDelayed(this, 1000)
        }
    }

    private val handler0 = android.os.Handler(android.os.Looper.getMainLooper())

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 78 && resultCode == RESULT_OK && data?.data != null) {
            try {
                val txt = contentResolver.openInputStream(data.data!!)?.use { ins ->
                    String(ins.readBytes().take(400_000).toByteArray())
                } ?: ""
                importBox?.setText(txt)
                doImport(txt)
            } catch (e: Exception) {
                toast("Couldn't read that file")
            }
        }
        if (requestCode == 77) {
            if (resultCode == RESULT_OK && data != null) {
                CaptureService.start(this, resultCode, data)
                handler0.postDelayed({ refreshers.forEach { it() } }, 1000)
            } else {
                toast("Capture permission was declined")
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Audio.retry(this)
        refreshers.forEach { it() }
    }

    // -------------------------------------------------------------------- sections

    private val PAGES = listOf(
        Triple("looks", "Looks & presets", "Ready-made styles and your saved looks"),
        Triple("viz", "Visualizer", "Style, colors, bars, sensitivity"),
        Triple("art", "Album art", "Size, shape, effects"),
        Triple("bg", "Background", "Card background and blur"),
        Triple("text", "Text", "Title, artist and album text"),
        Triple("controls", "Controls", "Buttons, progress bar, icons"),
        Triple("eq", "Equalizer", "Bands, presets, import, method"),
        Triple("bubble", "Floating bubble", "Behavior, size, shape, pop-up"),
        Triple("capture", "Audio capture", "Only if the visualizer stays flat")
    ).map { Pair(it.first, it.second) }
    private val PAGE_SUB = mapOf(
        "looks" to "Ready-made styles and your saved looks",
        "viz" to "Style, colors, bars, sensitivity",
        "art" to "Size, shape, effects",
        "bg" to "Card background and blur",
        "text" to "Title, artist and album text",
        "controls" to "Buttons, progress bar, icons",
        "eq" to "Bands, presets, import, method",
        "bubble" to "Behavior, size, shape, pop-up",
        "capture" to "Only needed if the visualizer stays flat"
    )

    private fun subHeader(title: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, 0)
        }
        row.addView(Button(this).apply {
            text = "‹ Back"
            isAllCaps = false
            setOnClickListener { go("home") }
        })
        row.addView(TextView(this).apply {
            text = title
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(12), 0, 0, 0)
        })
        col.addView(row)
    }

    private fun menuRow(pg: String, title: String) {
        col.addView(Button(this).apply {
            text = title + "  ›\n" + (PAGE_SUB[pg] ?: "")
            isAllCaps = false
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            setOnClickListener { go(pg) }
        })
    }

    private fun buildHome() {
        section("Setup")
        label("Do these once. Notification access is the only one you must have. The rest unlock extra features.")
        permRow(
            "Notification access (required)",
            "Lets the app see what is playing and control it. No notifications are read.",
            { listenerEnabled() }
        ) { Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }
        val audioRow = TextView(this).apply { setPadding(0, dp(8), 0, 0) }
        val audioBtn = Button(this).apply {
            text = "Grant audio permission"
            isAllCaps = false
            setOnClickListener { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2) }
        }
        refreshers.add {
            val ok = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            audioRow.text = (if (ok) "✅ " else "❌ ") + "Audio permission (for the visualizer)\n" +
                "Android calls this the microphone permission. The music is only analysed live, never recorded."
            audioBtn.visibility = if (ok) View.GONE else View.VISIBLE
        }
        col.addView(audioRow)
        col.addView(audioBtn)
        permRow(
            "Display over other apps (for the bubble)",
            "Lets the floating bubble appear on top of other apps.",
            { Settings.canDrawOverlays(this) }
        ) { Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")) }

        val eqPerm = TextView(this).apply { setPadding(0, dp(8), 0, 0) }
        val eqPermBtn = Button(this).apply {
            text = "How to enable"
            isAllCaps = false
            setOnClickListener { dumpHelpDialog() }
        }
        refreshers.add {
            val ok = EqEngine.hasDump()
            eqPerm.text = (if (ok) "✅ " else "⚪ ") + "Equalizer permission (only for the EQ)\n" +
                "Lets the EQ find which apps are playing so it can work on Bluetooth. A one-time step done from a computer."
            eqPermBtn.visibility = if (ok) View.GONE else View.VISIBLE
        }
        col.addView(eqPerm)
        col.addView(eqPermBtn)

        col.addView(Switch(this).apply {
            text = "Demo mode (fake music, to try looks)"
            isChecked = MediaState.demo
            setPadding(0, dp(12), 0, dp(4))
            setOnCheckedChangeListener { _, on -> MediaState.setDemo(on) }
        })
        val status = TextView(this).apply { textSize = 12f; setPadding(0, dp(6), 0, 0) }
        refreshers.add {
            status.text = MediaState.status + "\n" + Audio.status + "\n" + OverlayService.status
        }
        col.addView(status)

        section("Main switches")
        bubbleSwitch()
        switchRowPlain("Equalizer on", { p.eqOn }) {
            p.eqOn = it
            EqService.sync(this)
            EqEngine.apply(p)
        }
        val eqStatus = TextView(this).apply { textSize = 12f }
        refreshers.add { eqStatus.text = if (p.eqOn) EqEngine.status else "" }
        col.addView(eqStatus)
        col.addView(Button(this).apply {
            text = "Open full-screen player"
            isAllCaps = false
            setOnClickListener { startActivity(Intent(this@MainActivity, PlayerActivity::class.java)) }
        })

        section("Customize")
        PAGES.forEach { menuRow(it.first, it.second) }
    }

    private fun dumpHelpDialog() {
        val cmd = "pm grant app.nowplaying android.permission.DUMP"
        AlertDialog.Builder(this)
            .setTitle("Equalizer permission")
            .setMessage(
                "Why: the EQ attaches to each app that is playing sound. Android only lets an app see which apps are playing " +
                    "if it holds the DUMP permission, and that can't be granted from a normal settings screen. You do it once.\n\n" +
                    "1. Turn on Developer options (Settings > About phone, tap Build number 7 times), then turn on USB debugging.\n" +
                    "2. On a computer, open app.webadb.com in Chrome, plug in the phone, tap Connect and allow it on the phone.\n" +
                    "3. Open its shell and run:\n$cmd\n\n" +
                    "Without it the EQ falls back to the system-wide method, which doesn't work on some Bluetooth devices."
            )
            .setPositiveButton("Copy command") { _, _ ->
                val cm = getSystemService(android.content.ClipboardManager::class.java)
                cm.setPrimaryClip(android.content.ClipData.newPlainText("cmd", cmd))
                toast("Copied")
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun buildCapture() {
        label(
            "What it does: normally the visualizer listens to the phone's audio output. On some setups, mostly Bluetooth " +
                "headphones, that gives it silence and the visualizer stays flat. Playback capture reads what the music app " +
                "plays instead."
        )
        label(
            "When to use it: only if the visualizer doesn't move while music plays. It is not needed for the equalizer, " +
                "and not needed for the bubble to appear."
        )
        label(
            "Good to know: Android shows a screen-sharing prompt each time you start it (pick \"entire screen\"; " +
                "nothing is recorded). Some apps block capture. Only one app on the phone can capture at a time, so it " +
                "won't work while another audio-effects app holds that slot."
        )
        val capBtn = Button(this).apply {
            isAllCaps = false
            setOnClickListener {
                if (CaptureService.running) {
                    CaptureService.stop(this@MainActivity)
                } else {
                    startActivity(Intent(this@MainActivity, CaptureActivity::class.java))
                }
                handler0.postDelayed({ refreshers.forEach { it() } }, 800)
            }
        }
        refreshers.add {
            capBtn.text = if (CaptureService.running) "Stop playback capture" else "Start playback capture"
        }
        col.addView(capBtn)
        val status = TextView(this).apply { textSize = 12f; setPadding(0, dp(6), 0, 0) }
        refreshers.add { status.text = Audio.status }
        col.addView(status)
    }

    private fun bubbleSwitch() {
        col.addView(Switch(this).apply {
            text = "Show the floating bubble"
            isChecked = p.bubbleOn
            setPadding(0, dp(8), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                p.bubbleOn = on
                if (on && Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
                }
                if (on && !Settings.canDrawOverlays(this@MainActivity)) {
                    toast("Allow \"Display over other apps\" first")
                }
                applyOverlay()
            }
        })
    }

    private fun switchRowPlain(name: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        col.addView(Switch(this).apply {
            text = name
            isChecked = get()
            setPadding(0, dp(8), 0, dp(4))
            setOnCheckedChangeListener { _, on -> set(on) }
        })
    }

    private fun buildLooks() {
        section("Looks")
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        builtIn.forEach { (name, map) ->
            row.addView(Button(this).apply {
                text = name
                isAllCaps = false
                setOnClickListener {
                    p.apply(map)
                    changed()
                    recreateKeep()
                }
            })
        }
        col.addView(hscroll(row))
        col.addView(Button(this).apply {
            text = "Save current look as preset…"
            isAllCaps = false
            setOnClickListener { savePresetDialog() }
        })
        val mine = p.savedPresetNames()
        if (mine.isNotEmpty()) {
            label("Your presets (tap to load, long-press to delete)")
            val urow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            mine.forEach { nm ->
                urow.addView(Button(this).apply {
                    text = "★ $nm"
                    isAllCaps = false
                    setOnClickListener {
                        p.loadPreset(nm)
                        changed()
                        recreateKeep()
                    }
                    setOnLongClickListener {
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("Delete preset \"$nm\"?")
                            .setPositiveButton("Delete") { _, _ ->
                                p.deletePreset(nm)
                                recreateKeep()
                            }
                            .setNegativeButton("Cancel", null)
                            .show()
                        true
                    }
                })
            }
            col.addView(hscroll(urow))
        }
    }

    private fun buildVisualizer() {
        section("Visualizer")
        choice("Style", CardRenderer.STYLES, { p.vizStyle }) { p.vizStyle = it }
        choice(
            "Colors",
            listOf("Solid color", "Two-color gradient", "Album art (2 colors)", "Rainbow", "Album art (multi-color)"),
            { p.vizColorMode }
        ) { p.vizColorMode = it }
        colorRow("Color 1 (solid / gradient start)", { p.vizColor }) { p.vizColor = it }
        colorRow("Color 2 (gradient end)", { p.vizColor2 }) { p.vizColor2 = it }
        slider("Bars", "", 8, 64, p.vizBars) { p.vizBars = it }
        slider("Sensitivity", "%", 30, 250, p.vizSens) { p.vizSens = it }
        slider("Opacity", "%", 20, 100, p.vizOpacity) { p.vizOpacity = it }
        slider("Height (bars, wave styles)", "dp", 24, 140, p.vizHeight) { p.vizHeight = it }
        slider("Reach (circular and pulse ring)", "dp", 10, 50, p.vizDepth) { p.vizDepth = it }
        switchRow("LED segments (bars)", { p.vizSegments }) { p.vizSegments = it }
        switchRow("Reflection (bars)", { p.vizReflect }) { p.vizReflect = it }
        switchRow("Glow (lines and waves)", { p.vizGlow }) { p.vizGlow = it }
        switchRow("Slow spin (circular)", { p.vizSpin }) { p.vizSpin = it }
        switchRow("Gentle motion while paused", { p.idleBreath }) { p.idleBreath = it }
    }

    private fun buildArt() {
        section("Album art")
        choice("Shape", listOf("Square", "Rounded", "Circle"), { p.artShape }) { p.artShape = it }
        slider("Size (compact card)", "dp", 56, 160, p.artSize) { p.artSize = it }
        choice("Position (compact card)", listOf("Left", "Right"), { p.artPos }) { p.artPos = it }
        switchRow("Soft shadow", { p.artShadow }) { p.artShadow = it }
        label("Circular spectrum and Pulse ring always use a circle.")
    }

    private fun buildBackground() {
        section("Background")
        choice(
            "Style",
            listOf("Solid color", "Tinted from album art", "Blurred album art"),
            { p.bgMode }
        ) { p.bgMode = it }
        colorRow("Solid color", { p.bgColor }) { p.bgColor = it }
        slider("Opacity", "%", 0, 100, p.bgOpacity) { p.bgOpacity = it }
        slider("Corner radius", "dp", 0, 48, p.corner) { p.corner = it }
        slider("Blur (blurred style)", "%", 0, 100, p.blurAmount) { p.blurAmount = it }
    }

    private fun buildText() {
        section("Text")
        choice("Font", CardRenderer.FONTS, { p.font }) { p.font = it }
        switchRow("Bold title", { p.titleBold }) { p.titleBold = it }
        slider("Title size", "sp", 12, 30, p.titleSize) { p.titleSize = it }
        slider("Artist size", "sp", 10, 24, p.artistSize) { p.artistSize = it }
        slider("Scroll speed for long text", "dp/s", 10, 120, p.scrollSpeed) { p.scrollSpeed = it }
        choice("Text color", listOf("White", "Black", "From album art", "Custom"), { p.textMode }) { p.textMode = it }
        colorRow("Custom text color", { p.textColor }) { p.textColor = it }
        switchRow("Show album name", { p.showAlbum }) { p.showAlbum = it }
    }

    private fun buildControls() {
        section("Controls")
        switchRow("Show play / previous / next", { p.showControls }) { p.showControls = it }
        choice("Button style", listOf("Filled play button", "Minimal"), { p.controlStyle }) { p.controlStyle = it }
        switchRow("Progress line (drag to seek)", { p.showProgress }) { p.showProgress = it }
        switchRow("EQ dropdown chip on the card", { p.showEqChip }) { p.showEqChip = it }
        switchRow("Audio capture button on the card", { p.showCapChip }) { p.showCapChip = it }
    }

    private val eqPresets = listOf(
        "Flat" to "",
        "Bass boost" to "1:90:5:0.7|0:200:1.5:1",
        "Warm" to "1:120:3:0.7|2:8000:-3:0.7",
        "Vocal" to "0:300:-2:1|0:2500:3:1|0:9000:-1:1",
        "V-shape" to "1:100:5:0.7|0:700:-3:0.8|2:8000:5:0.7",
        "Treble boost" to "2:6000:5:0.7"
    )

    private object Eq { var loaded = "" }
    private var eqUpdateBtn: Button? = null

    private fun normBands(l: List<EqEngine.Band>): String = EqEngine.encode(l.sortedBy { it.f })

    private fun eqDirty(): Boolean {
        val n = Eq.loaded
        if (n.isEmpty()) return false
        val s = eqStore.getString(n, null) ?: return false
        val parts = s.split("#")
        val storedBands = normBands(EqEngine.parse(parts.getOrElse(0) { "" }))
        val storedPost = parts.getOrNull(1)?.toIntOrNull() ?: 0
        return storedBands != normBands(eqBandsList) || storedPost != p.eqPost
    }

    private fun refreshEqUpdate() {
        val b = eqUpdateBtn ?: return
        if (eqDirty()) {
            b.text = "Update \"" + Eq.loaded + "\" with these changes"
            b.visibility = View.VISIBLE
        } else {
            b.visibility = View.GONE
        }
    }

    private val eqBandsList = ArrayList<EqEngine.Band>()
    private lateinit var eqBox: LinearLayout
    private lateinit var eqSaved: LinearLayout
    private var eqPostBar: SeekBar? = null
    private var eqPostText: TextView? = null
    private val eqStore by lazy { getSharedPreferences("np_eqpresets", MODE_PRIVATE) }

    private fun eqPush() {
        p.eqCurrent = ""
        p.eqBands = EqEngine.encode(eqBandsList)
        EqEngine.apply(p)
        refreshEqUpdate()
    }

    private fun num(s: CharSequence?): Float? = s?.toString()?.trim()?.replace(',', '.')?.toFloatOrNull()

    private fun buildEq() {
        section("Equalizer")
        label("A parametric EQ for all audio, including Bluetooth. Turn it on from the front page. It doesn't use playback capture, so the visualizer keeps working.")
        if (p.eqCurrent.isNotEmpty()) Eq.loaded = p.eqCurrent
        val status = TextView(this).apply { textSize = 12f; setPadding(0, dp(4), 0, 0) }
        refreshers.add { status.text = EqEngine.status }
        col.addView(status)
        val dbg = TextView(this).apply {
            textSize = 10f
            setTextIsSelectable(true)
            setPadding(0, dp(2), 0, 0)
        }
        refreshers.add { dbg.text = EqEngine.debug }
        col.addView(dbg)

        choice(
            "EQ method",
            listOf("Automatic", "System-wide (output mix)", "Per-app streams (most reliable)"),
            { p.eqMode }
        ) {
            p.eqMode = it
            EqService.sync(this)
            EqEngine.apply(p)
        }
        col.addView(Button(this).apply {
            text = "Per-app permission help"
            isAllCaps = false
            setOnClickListener { dumpHelpDialog() }
        })
        label("Method guide: Per-app streams works on Bluetooth but needs the one-time permission. System-wide needs nothing but doesn't work on every device.")

        eqBandsList.clear()
        eqBandsList.addAll(EqEngine.parse(p.eqBands))
        eqBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(eqBox)
        rebuildEqList()

        col.addView(Button(this).apply {
            text = "+ Add band"
            isAllCaps = false
            setOnClickListener {
                eqBandsList.add(EqEngine.Band(0, 1000f, 0f, 1.41f))
                rebuildEqList()
                eqPush()
            }
        })

        val postT = TextView(this).apply { setPadding(0, dp(12), 0, 0) }
        eqPostText = postT
        fun postLabel() {
            postT.text = "Post gain: " + String.format(java.util.Locale.US, "%+.1f dB", p.eqPost / 10f)
        }
        postLabel()
        col.addView(postT)
        val postBar = SeekBar(this).apply {
            max = 240
            progress = (p.eqPost + 120).coerceIn(0, 240)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, v: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    p.eqPost = v - 120
                    postLabel()
                    p.eqCurrent = ""
                    EqEngine.apply(p)
                    refreshEqUpdate()
                }

                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        eqPostBar = postBar
        col.addView(postBar)
        label("A limiter sits after the EQ, so boosting won't clip. Lower the post gain if boosted bands sound harsh.")

        label("Quick starts")
        val prow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        eqPresets.forEach { (name, values) ->
            prow.addView(Button(this).apply {
                text = name
                isAllCaps = false
                setOnClickListener {
                    Eq.loaded = ""
                    p.eqPost = 0
                    syncPostBar()
                    eqBandsList.clear()
                    eqBandsList.addAll(EqEngine.parse(values))
                    rebuildEqList()
                    eqPush()
                }
            })
        }
        col.addView(hscroll(prow))

        buildEqDevices()

        label("Import / save")
        col.addView(Button(this).apply {
            text = "Import EQ preset…"
            isAllCaps = false
            setOnClickListener { importDialog() }
        })
        col.addView(Button(this).apply {
            text = "Save current EQ as preset…"
            isAllCaps = false
            setOnClickListener { saveEqDialog() }
        })
        eqUpdateBtn = Button(this).apply {
            isAllCaps = false
            visibility = View.GONE
            setOnClickListener {
                val n = Eq.loaded
                if (n.isNotEmpty()) {
                    eqStore.edit().putString(n, EqEngine.encode(eqBandsList) + "#" + p.eqPost).apply()
                    p.eqCurrent = n
                    toast("Updated \"$n\"")
                    refreshEqUpdate()
                }
            }
        }
        col.addView(eqUpdateBtn)
        refreshEqUpdate()
        eqSaved = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(eqSaved)
        rebuildEqSaved()
    }

    private lateinit var devBox: LinearLayout

    private fun buildEqDevices() {
        label("Per-device presets")
        label("Load a preset automatically when you switch outputs, for example one for Bluetooth headphones and another for wired. Needs the equalizer to be on.")
        val cur = TextView(this).apply { textSize = 12f }
        refreshers.add { cur.text = "Current output: " + (EqDevices.current(this) ?: "unknown") }
        col.addView(cur)
        col.addView(Button(this).apply {
            text = "Set a preset for the current output…"
            isAllCaps = false
            setOnClickListener {
                val dev = EqDevices.current(this@MainActivity)
                if (dev == null) { toast("No output found"); return@setOnClickListener }
                val names = eqStore.all.keys.sorted()
                val items = (listOf("Flat (no EQ)") + names).toTypedArray()
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Preset for $dev")
                    .setItems(items) { _, i ->
                        EqDevices.assign(this@MainActivity, dev, if (i == 0) EqDevices.FLAT else names[i - 1])
                        if (p.eqCurrent.isNotEmpty()) Eq.loaded = p.eqCurrent
                        eqBandsList.clear()
                        eqBandsList.addAll(EqEngine.parse(p.eqBands))
                        rebuildEqList()
                        syncPostBar()
                        refreshEqUpdate()
                        rebuildDevList()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        })
        devBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(devBox)
        rebuildDevList()
    }

    private fun rebuildDevList() {
        devBox.removeAllViews()
        val m = EqDevices.assignments(this)
        if (m.isEmpty()) return
        devBox.addView(TextView(this).apply {
            text = "Assigned (tap to remove)"
            textSize = 13f
            setPadding(0, dp(6), 0, 0)
        })
        m.toSortedMap().forEach { (dev, pr) ->
            devBox.addView(Button(this).apply {
                text = dev + "  →  " + (if (pr == EqDevices.FLAT) "Flat (no EQ)" else pr)
                isAllCaps = false
                setOnClickListener {
                    EqDevices.assign(this@MainActivity, dev, null)
                    rebuildDevList()
                }
            })
        }
    }

    private fun rebuildEqSaved() {
        eqSaved.removeAllViews()
        val names = eqStore.all.keys.sorted()
        if (names.isEmpty()) return
        eqSaved.addView(TextView(this).apply {
            text = "Your EQ presets (tap to load, long-press to delete)"
            textSize = 13f
            setPadding(0, dp(10), 0, dp(2))
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        names.forEach { nm ->
            row.addView(Button(this).apply {
                text = "★ $nm"
                isAllCaps = false
                setOnClickListener {
                    val s = eqStore.getString(nm, "") ?: ""
                    val parts = s.split("#")
                    eqBandsList.clear()
                    eqBandsList.addAll(EqEngine.parse(parts.getOrElse(0) { "" }))
                    p.eqPost = parts.getOrNull(1)?.toIntOrNull() ?: 0
                    Eq.loaded = nm
                    rebuildEqList()
                    syncPostBar()
                    eqPush()
                    p.eqCurrent = nm
                    refreshEqUpdate()
                }
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Delete EQ preset \"$nm\"?")
                        .setPositiveButton("Delete") { _, _ ->
                            eqStore.edit().remove(nm).apply()
                            rebuildEqSaved()
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                    true
                }
            })
        }
        eqSaved.addView(hscroll(row))
    }

    private fun syncPostBar() {
        eqPostBar?.progress = (p.eqPost + 120).coerceIn(0, 240)
        eqPostText?.text = "Post gain: " + String.format(java.util.Locale.US, "%+.1f dB", p.eqPost / 10f)
    }

    private fun saveEqDialog() {
        val et = EditText(this).apply { hint = "Preset name"; setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("Save EQ preset")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isEmpty()) {
                    toast("Give it a name")
                } else {
                    eqStore.edit().putString(n, EqEngine.encode(eqBandsList) + "#" + p.eqPost).apply()
                    p.eqCurrent = n
                    Eq.loaded = n
                    refreshEqUpdate()
                    toast("Saved \"$n\"")
                    rebuildEqSaved()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private var importBox: EditText? = null

    private fun importDialog() {
        val et = EditText(this).apply {
            hint = "Paste preset text here (Equalizer APO lines, \"freq gain Q\" lines, or Ozone XML)"
            minLines = 6
            gravity = Gravity.TOP
            textSize = 12f
        }
        importBox = et
        AlertDialog.Builder(this)
            .setTitle("Import EQ preset")
            .setView(et)
            .setPositiveButton("Import") { _, _ -> doImport(et.text.toString()) }
            .setNeutralButton("Choose file…") { _, _ ->
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                @Suppress("DEPRECATION")
                startActivityForResult(i, 78)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun doImport(text: String) {
        val r = EqImport.parse(text)
        if (r == null || r.bands.isEmpty()) {
            toast("Couldn't find any EQ bands in that. Send me the file and I'll add its format.")
            return
        }
        Eq.loaded = ""
        eqBandsList.clear()
        eqBandsList.addAll(r.bands.take(32))
        p.eqPost = ((r.preampDb ?: 0f) * 10f).toInt().coerceIn(-120, 120)
        rebuildEqList()
        syncPostBar()
        eqPush()
        toast("Imported ${eqBandsList.size} band(s)")
    }

    private fun rebuildEqList() {
        eqBox.removeAllViews()
        eqBandsList.sortBy { it.f }
        eqBandsList.forEachIndexed { idx, b ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(10), 0, dp(4))
            }
            val top = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val typeSp = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, EqEngine.TYPES)
                setSelection(b.type, false)
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                        if (pos != b.type) {
                            b.type = pos
                            eqPush()
                        }
                    }

                    override fun onNothingSelected(parent: AdapterView<*>?) {}
                }
            }
            top.addView(TextView(this).apply { text = "Band ${idx + 1}  " })
            top.addView(typeSp, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            top.addView(Button(this).apply {
                text = "✕"
                setOnClickListener {
                    eqBandsList.remove(b)
                    rebuildEqList()
                    eqPush()
                }
            })
            card.addView(top)

            val fields = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun field(hint: String, init: String, onNum: (Float) -> Unit): EditText {
                val e = EditText(this).apply {
                    this.hint = hint
                    setText(init)
                    setSingleLine()
                    inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                        android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or
                        android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
                    textSize = 14f
                }
                e.addTextChangedListener(object : android.text.TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b2: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b2: Int, c: Int) {}
                    override fun afterTextChanged(s: android.text.Editable?) {
                        val x = num(s) ?: return
                        onNum(x)
                    }
                })
                fields.addView(e, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                return e
            }
            var gainBar: SeekBar? = null
            var gainEdit: EditText? = null
            var guard = false
            field("Hz", fmtNum(b.f)) { b.f = it.coerceIn(10f, 22000f); eqPush() }
            gainEdit = field("dB", fmtNum(b.g)) {
                b.g = it.coerceIn(-15f, 15f)
                if (!guard) {
                    guard = true
                    gainBar?.progress = ((b.g + 15f) * 10f).toInt().coerceIn(0, 300)
                    guard = false
                }
                eqPush()
            }
            field("Q", fmtNum(b.q)) { b.q = it.coerceIn(0.1f, 20f); eqPush() }
            card.addView(fields)
            card.addView(TextView(this).apply { text = "Frequency (Hz)      Gain (dB)      Q"; textSize = 11f })

            gainBar = SeekBar(this).apply {
                max = 300
                progress = ((b.g + 15f) * 10f).toInt().coerceIn(0, 300)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, v: Int, fromUser: Boolean) {
                        if (!fromUser || guard) return
                        guard = true
                        b.g = v / 10f - 15f
                        gainEdit?.setText(fmtNum(b.g))
                        guard = false
                        eqPush()
                    }

                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) {}
                })
            }
            card.addView(gainBar)
            eqBox.addView(card)
        }
        if (eqBandsList.isEmpty()) {
            eqBox.addView(TextView(this).apply {
                text = "No bands: the EQ is flat. Add a band, pick a quick start, or import a preset."
                textSize = 12f
                setPadding(0, dp(8), 0, dp(4))
            })
        }
    }

    private fun fmtNum(x: Float): String =
        if (x == Math.rint(x.toDouble()).toFloat()) x.toInt().toString() else String.format(java.util.Locale.US, "%.2f", x)

    private fun buildBubble() {
        section("Floating bubble")
        label(
            "A small bubble with mini album art and the visualizer, floating over other apps while music plays. " +
                "Tap it for the card, drag it to move it, long-press to open this app."
        )
        label("Turn the bubble on or off from the front page.")
        switchRow("Hide it while the music app is open", { p.bubbleHideInApp }) { p.bubbleHideInApp = it }
        permRow(
            "Usage access (for hiding in the music app)",
            "Lets the bubble know which app is on screen. Find Now Playing Card in the list and allow it.",
            { OverlayService.hasUsageAccess(this) }
        ) { Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS) }
        switchRow("Keep it visible while paused", { p.bubbleKeepPaused }) { p.bubbleKeepPaused = it }
        switchRow("Tap = play / pause, hold = open panel", { p.bubbleTapPlay }) { p.bubbleTapPlay = it }
        label("Off: tap opens the panel and hold opens this app.")
        switchRow("Haptic feedback on tap and hold", { p.bubbleHaptic }) { p.bubbleHaptic = it }
        slider("Hide after being paused for (0 = never)", "min", 0, 60, p.bubbleHideMin) { p.bubbleHideMin = it }
        label("It always disappears once the music app is fully closed (if the app ends its media session).")
        choice("Bubble visualizer", CardRenderer.STYLES, { p.bubbleStyle }) { p.bubbleStyle = it }
        choice("Bubble shape", listOf("Circle", "Rounded square", "Square"), { p.bubbleShape }) { p.bubbleShape = it }
        slider("Bubble size", "dp", 36, 100, p.bubbleSize) { p.bubbleSize = it }
        slider("Visualizer bars", "", 8, 48, p.bubbleBars) { p.bubbleBars = it }
        slider("Bubble opacity", "%", 30, 100, p.bubbleOpacity) { p.bubbleOpacity = it }
        switchRow("Fling sideways to tuck it into the screen edge", { p.bubbleTuck }) { p.bubbleTuck = it }
        switchRow("Fling down to shrink it to a small dot", { p.bubbleDot }) { p.bubbleDot = it }
        label("Tap a tucked or shrunk bubble to bring it back. Dragging a tucked bubble also pulls it out.")
        switchRow("Snap to the screen edge", { p.bubbleSnap }) { p.bubbleSnap = it }
        slider("Pop-up card width", "dp", 260, 400, p.popupWidth) { p.popupWidth = it }
        slider("Close the card after (0 = stay open)", "sec", 0, 30, p.popupClose) { p.popupClose = it }
        label("The bubble uses the colors, sensitivity and spin settings from the Visualizer section. The pop-up card uses your full card look.")
    }

    // -------------------------------------------------------------------- helpers

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private val overlayRestart = Runnable { applyOverlay() }

    /** Called after any setting changes. */
    private fun changed() {
        card.reload()
        if (p.bubbleOn) {
            handler.removeCallbacks(overlayRestart)
            handler.postDelayed(overlayRestart, 700)
        }
    }

    private fun applyOverlay() {
        if (p.bubbleOn && Settings.canDrawOverlays(this)) {
            try {
                startForegroundService(Intent(this, OverlayService::class.java))
            } catch (e: Exception) {
                toast("Couldn't start the bubble")
            }
        } else {
            stopService(Intent(this, OverlayService::class.java))
        }
    }

    private fun listenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(packageName)
    }

    private fun savePresetDialog() {
        val et = EditText(this).apply { hint = "Preset name"; setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("Save current look")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isEmpty()) {
                    toast("Give it a name")
                } else {
                    p.savePreset(n)
                    toast("Saved \"$n\"")
                    recreateKeep()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun section(t: String) {
        if (skipSection) { skipSection = false; return }
        col.addView(TextView(this).apply {
            text = t
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(28), 0, dp(6))
        })
    }

    private fun label(t: String) {
        col.addView(TextView(this).apply {
            text = t
            textSize = 13f
            setPadding(0, dp(10), 0, dp(2))
        })
    }

    private fun permRow(title: String, desc: String, ok: () -> Boolean, intent: () -> Intent) {
        val t = TextView(this).apply { setPadding(0, dp(8), 0, 0) }
        val b = Button(this).apply {
            text = "Open settings"
            isAllCaps = false
            setOnClickListener {
                try {
                    startActivity(intent())
                } catch (e: Exception) {
                    toast("Could not open that settings page")
                }
            }
        }
        refreshers.add {
            val g = ok()
            t.text = (if (g) "✅ " else "❌ ") + title + "\n" + desc
            b.visibility = if (g) View.GONE else View.VISIBLE
        }
        col.addView(t)
        col.addView(b)
        t.text = title + "\n" + desc
    }

    private fun switchRow(name: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        col.addView(Switch(this).apply {
            text = name
            isChecked = get()
            setPadding(0, dp(8), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                set(on)
                changed()
            }
        })
    }

    private fun choice(name: String, opts: List<String>, get: () -> Int, set: (Int) -> Unit) {
        label(name)
        col.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, opts)
            setSelection(get())
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    if (pos != get()) {
                        set(pos)
                        changed()
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        })
    }

    private fun slider(name: String, unit: String, min: Int, max: Int, init: Int, onSet: (Int) -> Unit) {
        val t = TextView(this).apply {
            text = "$name: $init $unit"
            setPadding(0, dp(12), 0, 0)
        }
        val s = SeekBar(this).apply {
            this.max = max - min
            progress = (init - min).coerceIn(0, max - min)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, v: Int, fromUser: Boolean) {
                    val x = v + min
                    t.text = "$name: $x $unit"
                    if (fromUser) {
                        onSet(x)
                        changed()
                    }
                }

                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        col.addView(t)
        col.addView(s)
    }

    private fun colorRow(name: String, get: () -> Int, set: (Int) -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        val sw = View(this)
        fun paintSwatch() {
            sw.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(get())
                setStroke(dp(2), 0xFF888888.toInt())
            }
        }
        paintSwatch()
        val openPicker = View.OnClickListener {
            pickColor(get()) { picked ->
                set(picked)
                paintSwatch()
                changed()
            }
        }
        sw.setOnClickListener(openPicker)
        row.setOnClickListener(openPicker)
        row.addView(
            TextView(this).apply { text = name },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        row.addView(sw, LinearLayout.LayoutParams(dp(40), dp(40)))
        col.addView(row)
    }

    private fun pickColor(initial: Int, onPick: (Int) -> Unit) {
        val hsv = FloatArray(3)
        Color.colorToHSV(initial, hsv)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
        }
        val preview = View(this).apply { setBackgroundColor(Color.HSVToColor(hsv)) }
        box.addView(preview, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)))

        fun bar(name: String, maxV: Int, initV: Int, setter: (Int) -> Unit) {
            box.addView(TextView(this).apply {
                text = name
                setPadding(0, dp(8), 0, 0)
            })
            box.addView(SeekBar(this).apply {
                this.max = maxV
                progress = initV
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, v: Int, fromUser: Boolean) {
                        setter(v)
                        preview.setBackgroundColor(Color.HSVToColor(hsv))
                    }

                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) {}
                })
            })
        }
        bar("Hue", 360, hsv[0].toInt()) { hsv[0] = it.toFloat() }
        bar("Saturation", 100, (hsv[1] * 100).toInt()) { hsv[1] = it / 100f }
        bar("Brightness", 100, (hsv[2] * 100).toInt()) { hsv[2] = it / 100f }

        AlertDialog.Builder(this)
            .setTitle("Pick a color")
            .setView(box)
            .setPositiveButton("OK") { _, _ -> onPick(Color.HSVToColor(hsv)) }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
