package app.nowplaying

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var p: Prefs
    private lateinit var col: LinearLayout
    private lateinit var card: CardView
    private var density = 1f
    private val handler = Handler(Looper.getMainLooper())
    private val refreshers = ArrayList<() -> Unit>()
    private var active = false

    private fun dp(i: Int) = (i * density).toInt()

    // keep scroll positions across recreateKeep() so lists don't snap back
    private var vScroll: ScrollView? = null
    private val hScrolls = ArrayList<HorizontalScrollView>()
    private object Keep { var y = 0; var xs = ArrayList<Int>(); var on = false }

    private fun hscroll(inner: View): HorizontalScrollView {
        val h = HorizontalScrollView(this).apply { addView(inner) }
        hScrolls.add(h)
        return h
    }

    private fun recreateKeep() {
        Keep.y = vScroll?.scrollY ?: 0
        Keep.xs = ArrayList(hScrolls.map { it.scrollX })
        Keep.on = true
        recreate()
    }

    private fun restoreScroll() {
        if (!Keep.on) return
        Keep.on = false
        val y = Keep.y
        val xs = Keep.xs
        vScroll?.post {
            vScroll?.scrollTo(0, y)
            hScrolls.forEachIndexed { i, h -> if (i < xs.size) h.scrollTo(xs[i], 0) }
        }
    }

    // Built-in looks. Keys match Prefs.lookKeys; anything not listed is reset to its default.
    private val builtIn: List<Pair<String, Map<String, Any>>> = listOf(
        "Minimal" to mapOf("vizStyle" to 0, "bgMode" to 0, "bgColor" to 0xFF111214.toInt(), "bgOpacity" to 94, "vizBars" to 28),
        "Glass" to mapOf("vizStyle" to 7, "bgMode" to 2, "bgOpacity" to 82, "corner" to 32),
        "Neon ring" to mapOf("vizStyle" to 4, "vizColorMode" to 3, "bgMode" to 0, "bgColor" to 0xFF0B0B10.toInt(), "vizBars" to 48, "bgOpacity" to 95),
        "Pulse" to mapOf("vizStyle" to 5, "bgMode" to 2),
        "Scope" to mapOf(
            "vizStyle" to 2, "vizColorMode" to 1, "bgMode" to 0, "bgColor" to 0xFF08090C.toInt(),
            "font" to 5, "titleBold" to false, "bgOpacity" to 95
        ),
        "Skyline" to mapOf(
            "vizStyle" to 3, "vizColorMode" to 1, "vizColor" to 0xFFFF9100.toInt(), "vizColor2" to 0xFFFF4081.toInt(), "bgMode" to 1
        ),
        "Particles" to mapOf("vizStyle" to 6, "bgMode" to 2),
        "LED" to mapOf(
            "vizStyle" to 0, "vizSegments" to true, "vizColorMode" to 1, "vizColor" to 0xFF76FF03.toInt(),
            "vizColor2" to 0xFFFF1744.toInt(), "bgMode" to 0, "bgColor" to 0xFF000000.toInt(), "font" to 2,
            "vizHeight" to 64, "vizBars" to 24, "bgOpacity" to 96
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs(this)
        density = resources.displayMetrics.density
        MediaState.ensureStarted(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setOnApplyWindowInsetsListener { v, ins ->
                val i = ins.getInsets(WindowInsets.Type.systemBars())
                v.setPadding(i.left, i.top, i.right, i.bottom)
                ins
            }
        }
        card = CardView(this, p)
        card.onTap = { startActivity(Intent(this, PlayerActivity::class.java)) }
        root.addView(
            card,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(dp(14), dp(10), dp(14), dp(6)) }
        )

        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), dp(32))
        }
        root.addView(
            ScrollView(this).apply { addView(col) }.also { vScroll = it },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)

        buildSetup()
        buildLooks()
        buildVisualizer()
        buildArt()
        buildBackground()
        buildText()
        buildControls()
        buildBubble()
        restoreScroll()
    }

    override fun onResume() {
        super.onResume()
        active = true
        MediaState.retry()
        Audio.retry(this)
        card.reload()
        refreshers.forEach { it() }
        handler.post(ticker)
    }

    override fun onPause() {
        active = false
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!active) return
            refreshers.forEach { it() }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Audio.retry(this)
        refreshers.forEach { it() }
    }

    // -------------------------------------------------------------------- sections

    private fun buildSetup() {
        section("Setup")
        permRow(
            "Notification access (required)",
            "Lets the app see what is playing and control it. No notifications are read.",
            { listenerEnabled() }
        ) { Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }
        val audioRow = TextView(this).apply { setPadding(0, dp(8), 0, 0) }
        val audioBtn = Button(this).apply {
            text = "Grant audio permission"
            isAllCaps = false
            setOnClickListener { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2) }
        }
        refreshers.add {
            val ok = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            audioRow.text = (if (ok) "✅ " else "❌ ") + "Audio permission (for the visualizer)\n" +
                "Android calls this the microphone permission. The music is only analysed live, never recorded."
            audioBtn.visibility = if (ok) View.GONE else View.VISIBLE
        }
        col.addView(audioRow)
        col.addView(audioBtn)

        col.addView(Switch(this).apply {
            text = "Demo mode (fake music, to try looks)"
            isChecked = MediaState.demo
            setPadding(0, dp(12), 0, dp(4))
            setOnCheckedChangeListener { _, on -> MediaState.setDemo(on) }
        })
        val status = TextView(this).apply { textSize = 12f; setPadding(0, dp(6), 0, 0) }
        refreshers.add {
            status.text = MediaState.status + "\n" + Audio.status + "\n" + OverlayService.status
        }
        col.addView(status)
        col.addView(Button(this).apply {
            text = "Open full-screen player"
            isAllCaps = false
            setOnClickListener { startActivity(Intent(this@MainActivity, PlayerActivity::class.java)) }
        })
    }

    private fun buildLooks() {
        section("Looks")
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        builtIn.forEach { (name, map) ->
            row.addView(Button(this).apply {
                text = name
                isAllCaps = false
                setOnClickListener {
                    p.apply(map)
                    changed()
                    recreateKeep()
                }
            })
        }
        col.addView(hscroll(row))
        col.addView(Button(this).apply {
            text = "Save current look as preset…"
            isAllCaps = false
            setOnClickListener { savePresetDialog() }
        })
        val mine = p.savedPresetNames()
        if (mine.isNotEmpty()) {
            label("Your presets (tap to load, long-press to delete)")
            val urow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            mine.forEach { nm ->
                urow.addView(Button(this).apply {
                    text = "★ $nm"
                    isAllCaps = false
                    setOnClickListener {
                        p.loadPreset(nm)
                        changed()
                        recreateKeep()
                    }
                    setOnLongClickListener {
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("Delete preset \"$nm\"?")
                            .setPositiveButton("Delete") { _, _ ->
                                p.deletePreset(nm)
                                recreateKeep()
                            }
                            .setNegativeButton("Cancel", null)
                            .show()
                        true
                    }
                })
            }
            col.addView(hscroll(urow))
        }
    }

    private fun buildVisualizer() {
        section("Visualizer")
        choice("Style", CardRenderer.STYLES, { p.vizStyle }) { p.vizStyle = it }
        choice(
            "Colors",
            listOf("Solid color", "Two-color gradient", "From album art", "Rainbow"),
            { p.vizColorMode }
        ) { p.vizColorMode = it }
        colorRow("Color 1 (solid / gradient start)", { p.vizColor }) { p.vizColor = it }
        colorRow("Color 2 (gradient end)", { p.vizColor2 }) { p.vizColor2 = it }
        slider("Bars", "", 8, 64, p.vizBars) { p.vizBars = it }
        slider("Sensitivity", "%", 30, 250, p.vizSens) { p.vizSens = it }
        slider("Opacity", "%", 20, 100, p.vizOpacity) { p.vizOpacity = it }
        slider("Height (bars, wave styles)", "dp", 24, 140, p.vizHeight) { p.vizHeight = it }
        slider("Reach (circular and pulse ring)", "dp", 10, 50, p.vizDepth) { p.vizDepth = it }
        switchRow("LED segments (bars)", { p.vizSegments }) { p.vizSegments = it }
        switchRow("Reflection (bars)", { p.vizReflect }) { p.vizReflect = it }
        switchRow("Glow (lines and waves)", { p.vizGlow }) { p.vizGlow = it }
        switchRow("Slow spin (circular)", { p.vizSpin }) { p.vizSpin = it }
        switchRow("Gentle motion while paused", { p.idleBreath }) { p.idleBreath = it }
    }

    private fun buildArt() {
        section("Album art")
        choice("Shape", listOf("Square", "Rounded", "Circle"), { p.artShape }) { p.artShape = it }
        slider("Size (compact card)", "dp", 56, 160, p.artSize) { p.artSize = it }
        choice("Position (compact card)", listOf("Left", "Right"), { p.artPos }) { p.artPos = it }
        switchRow("Soft shadow", { p.artShadow }) { p.artShadow = it }
        label("Circular spectrum and Pulse ring always use a circle.")
    }

    private fun buildBackground() {
        section("Background")
        choice(
            "Style",
            listOf("Solid color", "Tinted from album art", "Blurred album art"),
            { p.bgMode }
        ) { p.bgMode = it }
        colorRow("Solid color", { p.bgColor }) { p.bgColor = it }
        slider("Opacity", "%", 0, 100, p.bgOpacity) { p.bgOpacity = it }
        slider("Corner radius", "dp", 0, 48, p.corner) { p.corner = it }
        slider("Blur (blurred style)", "%", 0, 100, p.blurAmount) { p.blurAmount = it }
    }

    private fun buildText() {
        section("Text")
        choice("Font", CardRenderer.FONTS, { p.font }) { p.font = it }
        switchRow("Bold title", { p.titleBold }) { p.titleBold = it }
        slider("Title size", "sp", 12, 30, p.titleSize) { p.titleSize = it }
        slider("Artist size", "sp", 10, 24, p.artistSize) { p.artistSize = it }
        choice("Text color", listOf("White", "Black", "From album art", "Custom"), { p.textMode }) { p.textMode = it }
        colorRow("Custom text color", { p.textColor }) { p.textColor = it }
        switchRow("Show album name", { p.showAlbum }) { p.showAlbum = it }
    }

    private fun buildControls() {
        section("Controls")
        switchRow("Show play / previous / next", { p.showControls }) { p.showControls = it }
        choice("Button style", listOf("Filled play button", "Minimal"), { p.controlStyle }) { p.controlStyle = it }
        switchRow("Progress line (drag to seek)", { p.showProgress }) { p.showProgress = it }
    }

    private fun buildBubble() {
        section("Floating bubble")
        label(
            "A small bubble with mini album art and the visualizer, floating over other apps while music plays. " +
                "Tap it for the card, drag it to move it, long-press to open this app."
        )
        permRow(
            "Display over other apps",
            "Needed for the bubble.",
            { Settings.canDrawOverlays(this) }
        ) { Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")) }
        col.addView(Switch(this).apply {
            text = "Show the bubble"
            isChecked = p.bubbleOn
            setPadding(0, dp(8), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                p.bubbleOn = on
                if (on && Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
                }
                if (on && !Settings.canDrawOverlays(this@MainActivity)) {
                    toast("Allow \"Display over other apps\" first")
                }
                applyOverlay()
            }
        })
        switchRow("Keep it visible while paused", { p.bubbleKeepPaused }) { p.bubbleKeepPaused = it }
        switchRow("Tap = play / pause, hold = open panel", { p.bubbleTapPlay }) { p.bubbleTapPlay = it }
        label("Off: tap opens the panel and hold opens this app.")
        switchRow("Haptic feedback on tap and hold", { p.bubbleHaptic }) { p.bubbleHaptic = it }
        slider("Hide after being paused for (0 = never)", "min", 0, 60, p.bubbleHideMin) { p.bubbleHideMin = it }
        label("It always disappears once the music app is fully closed (if the app ends its media session).")
        choice("Bubble visualizer", CardRenderer.STYLES, { p.bubbleStyle }) { p.bubbleStyle = it }
        choice("Bubble shape", listOf("Circle", "Rounded square", "Square"), { p.bubbleShape }) { p.bubbleShape = it }
        slider("Bubble size", "dp", 36, 100, p.bubbleSize) { p.bubbleSize = it }
        slider("Visualizer bars", "", 8, 48, p.bubbleBars) { p.bubbleBars = it }
        slider("Bubble opacity", "%", 30, 100, p.bubbleOpacity) { p.bubbleOpacity = it }
        switchRow("Snap to the screen edge", { p.bubbleSnap }) { p.bubbleSnap = it }
        slider("Pop-up card width", "dp", 260, 400, p.popupWidth) { p.popupWidth = it }
        slider("Close the card after (0 = stay open)", "sec", 0, 30, p.popupClose) { p.popupClose = it }
        label("The bubble uses the colors, sensitivity and spin settings from the Visualizer section. The pop-up card uses your full card look.")
    }

    // -------------------------------------------------------------------- helpers

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private val overlayRestart = Runnable { applyOverlay() }

    /** Called after any setting changes. */
    private fun changed() {
        card.reload()
        if (p.bubbleOn) {
            handler.removeCallbacks(overlayRestart)
            handler.postDelayed(overlayRestart, 700)
        }
    }

    private fun applyOverlay() {
        if (p.bubbleOn && Settings.canDrawOverlays(this)) {
            try {
                startForegroundService(Intent(this, OverlayService::class.java))
            } catch (e: Exception) {
                toast("Couldn't start the bubble")
            }
        } else {
            stopService(Intent(this, OverlayService::class.java))
        }
    }

    private fun listenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(packageName)
    }

    private fun savePresetDialog() {
        val et = EditText(this).apply { hint = "Preset name"; setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("Save current look")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isEmpty()) {
                    toast("Give it a name")
                } else {
                    p.savePreset(n)
                    toast("Saved \"$n\"")
                    recreateKeep()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun section(t: String) {
        col.addView(TextView(this).apply {
            text = t
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(28), 0, dp(6))
        })
    }

    private fun label(t: String) {
        col.addView(TextView(this).apply {
            text = t
            textSize = 13f
            setPadding(0, dp(10), 0, dp(2))
        })
    }

    private fun permRow(title: String, desc: String, ok: () -> Boolean, intent: () -> Intent) {
        val t = TextView(this).apply { setPadding(0, dp(8), 0, 0) }
        val b = Button(this).apply {
            text = "Open settings"
            isAllCaps = false
            setOnClickListener {
                try {
                    startActivity(intent())
                } catch (e: Exception) {
                    toast("Could not open that settings page")
                }
            }
        }
        refreshers.add {
            val g = ok()
            t.text = (if (g) "✅ " else "❌ ") + title + "\n" + desc
            b.visibility = if (g) View.GONE else View.VISIBLE
        }
        col.addView(t)
        col.addView(b)
        t.text = title + "\n" + desc
    }

    private fun switchRow(name: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        col.addView(Switch(this).apply {
            text = name
            isChecked = get()
            setPadding(0, dp(8), 0, dp(4))
            setOnCheckedChangeListener { _, on ->
                set(on)
                changed()
            }
        })
    }

    private fun choice(name: String, opts: List<String>, get: () -> Int, set: (Int) -> Unit) {
        label(name)
        col.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, opts)
            setSelection(get())
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    if (pos != get()) {
                        set(pos)
                        changed()
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        })
    }

    private fun slider(name: String, unit: String, min: Int, max: Int, init: Int, onSet: (Int) -> Unit) {
        val t = TextView(this).apply {
            text = "$name: $init $unit"
            setPadding(0, dp(12), 0, 0)
        }
        val s = SeekBar(this).apply {
            this.max = max - min
            progress = (init - min).coerceIn(0, max - min)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, v: Int, fromUser: Boolean) {
                    val x = v + min
                    t.text = "$name: $x $unit"
                    if (fromUser) {
                        onSet(x)
                        changed()
                    }
                }

                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        col.addView(t)
        col.addView(s)
    }

    private fun colorRow(name: String, get: () -> Int, set: (Int) -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        val sw = View(this)
        fun paintSwatch() {
            sw.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(get())
                setStroke(dp(2), 0xFF888888.toInt())
            }
        }
        paintSwatch()
        val openPicker = View.OnClickListener {
            pickColor(get()) { picked ->
                set(picked)
                paintSwatch()
                changed()
            }
        }
        sw.setOnClickListener(openPicker)
        row.setOnClickListener(openPicker)
        row.addView(
            TextView(this).apply { text = name },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        row.addView(sw, LinearLayout.LayoutParams(dp(40), dp(40)))
        col.addView(row)
    }

    private fun pickColor(initial: Int, onPick: (Int) -> Unit) {
        val hsv = FloatArray(3)
        Color.colorToHSV(initial, hsv)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
        }
        val preview = View(this).apply { setBackgroundColor(Color.HSVToColor(hsv)) }
        box.addView(preview, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)))

        fun bar(name: String, maxV: Int, initV: Int, setter: (Int) -> Unit) {
            box.addView(TextView(this).apply {
                text = name
                setPadding(0, dp(8), 0, 0)
            })
            box.addView(SeekBar(this).apply {
                this.max = maxV
                progress = initV
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar, v: Int, fromUser: Boolean) {
                        setter(v)
                        preview.setBackgroundColor(Color.HSVToColor(hsv))
                    }

                    override fun onStartTrackingTouch(sb: SeekBar) {}
                    override fun onStopTrackingTouch(sb: SeekBar) {}
                })
            })
        }
        bar("Hue", 360, hsv[0].toInt()) { hsv[0] = it.toFloat() }
        bar("Saturation", 100, (hsv[1] * 100).toInt()) { hsv[1] = it / 100f }
        bar("Brightness", 100, (hsv[2] * 100).toInt()) { hsv[2] = it / 100f }

        AlertDialog.Builder(this)
            .setTitle("Pick a color")
            .setView(box)
            .setPositiveButton("OK") { _, _ -> onPick(Color.HSVToColor(hsv)) }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
