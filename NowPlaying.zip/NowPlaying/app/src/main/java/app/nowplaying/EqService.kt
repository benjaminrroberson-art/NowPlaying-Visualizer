package app.nowplaying

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/** Keeps the process alive so the system equalizer stays applied. */
class EqService : Service() {

    companion object {
        fun sync(ctx: Context) {
            EqEngine.ctx = ctx.applicationContext
            val p = Prefs(ctx)
            if (p.eqOn) {
                try { ctx.startForegroundService(Intent(ctx, EqService::class.java)) } catch (e: Exception) {}
            } else {
                ctx.stopService(Intent(ctx, EqService::class.java))
                EqEngine.apply(p)
            }
        }
    }

    private val devCb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>?) { devChanged() }
        override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>?) { devChanged() }
    }
    private val h = Handler(Looper.getMainLooper())
    private fun devChanged() {
        h.removeCallbacksAndMessages(null)
        h.postDelayed({ EqDevices.applyForCurrent(this) }, 1200)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("np_eq", "Equalizer", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "np_eq")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Equalizer is on")
            .setContentText("Tap to adjust")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        EqEngine.ctx = applicationContext
        EqEngine.apply(Prefs(this))
        EqDevices.resetLast()
        EqDevices.applyForCurrent(this)
        try {
            val am = getSystemService(AudioManager::class.java)
            am.unregisterAudioDeviceCallback(devCb)
            am.registerAudioDeviceCallback(devCb, h)
        } catch (e: Exception) {}
        EqEngine.startPoll()
        return START_STICKY
    }

    override fun onDestroy() {
        try { getSystemService(AudioManager::class.java).unregisterAudioDeviceCallback(devCb) } catch (e: Exception) {}
        EqEngine.stopPoll()
        EqEngine.release()
        EqEngine.status = "EQ: off"
        super.onDestroy()
    }
}
