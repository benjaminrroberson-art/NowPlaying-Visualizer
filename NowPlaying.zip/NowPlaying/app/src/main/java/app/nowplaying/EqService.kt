package app.nowplaying

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder

/** Keeps the process alive so the system equalizer stays applied. */
class EqService : Service() {

    companion object {
        fun sync(ctx: Context) {
            EqEngine.ctx = ctx.applicationContext
            val p = Prefs(ctx)
            if (p.eqOn) {
                try { ctx.startForegroundService(Intent(ctx, EqService::class.java)) } catch (e: Exception) {}
            } else {
                ctx.stopService(Intent(ctx, EqService::class.java))
                EqEngine.apply(p)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("np_eq", "Equalizer", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "np_eq")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Equalizer is on")
            .setContentText("Tap to adjust")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        EqEngine.ctx = applicationContext
        EqEngine.apply(Prefs(this))
        EqEngine.startPoll()
        return START_STICKY
    }

    override fun onDestroy() {
        EqEngine.stopPoll()
        EqEngine.release()
        EqEngine.status = "EQ: off"
        super.onDestroy()
    }
}
