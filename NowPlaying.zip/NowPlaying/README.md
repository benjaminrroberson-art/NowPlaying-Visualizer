# Now Playing Card

Minimal now-playing card with a live music visualizer: app, floating card, home-screen widget.
Build and install the same way as Edge Volume Light (GitHub Actions + Obtainium).
